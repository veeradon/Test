package AEPCustomMonitor;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2005-08-03 14:35:53 EDT
// -----( ON-HOST: hqwhslas068.aepsc.com

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.util.*;
import java.io.*;
import oracle.jdbc.driver.OracleResultSet;
import com.wm.util.coder.*;
import com.wm.app.b2b.server.*;
import java.sql.*;
import com.wm.app.b2b.client.*;
// --- <<IS-END-IMPORTS>> ---

public final class utils

{
	// ---( internal utility methods )---

	final static utils _instance = new utils();

	static utils _newInstance() { return new utils(); }

	static utils _cast(Object o) { return (utils)o; }

	// ---( server methods )---




	public static final void checkPoolAvailability (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(checkPoolAvailability)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required maxPoolSize
		// [i] field:0:required busyConnections
		// [o] field:0:required availPercent
		IDataCursor pipelineCursor = pipeline.getCursor();
			int	maxPoolSize = Integer.parseInt(IDataUtil.getString( pipelineCursor, "maxPoolSize" ));
			int	busyConnections = Integer.parseInt(IDataUtil.getString( pipelineCursor, "busyConnections" ));
		pipelineCursor.destroy();
		
		int availPercent=((maxPoolSize-busyConnections)*100/maxPoolSize);
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "availPercent", Integer.toString(availPercent) );
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void generateHtmlscript (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(generateHtmlscript)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] record:0:required document
		// [i] field:0:optional id
		// [o] field:0:required htmlcontent
		IDataCursor pipelineCursor = pipeline.getCursor();
		int elementCount=0;
		String	id = String.valueOf(IDataUtil.getString( pipelineCursor, "id" ));
		IData	document = IDataUtil.getIData( pipelineCursor,"document" );
		  try
		    {
		      cls=Class.forName("com.wm.data.IData"); 
		      clsArray=((Object)(new IData[2])).getClass();
		    }catch(Exception e) {
		                           throw (new ServiceException(e.toString()));
		                        }
		
		String htmlcontent=null;
		            
		   if ( document != null)     
		    {
		        StringBuffer sbuf=new StringBuffer();
		        String k2=pipelineCursor.getKey();
		        if(!(id.equals("null")))
		          k2=k2+"_"+id;
		 
		        sbuf.append("<TR><td class=oddrow-l valign=top width=10%><IMG id=img"+k2+" src=images/tree_plus.gif  onClick=collapse('"+k2+"');>&nbsp;"+pipelineCursor.getKey()+"</TD>");
		        sbuf.append("<td class=oddrow-l><DIV id="+k2+" style=display:none><TABLE>");
		        genHtml(document,sbuf,k2);
		        sbuf.append("</TABLE></DIV></TD><TR>");
		        htmlcontent=sbuf.toString();
		    }
		pipelineCursor.destroy();
		IDataCursor pipelineCursor_1 = pipeline.getCursor();   
		IDataUtil.put(pipelineCursor_1,"htmlcontent",htmlcontent); 
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void invokeService (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(invokeService)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required serviceName
		// [o] field:0:required invokeStatus
		
		
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	serviceName = IDataUtil.getString( pipelineCursor, "serviceName" );
		pipelineCursor.destroy();
		int indx = serviceName.indexOf(':');
		String folderName =serviceName.substring(0,indx);
		String srvName =serviceName.substring(indx+1);
		String invokeStatus = invokeService(folderName,srvName);
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "invokeStatus", invokeStatus);
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void isWmService (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(isWmService)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required schName
		// [o] field:0:required isWmIntegration
		
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	schName = IDataUtil.getString( pipelineCursor, "schName" );
		pipelineCursor.destroy();
		
		String isWmIntegration = "false";
		
		   String wm = "wm";
		   boolean bol = schName.startsWith(wm);
		    if(bol)
		           isWmIntegration = "true";
		    
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		
		IDataUtil.put( pipelineCursor_1, "isWmIntegration", isWmIntegration);
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	private static Class cls=null;
	private static Class clsArray=null;
	private static String[] ids={"unitID","fuelName"};
	
	
	private static void getElementCount(IData dataObj,Hashtable queryStore,String[] reqList)
	{
	  IDataCursor documentCursor = dataObj.getCursor();
	  while(documentCursor.next())
	    {
	      Object obj=documentCursor.getValue();
	      for(int k=0;k<reqList.length;k++)
	      { 
	        if((documentCursor.getKey()).equals(reqList[k]))
	         {
	            if(!(queryStore.containsKey(reqList[k])))
	            {
	               ArrayList alist=new ArrayList();
	               alist.add(obj);  
	               queryStore.put(reqList[k],(Object)alist) ; 
	            } 
	            else{
	              	  ArrayList alist1=(ArrayList)queryStore.get(reqList[k]);
	                  alist1.add(obj);
	            }
	            break;
	         }
	       } 
	
	      if((cls.isInstance(obj)) || (clsArray.isInstance(obj)))
	       {
	          if((obj.getClass()).isArray())
	            {
	              IData[] dObj=(IData[])obj;
	              for(int i=0;i<dObj.length;i++)
	 				getElementCount(dObj[i],queryStore,reqList);   
	            }
	          else
	   	    	getElementCount((IData)obj,queryStore,reqList);
	  
	        }
	       
	    } 
	   documentCursor.destroy();
	   
	}
	
	private static void genHtml(IData dataObj,StringBuffer sbuf,String keyID)
	{
	  IDataCursor documentCursor = dataObj.getCursor();
	  while(documentCursor.next())
	    {
	      Object obj=documentCursor.getValue();
	      if(obj != null)
	       {                 
	     	 if((cls.isInstance(obj))||(clsArray.isInstance(obj)))
	       	{
	          if((obj.getClass()).isArray())
	            {
	              addDocToHtml(documentCursor.getKey(),sbuf,keyID+"|"+documentCursor.getKey()); 
	              IData[] dObj=(IData[])obj;
	              for(int i=0;i<dObj.length;i++)
	              {
	                String k1=(documentCursor.getKey()).toString();
	                addDocToHtml(getDocRef(dObj[i],k1,ids,i),sbuf,keyID+"|"+k1+"_"+i);
	 				genHtml(dObj[i],sbuf,keyID+"|"+k1+"_"+i); 
	                sbuf.append("</TABLE></DIV></TD><TR>");   
	              }  
	             sbuf.append("</TABLE></DIV></TD><TR>");  
	            }
	          else{
	                String k1=(documentCursor.getKey()).toString();
	                addDocToHtml(k1,sbuf,keyID+"|"+k1);
	   	    		genHtml((IData)obj,sbuf,keyID+"|"+k1);
	                sbuf.append("</TABLE></DIV></TD><TR>");
	          }  
	  
	        }
	        else{
	             addElementToHtml((documentCursor.getKey()).toString(),htmlEncode((documentCursor.getValue()).toString()),sbuf); 
	        }   
	     } 
	      else
	   		{  
	     		addElementToHtml((documentCursor.getKey()).toString(),"",sbuf); 
	   		}  
	   }
	  
	   documentCursor.destroy();
	}
	
	private static String getDocRef(IData idataObj,String docKey,String[] ids,int counter)
	{
	  String retStr=docKey;
	  IDataCursor documentCursor = idataObj.getCursor();
	  if(ids != null)
	   {
	      for(int i=0;i<ids.length;i++)
	       {
	         String tStr=String.valueOf(IDataUtil.get(documentCursor,ids[i])); 
	         if(!(tStr.equals("null")))  
	          { 
	            retStr=retStr+"["+ids[i]+"="+tStr+"]";
	            break; 
	          }  
	       }
	
	   } 
	  
	  if(retStr.equals(docKey))
	    retStr=retStr+" ["+counter+"]";
	
	 documentCursor.destroy();
	 return retStr;
	
	}
	 
	private static void addDocToHtml(String key,StringBuffer sbuf,String keyID)
	{
	  sbuf.append("<td class=oddrow-l valign=top><IMG id=img"+keyID+" src=images/tree_plus.gif  onClick=collapse('"+keyID+"')>&nbsp;"+key+"</TD>");
	  sbuf.append("<td class=oddrow-l><DIV id="+keyID+" style=display:none><TABLE>");
	}
	
	private static void addElementToHtml(String key,String value,StringBuffer sbuf)
	{
	  sbuf.append("<TR><td class=evenrow-l><IMG src=images/tree_blank.gif>&nbsp;"+key+"</TD>");
	  sbuf.append("<td class=evenrow-l>&nbsp;"+value+"</TD></TR>");
	
	}
	
	private static void logmessage(String message)
	{
	 
	IData input = IDataFactory.create();
	IDataCursor inputCursor = input.getCursor();
	IDataUtil.put( inputCursor, "message",message);
	inputCursor.destroy();
	IData 	output = IDataFactory.create();
	try{
		output = Service.doInvoke( "pub.flow", "debugLog", input );
	}catch( Exception e){}
	
	}
	
	private static String htmlEncode(String inString)
	{
		IData input = IDataFactory.create();
		IDataCursor inputCursor = input.getCursor();
		IDataUtil.put( inputCursor, "inString", inString);
		inputCursor.destroy();
	
		IData 	output = IDataFactory.create();
		try{
				output = Service.doInvoke( "pub.string", "HTMLEncode", input );
		}catch( Exception e){}
		IDataCursor outputCursor = output.getCursor();
		String value=IDataUtil.getString( outputCursor, "value" );
		outputCursor.destroy();
	    return value;
	
	}
	
	
	
	
	
	private static String invokeService(String folderName,String srvName){
	  String invokeStatus = "false";
	  
	IData input = IDataFactory.create();
	
	
	IData 	output = IDataFactory.create();
	try{
		output = Service.doInvoke( folderName, srvName, input );
		invokeStatus = "true";
	}catch( Exception e){
	     invokeStatus = e.toString();
	       }
	
	  return invokeStatus;
	}
	
	// --- <<IS-END-SHARED>> ---
}

