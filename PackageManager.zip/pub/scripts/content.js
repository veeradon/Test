function checkContent()
   {
   
   
      var row = 0;
      var tObj=document.getElementById('fcparams_body');
      for(i=1;i<tObj.childNodes.length;i++)
       {
         var trObj=tObj.childNodes[i];
           if(row == 0){
         trObj.setAttribute("bgColor","#E0E0C0");
                  row++;
                }
   
            else{
               trObj.setAttribute("bgColor","#F0F0E0");
                row = 0;
               }
         for(j=0;j<trObj.childNodes.length;j++)
          {
            var tdObj=trObj.childNodes[j];
             for(z=0;z<tdObj.childNodes.length;z++){
             var txtObj=tdObj.childNodes[z];
             if(txtObj.value  == "")
                {
                   txtObj.style.backgroundColor="F9685D";
                  }
   
   
   
               }
   
   
   
          }
   
       }
   
}