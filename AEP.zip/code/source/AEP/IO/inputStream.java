package AEP.IO;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2005-04-14 15:11:22 EDT
// -----( ON-HOST: hqwhslas068.aepsc.com

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
// --- <<IS-END-IMPORTS>> ---

public final class inputStream

{
	// ---( internal utility methods )---

	final static inputStream _instance = new inputStream();

	static inputStream _newInstance() { return new inputStream(); }

	static inputStream _cast(Object o) { return (inputStream)o; }

	// ---( server methods )---




	public static final void close (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(close)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] object:0:required inputStream
		IDataCursor idc = pipeline.getCursor();
		java.io.InputStream is = (java.io.InputStream)IDataUtil.get(idc, "inputStream");
		idc.destroy();
		
		try
		{
		    is.close();
		}
		catch (java.io.IOException ioe)
		{
		    throw new ServiceException(ioe);
		}
		// --- <<IS-END>> ---

                
	}
}

