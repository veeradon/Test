package AEP;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2005-10-18 17:33:03 EDT
// -----( ON-HOST: P3031248.aepsc.com

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import com.wm.app.b2b.server.ServerAPI;
import com.wm.app.b2b.server.Session;
import com.wm.app.b2b.server.InvokeState;
import com.wm.app.b2b.server.User;
import com.wm.app.b2b.server.Service;
import java.io.*;
import com.wm.lang.ns.*;
// --- <<IS-END-IMPORTS>> ---

public final class serverInfo

{
	// ---( internal utility methods )---

	final static serverInfo _instance = new serverInfo();

	static serverInfo _newInstance() { return new serverInfo(); }

	static serverInfo _cast(Object o) { return (serverInfo)o; }

	// ---( server methods )---




	public static final void getConfigPath (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getConfigPath)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:optional packageName
		// [o] field:0:required configPath
	IDataCursor idcPipeline = pipeline.getCursor();

	//Input variable
	String packageName = null;

	// If a package name was passed, use it.  Otherwise, derive it.
	if (!idcPipeline.first("packageName") || (packageName = (String) idcPipeline.getValue()) == "")
	{
		NSService callingService = Service.getCallingService();
		if(callingService != null)
		{
		  NSPackage pkg = callingService.getPackage();
		  packageName = pkg.getName();
		}
		else //Must have been called directly from Developer
		{
			packageName = Service.getPackageName();  //This package
		}
	}

	File fileConfigDir = ServerAPI.getPackageConfigDir(packageName);

	StringBuffer configPath = new StringBuffer(fileConfigDir.getPath()+File.separator);

	//insert the configPath into the pipeline
	if(idcPipeline.first("configPath"))
		idcPipeline.setValue(configPath.toString());
	else
		idcPipeline.insertAfter("configPath", configPath.toString());

	// Clean up IData cursors
	idcPipeline.destroy();

		// --- <<IS-END>> ---

                
	}



	public static final void getServerConfigDir (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getServerConfigDir)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [o] field:0:required serverConfigDir
		IDataCursor idcPipeline = pipeline.getCursor();
		
		String serverConfigDir = ServerAPI.getServerConfigDir().toString();
		
		if(idcPipeline.first("serverConfigDir")) idcPipeline.setValue(serverConfigDir);
		else idcPipeline.insertAfter("serverConfigDir", serverConfigDir);
		
		// Clean up IData cursors
		idcPipeline.destroy();
		
		// --- <<IS-END>> ---

                
	}



	public static final void getServerInformation (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getServerInformation)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [o] field:0:required serverName
		// [o] field:0:required primaryPort
		// [o] field:0:required currentPort
	IDataCursor idcPipeline = pipeline.getCursor();

	//Output variable
	String strServerName = ServerAPI.getServerName();
	int intCurrentPort = ServerAPI.getCurrentPort();

	// Added 10/17/2005
	IData listenerInfo = null;
	Integer intPrimaryPort = null;
	try
	{
		IData results = Service.doInvoke("wm.server.net.listeners", "getPrimaryListener", pipeline);
		IDataUtil.merge(results, pipeline);

	}
	catch(Exception e)
	{
		throw new ServiceException("Could not invoke wm.server.net.listeners:getPrimaryListener: " + e);
	}

	if (idcPipeline.first("primary"))
	{
		listenerInfo = (IData)idcPipeline.getValue();
		idcPipeline.delete();
	}
	IDataCursor idcListenerInfo = listenerInfo.getCursor();

	if (idcListenerInfo.first("port"))
	{
		intPrimaryPort = (Integer)idcListenerInfo.getValue();
	}
	idcListenerInfo.destroy();
	// end 10/17/2005


	//insert the serverName into the pipeline	
	idcPipeline.insertAfter("serverName", strServerName);

	// Added 10/17/2005
	idcPipeline.insertAfter("primaryPort", intPrimaryPort.toString());
	// end 10/17/2005

	//insert the currentPort into the pipeline	
	idcPipeline.insertAfter("currentPort", String.valueOf(intCurrentPort));

    // Clean up IData cursors
	idcPipeline.destroy();

		// --- <<IS-END>> ---

                
	}



	public static final void getUser (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getUser)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [o] field:0:required username
		//Get the current session
		Session currentSession = Service.getSession();
		
		//Get current user
		User user = currentSession.getUser();
		
		//Assign the username value to strUsername
		String strUsername = user.getName();
		
		//insert the username into the pipeline
		IDataCursor idcPipeline = pipeline.getCursor();
		idcPipeline.insertAfter("username", strUsername);
		// --- <<IS-END>> ---

                
	}



	public static final void ping (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(ping)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [o] field:0:required date
		IDataCursor pipelineCursor = pipeline.getCursor();
		IDataUtil.put( pipelineCursor, "date", (new java.util.Date()).toString());
		pipelineCursor.destroy();
		// --- <<IS-END>> ---

                
	}
}

