package AEP;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2005-10-17 14:11:32 EDT
// -----( ON-HOST: P3031248.aepsc.com

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.util.*;
import java.text.*;
// --- <<IS-END-IMPORTS>> ---

public final class string

{
	// ---( internal utility methods )---

	final static string _instance = new string();

	static string _newInstance() { return new string(); }

	static string _cast(Object o) { return (string)o; }

	// ---( server methods )---




	public static final void concatMultipleStrings (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(concatMultipleStrings)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:1:required inStringList
		// [o] field:0:required outString
		
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		String[]	inStringList = IDataUtil.getStringArray( pipelineCursor, "inStringList" );
		pipelineCursor.destroy();
		StringBuffer outString = new StringBuffer();
		try
		{
			
			for (int i = 0; i < inStringList.length ; i++)
			{
		    		outString.append(inStringList[i]);
			}
		} catch (NullPointerException e1)
		{
			throw new ServiceException("Input string list is blank.");
		}
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "outString", outString.toString() );
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void sortStrings (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(sortStrings)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:1:required stringList
		// [i] field:0:optional caseInsensitive {"false","true"}
		// [i] field:0:optional reverseOrder {"false","true"}
		// [o] field:1:required sortedStrings
		//define input variables
		IDataCursor idc = pipeline.getCursor();
		String caseInsensitive = "false";
		String reverseOrder = "false";
		
		String stringList[] = IDataUtil.getStringArray(idc, "stringList");
		
		if((stringList != null) && (stringList.length > 0))
		{
		    String sortedStrings[] = (String[]) stringList.clone();  //Make a copy of the original string list
		
		    if(idc.first("caseInsensitive")) caseInsensitive = (String) idc.getValue();
		    if(idc.first("reverseOrder")) reverseOrder = (String) idc.getValue();
		
		    //Note that caseInsensitive takes precedence, and must be false (default)
		    //to obtain a reverse order sort.
		
		    if(caseInsensitive.equals("true"))
		      Arrays.sort(sortedStrings, String.CASE_INSENSITIVE_ORDER);
		    else if(reverseOrder.equals("true"))
		      Arrays.sort(sortedStrings, Collections.reverseOrder());
		    else
		      Arrays.sort(sortedStrings); //Sort it, natural order
		
		    if(idc.first("sortedStrings")) idc.setValue(sortedStrings);
		    else idc.insertAfter("sortedStrings", sortedStrings); //Place it in the pipeline
		}
		
		idc.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void strReplace (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(strReplace)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required inString
		// [i] field:0:optional replace
		// [i] field:0:optional replaceWith
		// [o] field:0:required outString
		//define input variables
		IDataCursor idcPipeline = pipeline.getCursor();
		String inString=null;
		String replace=null;
		String replaceWith=null;
		
		//Output Variables
		String outString=null;
		
		//Remove all ocurrences of the target variables from the pipeline...
		while(idcPipeline.first("outString"))
		  idcPipeline.delete();
		
		
		if (idcPipeline.first("inString"))
		{
			inString = (String) idcPipeline.getValue();
		}
		else
		{
			idcPipeline.destroy();
			return;
		}
		
		if (idcPipeline.first("replace"))
		{
			replace = (String) idcPipeline.getValue();
		}
		
		if (idcPipeline.first("replaceWith"))
		{
			replaceWith = (String) idcPipeline.getValue();
		}
		
		// Assume that no changes will be made.
		outString = inString;
		
		// Create a sandbox in which to make any changes.
		StringBuffer strBuff = new StringBuffer(inString);
		
		int start;
		
		if (replace != null && replace.length() > 0) // Substring to search for
			{
			int howmany = replace.length ();
		
			// Replace all occurrences.
		
			while ((start = outString.indexOf (replace)) != -1)
				{
				if(replaceWith == null || replaceWith.length() == 0)
					strBuff.delete(start, start + howmany);
				else
					strBuff.replace (start, start + howmany, replaceWith);
				outString = strBuff.toString ();
				}
			}
		else
			{
			// No search target specified.  Look for any occurrences of the whitespace escape 
			// sequences "\t", "\r", or "\n", and replace them with the control-character
			// equivalents.
		
			boolean bChanged;
			start = 0;
		
			while ((start = outString.indexOf ('\\', start)) != -1)
				{
				bChanged = false;
				char c = outString.charAt (start + 1);
		
				if (c == 't')
					{
					strBuff.replace (start, start + 2, "\t");
					bChanged = true;
					}
				else if (c == 'r')
					{
					strBuff.replace (start, start + 2, "\r");
					bChanged = true;
					}
				else if (c == 'n')
					{
					strBuff.replace (start, start + 2, "\n");
					bChanged = true;
					}
				else
					{
					// A legitimate backslash!  Who'd'a thunk it.  Skip over it and
					// keep on going.
		
					++ start;
					}
		
				if (bChanged)
					{
					outString = strBuff.toString();
					}
				}
			}
		
		idcPipeline.insertAfter("outString", outString);
		
		idcPipeline.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void truncate (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(truncate)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required inString
		// [i] field:0:required length
		// [o] field:0:required value
		IDataCursor pipelineCursor = pipeline.getCursor();
		String inString = IDataUtil.getString( pipelineCursor, "inString" );
		int length = IDataUtil.getInt(pipelineCursor, "length", Integer.MIN_VALUE);
		
		if(length != Integer.MIN_VALUE)
		{
		  if(inString != null)
		  {
		    if(length < 0)
		    {
		      length = -1*length;
		      if(length >= inString.length())
		        inString = "";
		      else
		        inString = inString.substring(0, inString.length()-length);
		    }
		    else if(inString.length() >= length)
		    {
		      inString = inString.substring(0, length);
		    }
		  }
		}
		IDataUtil.put(pipelineCursor, "value", inString);
		pipelineCursor.destroy();
		// --- <<IS-END>> ---

                
	}
}

