package AEPTestSuite;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2017-11-01 10:26:13 EDT
// -----( ON-HOST: wmmwq01.aepsc.com

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.util.*;
import com.wm.app.b2b.server.*;
import com.webmethods.sc.directory.*;
// --- <<IS-END-IMPORTS>> ---

public final class util

{
	// ---( internal utility methods )---

	final static util _instance = new util();

	static util _newInstance() { return new util(); }

	static util _cast(Object o) { return (util)o; }

	// ---( server methods )---




	public static final void getUserName (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getUserName)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [o] field:0:required username
		IDataCursor pipelineCursor = pipeline.getCursor();
		IDataUtil.put( pipelineCursor, "username", ((Service.getSession()).getUser()).getName() );
		pipelineCursor.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void preReprocess (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(preReprocess)>> ---
		// @sigtype java 3.5
		// [i] field:0:required fileName
		// [o] field:0:required rFileName
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	fileName = IDataUtil.getString( pipelineCursor, "fileName" );
			String sTemp= fileName.replace("_baseLine", " ");
			int sfile = sTemp.length();
			sTemp = sTemp.substring(0,(sfile-11));
			
		pipelineCursor.destroy();
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "rFileName", sTemp);
		//IDataUtil.put( pipelineCursor_1, "fileName", fileName);
		
		
		pipelineCursor_1.destroy();
			
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---










	
	// --- <<IS-END-SHARED>> ---
}

