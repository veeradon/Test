function FileData_Pairs(x)
{
x.t("2007","-2015");
x.t("-2015","software");
x.t("integration","server");
x.t("darmstadt","germany");
x.t("software","darmstadt");
x.t("online","help");
x.t("help","2007");
x.t("help","integration");
x.t("server","online");
}
