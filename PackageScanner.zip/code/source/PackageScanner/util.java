package PackageScanner;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2010-10-11 21:59:01 EDT
// -----( ON-HOST: 127.0.0.1

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.io.*;
import java.util.*;
import com.wm.util.coder.*;
import com.wm.app.b2b.server.*;
// --- <<IS-END-IMPORTS>> ---

public final class util

	implements FilenameFilter

{
	// ---( internal utility methods )---

	final static util _instance = new util();

	static util _newInstance() { return new util(); }

	static util _cast(Object o) { return (util)o; }

	// ---( server methods )---




	public static final void buildConfigDoc (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(buildConfigDoc)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		Hashtable flowStore=new Hashtable();
		Hashtable keyStore=new Hashtable();
		
		IDataCursor pipelineCursor = pipeline.getCursor();
			IData[]	configList = IDataUtil.getIDataArray( pipelineCursor, "configList" );
			if ( configList != null)
			{
				for ( int i = 0; i < configList.length; i++ )
				{
					IDataCursor configListCursor = configList[i].getCursor();
						String	flow = IDataUtil.getString( configListCursor, "flow" );
						String[] list = IDataUtil.getStringArray( configListCursor, "list" );
		                                Vector ck=new Vector();
		                                Vector st=new Vector();  
		                                for(int i1=0;i1<list.length;i1++)
		                                {
		                                   list[i1]=list[i1].trim();
		                                   int storeIndx=list[i1].indexOf("storeName::");
		                                   int configIndx=list[i1].indexOf("configKey::");
		                                   if(storeIndx != -1)  
		                                    {
		                                      String storeName=list[i1].substring(11,list[i1].length()); 
		                                      if(!st.contains(storeName))  
		                                        st.addElement(storeName);
		                                    } 
		                                   if(configIndx != -1)
		                                    {
		                                      String configKey=list[i1].substring(11,list[i1].length()); 
		                                      if(!ck.contains(configKey))  
		                                        ck.addElement(configKey);
		                                    } 
		                                   
		                                }
		                                
		                                String storeNames="";
		                                for(int i12=0;i12<st.size();i12++)
		                                  storeNames=storeNames+(String)st.elementAt(i12);
		                              
		                                if(!keyStore.containsKey(storeNames))
		                                 { 
		                                    
		                                    Vector v_12=new Vector();
		                                    for(int i12=0;i12<ck.size();i12++)
		                                     { 
		                                       if(!v_12.contains(ck.elementAt(i12)))
		                                         v_12.addElement(ck.elementAt(i12));
		                                     }
		                                     keyStore.put(storeNames,v_12);
		                                 } 
		                                 else
		                                 {
		                                    Vector v_2=(Vector)keyStore.get(storeNames);
		                                    for(int i13=0;i13<ck.size();i13++)
		                                     { 
		                                       if(!v_2.contains(ck.elementAt(i13)))
		                                         v_2.addElement(ck.elementAt(i13));
		                                     }
		                                 }  
		
		                                if(!flowStore.containsKey(storeNames))
		                                 { 
		                                    Vector v_3=new Vector();
		                                    v_3.addElement(flow);  
		                                    flowStore.put(storeNames,v_3);
		                                 } 
		                                 else
		                                 {
		                                    Vector v_31=(Vector)flowStore.get(storeNames);
		                                    v_31.addElement(flow);
		                                 }  
		                        st.clear();
		                        ck.clear(); 
					configListCursor.destroy();
				}
			}
		pipelineCursor.destroy();
		IData[]	configs =null;
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		int counter=0;
		if(flowStore.size() >0)
		{
			configs = new IData[flowStore.size()];
			Enumeration enum_2=flowStore.keys();
		        while(enum_2.hasMoreElements())
		        { 
		          String key=(String)enum_2.nextElement();
		          configs[counter] = IDataFactory.create();
		          IDataCursor configsCursor = configs[counter].getCursor();
		          IDataUtil.put( configsCursor, "storeName", key ); 
		          String[]	keyList=null;
		          Vector v_11=(Vector)keyStore.get(key);
		          if(v_11.size()>0)
		          {
		             keyList =new String[v_11.size()];
		             v_11.toArray(keyList);
		             
		          }  
		          IDataUtil.put( configsCursor, "keyList", keyList );
		
		          String[] flow_1=null;
		          
		          Vector v_12=(Vector)flowStore.get(key);
		          if(v_12.size()>0)
		          {
		             flow_1 =new String[v_12.size()];
		             v_12.toArray(flow_1);
		             
		          }  
		          IDataUtil.put( configsCursor, "flow",  flow_1  );    
		          counter++; 
		          configsCursor.destroy();
		        }
		}  
		keyStore.clear();
		keyStore=null;
		flowStore.clear();
		flowStore=null;
		IDataUtil.put( pipelineCursor_1, "configs", configs );
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void buildPkgDepList (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(buildPkgDepList)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:1:optional successors
		// [o] field:1:optional successors
		
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String[]	successors = IDataUtil.getStringArray( pipelineCursor, "successors" );
		pipelineCursor.destroy();
		
		
		  for (int i=0;i<successors.length;i++){
		        successors[i] =  successors[i].substring(0, successors[i].indexOf(";"));
		   }
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		
		
		IDataUtil.put( pipelineCursor_1, "successors", successors );
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void fileExists (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(fileExists)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required filename
		// [o] object:0:required exists
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	filename = IDataUtil.getString( pipelineCursor, "filename" );
		pipelineCursor.destroy();
		 
		File f=new File(filename);
		boolean fileexists=f.exists();
		
		
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "exists", Boolean.valueOf(fileexists));
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void generateHtmlscript (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(generateHtmlscript)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] record:0:required document
		// [i] - field:1:required flows
		// [i] field:0:required key
		// [o] field:0:required htmlcontent
		IDataCursor pipelineCursor = pipeline.getCursor();
		int elementCount=0; 
		String	key = IDataUtil.getString( pipelineCursor,"key" );
		IData	document = IDataUtil.getIData( pipelineCursor,"document" );
		  try
		    {
		      cls=Class.forName("com.wm.data.IData"); 
		      clsArray=((Object)(new IData[2])).getClass();
		      strArray=((Object)(new String[2])).getClass();
		
		    }catch(Exception e) {
		                           throw (new ServiceException(e.toString()));
		                        }
		
		String htmlcontent=null;
		            
		   if ( document != null)     
		    {
		        StringBuffer sbuf=new StringBuffer();
		        String k2=key;
		        //sbuf.append("<TR><td class=oddrow-l valign=top width=10%><IMG id=img"+k2+" src=images/tree_minus.gif  onClick=collapse('"+k2+"');>&nbsp;"+k2+"</TD>");
		        //sbuf.append("<td class=oddrow-l><TABLE>");
		        sbuf.append("<TR><TD><DIV id="+k2+" style=display:block><TABLE>");  
		        genHtml(document,sbuf,k2);
		        sbuf.append("</TABLE></DIV></TD><TR>");
		        htmlcontent=sbuf.toString();
		    }
		pipelineCursor.destroy();
		IDataCursor pipelineCursor_1 = pipeline.getCursor();   
		IDataUtil.put(pipelineCursor_1,"htmlcontent",htmlcontent); 
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getACLList (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getACLList)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required packageName
		// [o] field:1:required aclList
		
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	packageName = IDataUtil.getString( pipelineCursor, "packageName" );
		pipelineCursor.destroy();
		
		String[] aclList=null;
		if(aclStore.containsKey(packageName))
		{
		  Vector v_1=(Vector)aclStore.get(packageName);
		  if(v_1.size() >0)
		   {
		     aclList=new String[v_1.size()];
		     v_1.toArray(aclList);
		   }
		}
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "aclList", aclList );
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getBrokerDocDetail (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getBrokerDocDetail)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required data
		// [i] field:0:required serviceName
		// [o] field:1:required docList
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	data = IDataUtil.getString( pipelineCursor, "data" );
		pipelineCursor.destroy();
		
		Vector splitData=new Vector();
		String stTag="<value name=\"brokerEventTypeName\">";
		String endTag="</value>";
		splitDataOnTagName(data,stTag,endTag,splitData);
		String[] docList=null;
		if(splitData.size()>0)
		{
		        
			docList=new String[splitData.size()];
		        for(int i=0;i<splitData.size();i++)
		         {
		            docList[i]=getTagValue((String)splitData.elementAt(i),stTag,endTag);
		         } 
		
		}
		
		
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "docList", docList );
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getConnectionDetails (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getConnectionDetails)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] object:0:required bytes
		// [o] record:0:required pipeline
		// [o] field:0:required errorMessage
		IDataCursor pipelineCursor = pipeline.getCursor();
			byte[]	bytes = (byte[])IDataUtil.get( pipelineCursor, "bytes" );
		pipelineCursor.destroy();
		
		IData d=null;
		String errorMessage=null;
		
		if(bytes != null)
		{
		  try
		   {
		     IDataBinCoder coder = new IDataBinCoder();
		     d = coder.decode(new ByteArrayInputStream(bytes));
		
		   }catch(Exception e){
		                          errorMessage=e.toString();
		                      }
		
		}
		else
		 errorMessage="No Pipline data found for this step";
		
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "pipeline",d);
		IDataUtil.put( pipelineCursor_1, "errorMessage",errorMessage);
		pipelineCursor_1.destroy();
		
		
		// --- <<IS-END>> ---

                
	}



	public static final void getDependenciesList (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getDependenciesList)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:1:required SLIST
		// [i] field:0:required reqPackage
		// [o] field:1:optional depErrFlows
		// [o] field:0:optional pkgAlerts
		Hashtable hStore=new Hashtable();
		Vector vTemp = new Vector();
		Vector refStore=new Vector();
		
		IDataCursor pipelineCursor = pipeline.getCursor();
			String[] SLIST = IDataUtil.getStringArray( pipelineCursor, "SLIST" );
		        String	reqPackage = IDataUtil.getString( pipelineCursor, "reqPackage" );
		pipelineCursor.destroy();
		
		String[] svcs = new String[2];
		String packageName = "";
		
		for(int i=0;i<SLIST.length;i++)
		{
		  String[] strTemp=splitString(SLIST[i]);
		  svcs =  isValidNS(SLIST[i],"true");
		  
		  packageName = svcs[1];
		 
		  if(svcs[0].equals("false"))
		       {
		        vTemp.add(SLIST[i]);
		                  
		       }
		/* if( (packageName == null) || (packageName == "")){
		      packageName = strTemp[0];
		     }*/
		
		  if ((reqPackage.equals(packageName)) || (packageName == null) || (packageName == "")){
		     // exclude from the list
		    }
		  else{
			if(!refStore.contains(packageName)){
		     
		  	 if(hStore.containsKey(packageName))
		    	  {
		      		Vector v_2=(Vector)hStore.get(packageName); 
				      if(! v_2.contains(SLIST[i]))
				         v_2.addElement(SLIST[i]);    
			       
			 }
			else
			 { 
				Vector v_1=new Vector();
				v_1.addElement(SLIST[i]); 
				hStore.put(packageName,v_1);
		   	}
		
		   }//vector pkgName
		  }//else
		}//for
		
		
		refStore.clear();
		refStore=null;
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IData[]	dependencies = new IData[hStore.size()];
		Enumeration enum_1=hStore.keys();
		int counter=0;
		
		while(enum_1.hasMoreElements())
		{
		  String key=(String)enum_1.nextElement();
		 
		  dependencies[counter] = IDataFactory.create();
		  IDataCursor dependenciesCursor = dependencies[counter].getCursor();
		  
		  IDataUtil.put( dependenciesCursor, "packageName", key);
		    
		      String v = getVersion(key);
		                IDataUtil.put( dependenciesCursor, "packageVersion", v);
		           
		  
		  Vector v_3=(Vector)hStore.get(key);
		  String[]   flows = new String[v_3.size()];
		  v_3.toArray(flows);
		
		  IDataUtil.put( dependenciesCursor, "flows", flows );
		  dependenciesCursor.destroy();
		  
		  counter++;
		}
		hStore.clear();
		hStore=null;
		
		if(vTemp.size()>0){
		String [] depErrFlows = new String[vTemp.size()];
		IDataUtil.put( pipelineCursor_1, "depErrFlows", vTemp.toArray(depErrFlows) );
		IDataUtil.put( pipelineCursor_1, "pkgAlerts", "Missing Package Reference" );
		}
		vTemp.clear();
		vTemp = null;
		IDataUtil.put( pipelineCursor_1, "dependencies", dependencies );
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getDirList (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getDirList)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required filename
		// [o] object:0:required isDir
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	filename = IDataUtil.getString( pipelineCursor, "filename" );
		pipelineCursor.destroy();
		 
		File f=new File(filename);
		boolean isDir=f.isDirectory();
		
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "isDir", Boolean.valueOf(isDir));
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getDistinctList (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getDistinctList)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:1:required list
		// [o] field:1:required distinctList
		Vector dataStore=new Vector();
		IDataCursor pipelineCursor = pipeline.getCursor();
			String[]	list = IDataUtil.getStringArray( pipelineCursor, "list" );
		pipelineCursor.destroy();
		
		for(int i=0;i<list.length;i++)
		{
		  if(!dataStore.contains(list[i]))
		   {
		     dataStore.addElement(list[i]);
		   } 
		
		}
		
		String[] distinctList=null;
		if(dataStore.size()>0)
		{
		    distinctList=new String[dataStore.size()];
		    dataStore.toArray(distinctList);
		}
		dataStore.clear();
		dataStore=null;
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "distinctList", distinctList );
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getFilePath (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getFilePath)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required serviceName
		// [o] field:0:required filepath
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	serviceName = IDataUtil.getString( pipelineCursor, "serviceName" );
		pipelineCursor.destroy();
		
		int indx=serviceName.indexOf(":");
		String ndName=serviceName.substring((indx+1),serviceName.length());
		String folderData=serviceName.substring(0,indx);
		StringTokenizer stk=new StringTokenizer(folderData,".");
		String[] folderList=new String[stk.countTokens()];
		int counter=0;
		while(stk.hasMoreTokens())
		{
		  folderList[counter]=(String)stk.nextToken();
		  counter++;
		}
		
		String filepath="./packages/"+folderList[0]+"/ns";
		for(int i=0;i<folderList.length;i++)
		{
		  filepath=filepath+"/"+folderList[i];
		}
		
		filepath=filepath+"/"+ndName+"/node.ndf";
		
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "filepath",filepath);
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getFileType (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getFileType)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required filename
		// [o] field:0:required type
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	filename = IDataUtil.getString( pipelineCursor, "filename" );
		pipelineCursor.destroy();
		
		String type="xml";
		if((filename.indexOf(".xml")) == -1)
		 type="ndf";  
		
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "type", type);
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getFlowMetaData (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getFlowMetaData)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required data
		// [i] field:0:required packageName
		// [o] field:1:required SERVICELIST
		// [o] field:1:required REFLIST
		// [o] field:1:required SYNCDOCLIST
		// [o] field:1:required CONINFO
		// [o] field:1:required DATA
		// [o] field:1:required flowAlert
		// [o] field:1:required varAlert
		// [o] field:1:required config
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	data = IDataUtil.getString( pipelineCursor, "data" );
		        String	packageName = IDataUtil.getString( pipelineCursor, "packageName" ); 
		pipelineCursor.destroy();
		 
		Vector flowAlertStore=new Vector();
		Vector varAlertStore=new Vector();
		Vector configObj=new Vector();
		String[] trigList=null;
		String[] refList_1=null;
		String trigData = "false";
		Vector splitData=new Vector();
		String stTag="<INVOKE";
		String endTag="</INVOKE>";
		splitDataOnTagName(data,stTag,endTag,splitData);
		String[] invokeList=null;
		if(splitData.size()>0)
		{
			invokeList=new String[splitData.size()];
			splitData.toArray(invokeList);
		}
		
		
		splitData.clear();
		
		String stParentTag="<value name=\"node_type\">";
		
		String endParentTag="</value>";
		splitDataOnTagName(data,stParentTag,endParentTag,splitData);
		
		if(splitData.size()>0){
		  Vector isWmTrigStore=new Vector();
			for(int k3=0;k3<splitData.size();k3++)
			{
			  splitDataOnTagName((String)splitData.elementAt(k3),stParentTag,endParentTag,isWmTrigStore,packageName,false,flowAlertStore);
			}
		        if(isWmTrigStore.size() >0)
		        {
				trigList=new String[isWmTrigStore.size()];
				isWmTrigStore.toArray(trigList);
		                 trigData = "true";
		        }
		}
		
		
		  if(trigData.equals("true")){
		     if(trigList[0].equals("webMethods/trigger")){
		      splitData.clear();
		     stTag="<value name=\"serviceName\">";
		     stTag = stTag.trim();
		     endTag="</value>";
		     splitDataOnTagName(data,stTag,endTag,splitData);
		
		 
		       if(splitData.size()>0)
		      {
			Vector refStore_1=new Vector();
			for(int k3=0;k3<splitData.size();k3++)
			{
			  splitDataOnTagName((String)splitData.elementAt(k3),stTag,endTag,refStore_1,packageName,false,flowAlertStore);
			}
		
		      stTag = stTag="<value name=\"messageType\">";
		      endTag="</value>";
		      splitDataOnTagName(data,stTag,endTag,splitData);
		       for(int k3=0;k3<splitData.size();k3++)
			{
			  splitDataOnTagName((String)splitData.elementAt(k3),stTag,endTag,refStore_1,packageName,false,flowAlertStore);
			}
		
		        if(refStore_1.size() >0)
		        {
				refList_1=new String[refStore_1.size()];
				refStore_1.toArray(refList_1);
		        }
		}
		}
		
		if(refList_1!=null){
		refList_1 = getPackages(refList_1);
		}
		
		}
		
		
		
		
		
		splitData.clear();
		stTag="<MAPINVOKE";
		endTag="</MAPINVOKE>";
		splitDataOnTagName(data,stTag,endTag,splitData);
		String[] mapInvokeList=null;
		if(splitData.size() > 0)
		{
			mapInvokeList=new String[splitData.size()];
			splitData.toArray(mapInvokeList);
		}
		
		
		splitData.clear();
		stTag="<MAPSET ";
		endTag="</MAPSET>";
		splitDataOnTagName(data,stTag,endTag,splitData);
		String[] mapList=null;
		String[] dataList=null;
		Vector dObjList=new Vector();
		if(splitData.size()>0)
		{
			mapList=new String[splitData.size()];
			splitData.toArray(mapList);
		        Vector mStore=new Vector();
		        stTag="<DATA ";
		        endTag="</DATA>";
		        for(int q11=0;q11<mapList.length;q11++)
		        {
		          splitDataOnTagName(mapList[q11],stTag,endTag,mStore);
		          if(mStore.size()>0)
			  { 
			       	dataList=new String[mStore.size()];
			 	mStore.toArray(dataList); 
				stTag="<Values ";
				endTag="</Values>";
				Vector vStore=new Vector(); 
				for(int q1=0;q1< dataList.length;q1++)
				{ 
				   splitDataOnTagName(dataList[q1],stTag,endTag,vStore); 
			           if(vStore.size() >0)
			            {
			               dataList=new String[vStore.size()];
			               vStore.toArray(dataList); 
				       for(int q2=0;q2<dataList.length;q2++)
				          {
		                                String fieldName=getTagValue(dataList[q2],"<value name=\"field_name\">","</value>");
		                                if(fieldName==null)
		                                   fieldName=getFieldName(mapList[q11]);
		                                String val=getTagValue(dataList[q2],"<value name=\"xml\">","</value>");
		                                if(tbdVars.contains(fieldName))
		                                  varAlertStore.addElement(fieldName+"::"+val);
		                                if(configVars.contains(fieldName))
		                                  configObj.addElement(fieldName+"::"+val);
		             			dObjList.addElement(fieldName+"::"+val);
				          }
			            } 
				    vStore.clear();
		                }   
		 	  }
			  mStore.clear();
		      }     
		}
		
		if(dObjList.size() >0)
		{
		 	dataList=new String[dObjList.size()];
			dObjList.toArray(dataList); 
		} 
		
		splitData.clear();
		stTag="<value name=\"rec_ref\">";
		endTag="</value>";
		splitDataOnTagName(data,stTag,endTag,splitData);
		String[] refList=null;
		if(splitData.size()>0)
		{
			Vector refStore=new Vector();
			for(int k3=0;k3<splitData.size();k3++)
			{
			  splitDataOnTagName((String)splitData.elementAt(k3),stTag,endTag,refStore,packageName,false,flowAlertStore);
			}
		        if(refStore.size() >0)
		        {
				refList=new String[refStore.size()];
				refStore.toArray(refList);
		        }
		}
		
		splitData.clear();
		stTag="<value name=\"brokerEventTypeName\">";
		endTag="</value>";
		splitDataOnTagName(data,stTag,endTag,splitData);
		String[] syncDocList=null;
		if(splitData.size()>0)
		{
		        
			syncDocList=new String[splitData.size()];
		        for(int i=0;i<splitData.size();i++)
		         {
		            syncDocList[i]=getTagValue((String)splitData.elementAt(i),stTag,endTag);
		         } 
		
		}
		
		splitData.clear();
		stTag="<value name=\"IRTNODE_PROPERTY\">";
		endTag="</value>";
		splitDataOnTagName(data,stTag,endTag,splitData);
		String[] conList=null;
		if(splitData.size() > 0)
		{
			Vector conStore=new Vector();
			for(int k4=0;k4<splitData.size();k4++)
			{
			  splitDataOnTagName((String)splitData.elementAt(k4),stTag,endTag,conStore,packageName,false,flowAlertStore);
			}
		        if(conStore.size() >0)
		        {
				conList=new String[conStore.size()];
				conStore.toArray(conList);
		        }   
		}
		
		
		Vector dataStore=new Vector();
		stTag="SERVICE=";
		endTag="\"";
		if(invokeList != null)
		{
			for(int k=0;k<invokeList.length;k++)
			{ 
			  splitDataOnTagName(invokeList[k],stTag,endTag,dataStore,packageName,true,flowAlertStore);
			}
		}
		if(mapInvokeList != null)
		{
			for(int k1=0;k1<mapInvokeList.length;k1++)
			{ 
			  splitDataOnTagName(mapInvokeList[k1],stTag,endTag,dataStore,packageName,true,flowAlertStore);
			}
		}
		
		String[] serviceList=null;
		if(dataStore.size() > 0)
		{
			serviceList=new String[dataStore.size()];
			dataStore.toArray(serviceList);
		}
		
		String[] flowAlert=null;
		if(flowAlertStore.size()>0)
		{
		   flowAlert=new String[flowAlertStore.size()];
		   flowAlertStore.toArray(flowAlert);
		   flowAlertStore.clear();
		}
		flowAlertStore=null;
		
		String[] varAlert=null;
		if(varAlertStore.size()>0)
		{
		  varAlert=new String[varAlertStore.size()];
		  varAlertStore.toArray(varAlert);
		  varAlertStore.clear();
		}
		varAlertStore=null;
		
		String[] config=null;
		if(configObj.size() >0)
		{
		  config=new String[configObj.size()];  
		  configObj.toArray(config);
		  configObj.clear();
		}
		configObj=null;
		
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "SERVICELIST", serviceList );
		IDataUtil.put( pipelineCursor_1, "REFLIST", refList );
		IDataUtil.put( pipelineCursor_1, "SYNCDOCLIST", syncDocList);
		IDataUtil.put( pipelineCursor_1, "CONINFO", conList );
		IDataUtil.put( pipelineCursor_1, "DATA", dataList );
		IDataUtil.put( pipelineCursor_1, "flowAlert", flowAlert);
		IDataUtil.put( pipelineCursor_1, "varAlert", varAlert );
		IDataUtil.put( pipelineCursor_1, "config", config );
		IDataUtil.put( pipelineCursor_1, "TrigInvokeList", refList_1);
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getFlowName (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getFlowName)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required filePath
		// [o] field:0:required flowname
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	filePath = IDataUtil.getString( pipelineCursor, "filePath" );
		pipelineCursor.destroy();
		
		String flowname=filePath;
		
		int i=filePath.indexOf("/ns/");
		if(i != -1)
		 {
		   int j=filePath.lastIndexOf("/");
		   if( j== -1)
		     j= filePath.length();
		
		   flowname=filePath.substring((i+4),j);
		 }  
		
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "flowname", flowname );
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getFolderName (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getFolderName)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required nsString
		// [i] field:0:required idx
		// [o] field:0:required pFolder
		
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	nsString = IDataUtil.getString( pipelineCursor, "nsString" );
		        int	idx = Integer.parseInt(IDataUtil.getString( pipelineCursor, "idx" ));
		        
		         String temp = nsString.substring(idx+4);
		         idx = temp.indexOf("/");
		         String pFolder = temp.substring(0,idx);
		pipelineCursor.destroy();
		
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "pFolder", pFolder );
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getPackDetailsAsHtml (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getPackDetailsAsHtml)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required header
		// [i] field:0:required keyref
		// [i] field:0:required sourceISHost
		// [o] field:0:required htmlContent
		String htmlContent="<TABLE>";
		IDataCursor pipelineCursor = pipeline.getCursor();
		
			String	header = IDataUtil.getString( pipelineCursor, "header" );
		        String	keyref = IDataUtil.getString( pipelineCursor, "keyref" ); 
			String	sourceISHost = IDataUtil.getString( pipelineCursor, "sourceISHost" );
			
		        if(keyref.equals("pack"))
		 		//htmlContent=htmlContent+"<TH align=left>"+header+"</TH><TR><td class=oddcol-l>PackageName</td><td class=oddcol-l>Version</td><td class=oddcol-l>SVN-Version</td><td class=oddcol-l>Server</td><td class=oddcol-l>External Dependencies</td></TR>";
				htmlContent=htmlContent+"<TR align=left><td><B>"+header+"</B></td></TR><TR><td class=oddcol-l>PackageName</td><td class=oddcol-l>Version</td><td class=oddcol-l>SVN-Version</td><td class=oddcol-l>Server</td><td class=oddcol-l>External Dependencies</td></TR>";
		         else
		        	//htmlContent=htmlContent+"<TH align=left>"+header+"</TH><TR><td class=oddcol-l>Ref PackageName</td><td class=oddcol-l>Version</td><td class=oddcol-l>SVN-Version</td><td class=oddcol-l>Server</td><td class=oddcol-l>dependencies</td></TR>";
		                htmlContent=htmlContent+"<TR align=left><td><B>"+header+"</B></td></TR><TR><td class=oddcol-l>Ref PackageName</td><td class=oddcol-l>Version</td><td class=oddcol-l>SVN-Version</td><td class=oddcol-l>Server</td><td class=oddcol-l>dependencies</td></TR>";
		         
		          
		
			IData[]	dependencies = IDataUtil.getIDataArray( pipelineCursor, "dependencies" );
			if ( dependencies != null)
			{
				for ( int i = 0; i < dependencies.length; i++ )
				{
					IDataCursor dependenciesCursor = dependencies[i].getCursor();
						String	packageName = IDataUtil.getString( dependenciesCursor, "packageName" );
						String	packageVersion = IDataUtil.getString( dependenciesCursor, "packageVersion" );
		                                
						String[]	flows = IDataUtil.getStringArray( dependenciesCursor, "flows" );
		                                String[]	successors = IDataUtil.getStringArray( dependenciesCursor, "successors" );
		                    	dependenciesCursor.destroy();
		                        if(packageVersion==null){
		                        htmlContent=htmlContent+"<TR><td class=evenrow-l title=MissingPackageRef><font color=red>"+packageName+"</font></td><td class=evenrow-l>"+packageVersion+"</td><td class=evenrow-l><input type=text size=9 value = "+packageVersion+"></input></td><td class=evenrow-l><input type=text size=30 value =  "+sourceISHost+" ></input></td>";
					}
		                        else{
		 				htmlContent=htmlContent+"<TR><td class=evenrow-l>"+packageName+"</td><td class=evenrow-l>"+packageVersion+"</td><td class=evenrow-l><input type=text size=9 value = "+packageVersion+"></input></td><td class=evenrow-l><input type=text size=30 value =  "+sourceISHost+" ></input></td>";
		                         }
		                        htmlContent=htmlContent+"<td class=evenrow-l>";
		
		                        if(flows != null)
		                           htmlContent=htmlContent+"<table>"+genDhtml(flows,keyref+"_"+i)+"</table></td></TR>";
		                      
		                       // for external dependencies
		                           if(successors != null){
		                        //  htmlContent=htmlContent+"<BR>"+"<TH align=left></TH><TR><td class=oddcol-l>Explicit Package Dependencies</td><td class=oddcol-l>"+genDHtml(successors,keyref+"_"+i,"Packages")+"</td></TR>";
		                               htmlContent=htmlContent+"<table>"+genDHtml(successors,keyref+"_"+i,"Packages")+"</table></td></TR>";
		                                  
		                                                }
					
		                        
		                   
				}
			}
		
		pipelineCursor.destroy();
		htmlContent=htmlContent+"</TABLE><PRE>\n</PRE>";
		
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "htmlContent",htmlContent);
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getPackDetailsAsHtml_bkup (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getPackDetailsAsHtml_bkup)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required header
		// [i] field:0:required keyref
		// [o] field:0:required htmlContent
		String htmlContent="<TABLE>";
		IDataCursor pipelineCursor = pipeline.getCursor();
		
			String	header = IDataUtil.getString( pipelineCursor, "header" );
		        String	keyref = IDataUtil.getString( pipelineCursor, "keyref" ); 
		        htmlContent=htmlContent+"<TH align=left>"+header+"</TH><TR><td class=oddcol-l>PackageName</td><td class=oddcol-l>Version</td><td class=oddcol-l>SVN-Version</td><td class=oddcol-l>SVN-Path</td><td class=oddcol-l>Server</td><td class=oddcol-l>dependencies</td></TR>";
		
			IData[]	dependencies = IDataUtil.getIDataArray( pipelineCursor, "dependencies" );
			if ( dependencies != null)
			{
				for ( int i = 0; i < dependencies.length; i++ )
				{
					IDataCursor dependenciesCursor = dependencies[i].getCursor();
						String	packageName = IDataUtil.getString( dependenciesCursor, "packageName" );
						String	packageVersion = IDataUtil.getString( dependenciesCursor, "packageVersion" );
						String[]	flows = IDataUtil.getStringArray( dependenciesCursor, "flows" );
		                    	dependenciesCursor.destroy();
		
		                        htmlContent=htmlContent+"<TR><td class=evenrow-l>"+packageName+"</td><td class=evenrow-l>"+packageVersion+"</td><td class=evenrow-l><input type=text size=9 value = "+packageVersion+"></input></td><td class=evenrow-l><input type=text size=40></input></td><td class=evenrow-l><input type=text size=15></input></td>";
		                        htmlContent=htmlContent+"<td class=evenrow-l>";
		
		                        if(flows != null)
		                           htmlContent=htmlContent+"<table>"+genDhtml(flows,keyref+"_"+i)+"</table></td></TR>";
		                        else
		                           htmlContent=htmlContent+"&nbsp;</td></TR>";
		                   
				}
			}
		
		pipelineCursor.destroy();
		htmlContent=htmlContent+"</TABLE><PRE>\n</PRE>";
		
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "htmlContent",htmlContent);
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getPackage (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getPackage)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:1:required refList
		// [o] field:1:required packageName
		  
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String[]	refList = IDataUtil.getStringArray( pipelineCursor, "refList" );
		pipelineCursor.destroy();
		
		int sList = refList.length;
		String[]	packageName = new String[sList];
		for (int i=0;i<sList;i++){
		packageName[i] = getPkgName(refList[i]);
		}
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		String[]	package_1 = new String[1];
		package_1[0] = "package";
		IDataUtil.put( pipelineCursor_1, "packageName", packageName);
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getServer (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getServer)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [o] field:0:required serverName
		// [o] field:0:required primaryPort
		// [o] field:0:required currentPort
	IDataCursor idcPipeline = pipeline.getCursor();

	//Output variable
	String strServerName = ServerAPI.getServerName();
	int intCurrentPort = ServerAPI.getCurrentPort();

	// Added 10/17/2005
	IData listenerInfo = null;
	Integer intPrimaryPort = null;
	try
	{
		IData results = Service.doInvoke("wm.server.net.listeners", "getPrimaryListener", pipeline);
		IDataUtil.merge(results, pipeline);

	}
	catch(Exception e)
	{
		throw new ServiceException("Could not invoke wm.server.net.listeners:getPrimaryListener: " + e);
	}

	if (idcPipeline.first("primary"))
	{
		listenerInfo = (IData)idcPipeline.getValue();
		idcPipeline.delete();
	}
	IDataCursor idcListenerInfo = listenerInfo.getCursor();

	if (idcListenerInfo.first("port"))
	{
		intPrimaryPort = (Integer)idcListenerInfo.getValue();
	}
	idcListenerInfo.destroy();
	// end 10/17/2005


	//insert the serverName into the pipeline	
	idcPipeline.insertAfter("serverName", strServerName);

	// Added 10/17/2005
	idcPipeline.insertAfter("primaryPort", intPrimaryPort.toString());
	// end 10/17/2005

	//insert the currentPort into the pipeline	
	idcPipeline.insertAfter("currentPort", String.valueOf(intCurrentPort));

    // Clean up IData cursors
	idcPipeline.destroy();

		// --- <<IS-END>> ---

                
	}



	public static final void getTagValue (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getTagValue)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required data
		// [i] field:0:required stTag
		// [i] field:0:required endTag
		// [o] field:0:required value
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	data = IDataUtil.getString( pipelineCursor, "data" );
			String	stTag = IDataUtil.getString( pipelineCursor, "stTag" );
			String	endTag = IDataUtil.getString( pipelineCursor, "endTag" );
		pipelineCursor.destroy();
		
		Vector splitData=new Vector();
		splitDataOnTagName(data,stTag,endTag,splitData);
		String value=(String)splitData.elementAt(0);
		int i1=value.indexOf(stTag)+stTag.length();
		int i2=value.indexOf(endTag);
		
		value=value.substring(i1,i2);
		
		splitData.clear();
		splitData=null;
		
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "value",value);
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getUnitqueList (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getUnitqueList)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:1:required list
		// [o] field:1:required distinctList
		Vector dataStore=new Vector();
		IDataCursor pipelineCursor = pipeline.getCursor();
			String[]	list = IDataUtil.getStringArray( pipelineCursor, "list" );
		pipelineCursor.destroy();
		
		for(int i=0;i<list.length;i++)
		{
		
		  
		  if(!dataStore.contains(list[i].trim()))
		   {
		     dataStore.addElement(list[i]);
		   } 
		
		}
		
		String[] distinctList=null;
		if(dataStore.size()>0)
		{
		    distinctList=new String[dataStore.size()];
		    dataStore.toArray(distinctList);
		}
		dataStore.clear();
		dataStore=null;
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "distinctList", distinctList );
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getXMLFileList (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getXMLFileList)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required path
		// [o] field:1:required xmlfilePaths
		Vector vnum=new Vector();
		
		String[] xmlfilePaths = null;
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	path = IDataUtil.getString( pipelineCursor, "path" );
		pipelineCursor.destroy();
		
		getXMLFiles(path,vnum);
		xmlfilePaths=new String[vnum.size()];
		vnum.toArray(xmlfilePaths);
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "xmlfilePaths", xmlfilePaths );
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void isSVNFile (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(isSVNFile)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required fileName
		// [o] field:0:required isSVNFile
		String isSVNFile = "false";
		
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	fileName = IDataUtil.getString( pipelineCursor, "fileName" );
		        int idx = fileName.indexOf("/.svn/");
		          if(idx>0)
		              isSVNFile = "true";
		pipelineCursor.destroy();
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "isSVNFile", isSVNFile);
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void isValidNs (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(isValidNs)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required nsName
		// [i] field:0:required getPkgName {"true","false"}
		// [o] field:0:optional pkgName
		// [o] field:0:required isValid
		String isValid = "true";
		 IDataCursor idc = pipeline.getCursor();   
		 String nsNameStr = IDataUtil.getString(idc, "nsName");   
		 String getPkgName = IDataUtil.getString(idc, "getPkgName");   
		 com.wm.lang.ns.NSName nsname = com.wm.lang.ns.NSName.create(nsNameStr);  
		  com.wm.app.b2b.server.ns.Namespace namesp = com.wm.app.b2b.server.ns.Namespace.current();  
		  com.wm.lang.ns.NSNode nsnode = namesp.getNode(nsname); 
		   if(nsnode != null) {
		        if(getPkgName.equals("true"))
		      	 IDataUtil.put(idc, "pkgName", nsnode.getPackage().getName());
		         }
		    else{
		           isValid = "false"; 
		        }
		
		   IDataUtil.put(idc, "isValid", isValid);
		
		   idc.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void isWmPackage (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(isWmPackage)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required packageName
		// [o] field:0:required isWmPkg
		
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	packageName = IDataUtil.getString( pipelineCursor, "packageName" );
		boolean bol = packageName.startsWith("Wm");
		pipelineCursor.destroy();
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "isWmPkg", bol+"");
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void sortStringList (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(sortStringList)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:1:required inStringList
		// [o] field:1:required outStringList
		IDataCursor pipelineCursor = pipeline.getCursor();
			String[]	inStringList = IDataUtil.getStringArray( pipelineCursor, "inStringList" );
		pipelineCursor.destroy();
		
		Arrays.sort(inStringList);
		
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "outStringList", inStringList );
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void storeAcls (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(storeAcls)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] record:1:required value
		// [i] - field:0:required @name
		// [i] - field:0:required *body
		aclStore.clear();
		IDataCursor pipelineCursor = pipeline.getCursor();
			IData[]	value = IDataUtil.getIDataArray( pipelineCursor, "value" );
			if ( value != null)
			{
				for ( int i = 0; i < value.length; i++ )
				{
					IDataCursor valueCursor = value[i].getCursor();
						String	name = IDataUtil.getString( valueCursor, "@name" );
						String	body = IDataUtil.getString( valueCursor, "*body" );
					valueCursor.destroy();
		                        if(!(body.equals("Internal")))
		                          addACLMapToStore(name,body);
		  
				}
			}
		pipelineCursor.destroy();
		
		// --- <<IS-END>> ---

                
	}



	public static final void stringListToString (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(stringListToString)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:1:required inStringList
		// [i] field:0:optional delimiter
		// [i] field:0:optional quoted {"false","true"}
		// [i] field:0:optional quoteType {",'"}
		// [o] field:0:required outString
		 
		IDataCursor cursor = pipeline.getCursor();
		String[] stringList = IDataUtil.getStringArray(cursor, "inStringList");
		String delimiter = IDataUtil.getString(cursor, "delimiter");
		boolean quoted = false;
		String quoteType = "";
		String outString = "";
		
		if (stringList != null)
		{
		  if (delimiter == null)
		  {
		    delimiter = ",";
		  }
		
		  if (cursor.first("quoted"))
		  {
		    quoted = Boolean.valueOf((String) cursor.getValue()).booleanValue();
		  }
		
		  if (cursor.first("quoteType"))
		  {
		
		    quoteType = (String) cursor.getValue();
		  }
		  StringBuffer outStringBuff = new StringBuffer();
		  int length = stringList.length - 1;
		  int len = 0;
		
		  for (int i = 0; i < length; i++)
		  {
		
		    outStringBuff = outStringBuff.append(stringList[i]);
		    if (quoted)
		    {
		      outStringBuff = outStringBuff.insert(len, quoteType).append(quoteType);
		    }
		    outStringBuff = outStringBuff.append(delimiter);
		    len = len + stringList[i].length() + 3;
		  }
		  outStringBuff = outStringBuff.append(stringList[length]);
		  if (quoted)
		  {
		    outStringBuff = outStringBuff.insert(len, quoteType).append(quoteType);
		  }
		  outString = outStringBuff.toString();
		  IDataUtil.put(cursor, "outString", outString);
		}
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	private static Class cls=null; 
	private static Class clsArray=null;
	private static Class strArray=null;
	private static String[] ignoreList={"wm.","pub."};
	private static Vector tdbFlows=new Vector();
	private static Vector tbdVars=new Vector();
	private static Vector configVars=new Vector();
	private static Hashtable aclStore=new Hashtable();
	
	private static FilenameFilter ffilter=(FilenameFilter)(new PackageScanner.util());
	private static String[] ids={"unitID","fuelName"};
	
	static{
			tdbFlows.addElement("pub.flow:savePipeline");
			tdbFlows.addElement("pub.flow:restorePipeline");
			tdbFlows.addElement("pub.flow:savePipelineToFile");
			tdbFlows.addElement("pub.flow:restorePipelineFromFile");
			tdbFlows.addElement("pub.flow:debugLog");
			tdbFlows.addElement("pub.flow:tracePipeline");
	
	        tbdVars.addElement("address");
			tbdVars.addElement("environment");
			tbdVars.addElement("maxRetries");
			tbdVars.addElement("retryCount");
	       
	
	       		configVars.addElement("storeName");
	        	configVars.addElement("configKey");
	
	
	     };   
	
	public boolean accept(File dir,String filename)
	{
	  File f1=new File(dir+"/"+filename);
	  if( ! f1.isDirectory())
	  { 
	    int i=filename.indexOf(".xml");
	
	    if(i== -1)
	      i=filename.indexOf(".ndf");
	
	    if(i != -1)
	    {
	       int j=filename.indexOf(".bak");
	       if(j == -1) 
	         return true;
	       else
	         return false;
	    }
	    else
	      return false;
	  }
	  else
	    return true;
	
	}
	
	private static void getXMLFiles(String path,Vector vnum)
	{
	  File f=new File(path);
	  String[] fileList=f.list(ffilter);
	  for(int i=0;i<fileList.length;i++)
	   {
	         String tfile=path+fileList[i]+"/";
	         File tf=new File(tfile);
	         if(tf.isDirectory())
			     getXMLFiles(tfile,vnum); 
	         else  
	             vnum.addElement(path+fileList[i]);
	   } 
	  
	}
	
	private static void splitDataOnTagName(String data,String stTag,String endTag,Vector splitData)
	{
	  
	   int begIndx=data.indexOf(stTag);
	   
	   if(begIndx != -1)
	   {
	     data=data.substring(begIndx,data.length());
	     begIndx=0;
	     int endIndx=data.indexOf(endTag);
	     if(endIndx != -1)
	     {
	     	endIndx=endIndx+endTag.length();
	     	if(begIndx < endIndx){
	             
	        	splitData.addElement(data.substring(begIndx,endIndx));
	               
	             }
		     data=data.substring(endIndx,data.length());
	    	 splitDataOnTagName(data,stTag,endTag,splitData);
	     }
	     else
	     {
	         endIndx=data.length();
	         splitData.addElement(data.substring(begIndx,endIndx));
	     } 
	   }
	}
	
	private static void splitDataOnTagName(String data,String stTag,String endTag,Vector dataStore,String packageName,boolean addOneChar,Vector alertStore)
	{
	   int begIndx=data.indexOf(stTag);
	   if(begIndx != -1)
	   {
	    if(addOneChar)
	       data=data.substring((begIndx+stTag.length()+1),data.length());
	    else
	       data=data.substring((begIndx+stTag.length()),data.length());
	
	    int endIndx=data.indexOf(endTag);
	    String strTemp=data.substring(0,endIndx);
	   
	    if(tdbFlows.contains(strTemp.trim()))
	    {
	      alertStore.addElement(strTemp);
	   
	    }
	    
	    if(strTemp.indexOf(packageName) == -1)
	    {
	      boolean isPublicService=false;    
	      for(int q=0;q<ignoreList.length;q++)
	      {
	         int idx=strTemp.indexOf(ignoreList[q]); 
	         if(idx==0)  
	         { 
	           isPublicService=true;
	           break;  
	         } 
	           
	      }    
	      if((!dataStore.contains(strTemp)) && !isPublicService)
	         dataStore.addElement(strTemp);
	    } 
	     
	   }
	   
	}
	
	private static String getTagValue(String data,String stTag,String endTag)
	{
	   String retString=null;
	   int begIndx=data.indexOf(stTag);
	   if(begIndx != -1)
	   { 
	      data=data.substring((begIndx+stTag.length()),data.length());
	      int endIndx=data.indexOf(endTag);
	      retString=data.substring(0,endIndx);
	   }
	   
	   return retString;  
	       
	}
	
	private static String getFieldName(String data)
	{
	  String retString=null;
	  int begIndx=data.indexOf("FIELD=\"/");
	  if(begIndx != -1)
	   {
	     data=data.substring((begIndx+8),data.length());
	     int endIndx=data.indexOf(";");
	     if(endIndx == -1)
	       endIndx=data.length();
	     retString=data.substring(0,endIndx);      
	   }
	  return retString;
	}
	private static String[] splitString(String str)
	{ 
	  String[] retString=new String[2];
	  int indx=str.indexOf(".");
	  if(indx== -1)
	    indx=str.indexOf(":");
	  retString[0]=str.substring(0,indx);
	  retString[1]=str.substring((indx+1),str.length());
	  return retString;
	
	}
	
	
	
	private static void getElementCount(IData dataObj,Hashtable queryStore,String[] reqList)
	{
	  IDataCursor documentCursor = dataObj.getCursor();
	  while(documentCursor.next())
	    {
	      Object obj=documentCursor.getValue();
	      for(int k=0;k<reqList.length;k++)
	      { 
	        if((documentCursor.getKey()).equals(reqList[k]))
	         {
	            if(!(queryStore.containsKey(reqList[k])))
	            {
	               ArrayList alist=new ArrayList();
	               alist.add(obj);  
	               queryStore.put(reqList[k],(Object)alist) ; 
	            } 
	            else{
	              	  ArrayList alist1=(ArrayList)queryStore.get(reqList[k]);
	                  alist1.add(obj);
	            }
	            break;
	         }
	       } 
	
	      if((cls.isInstance(obj)) || (clsArray.isInstance(obj)) || (strArray.isInstance(obj)))
	       {
	          if(clsArray.isInstance(obj))
	            {
	              IData[] dObj=(IData[])obj;
	              for(int i=0;i<dObj.length;i++)
	 				getElementCount(dObj[i],queryStore,reqList);   
	            }
	          else if(cls.isInstance(obj))
	           {
	   	    	 getElementCount((IData)obj,queryStore,reqList);
	           }
	           else
	           {
	
	           }
	        }
	       
	    } 
	   documentCursor.destroy();
	   
	}
	
	private static void genHtml(IData dataObj,StringBuffer sbuf,String keyID)
	{
	  IDataCursor documentCursor = dataObj.getCursor();
	  while(documentCursor.next())
	    {
	      Object obj=documentCursor.getValue();
	      if(obj != null)
	       {                 
	     	 if((cls.isInstance(obj))||(clsArray.isInstance(obj)) || (strArray.isInstance(obj)))
	       	{
	          if(clsArray.isInstance(obj))
	            {
	              addDocToHtml(documentCursor.getKey(),sbuf,keyID+"|"+documentCursor.getKey()); 
	              IData[] dObj=(IData[])obj;
	              for(int i=0;i<dObj.length;i++)
	              {
	                String k1=(documentCursor.getKey()).toString();
	                addDocToHtml(getDocRef(dObj[i],k1,ids,i),sbuf,keyID+"|"+k1+"_"+i);
	 				genHtml(dObj[i],sbuf,keyID+"|"+k1+"_"+i); 
	                sbuf.append("</TABLE></DIV></TD><TR>");   
	              }  
	             sbuf.append("</TABLE></DIV></TD><TR>");  
	            }
	          else if(cls.isInstance(obj))
	           {
	                String k1=(documentCursor.getKey()).toString();
	                addDocToHtml(k1,sbuf,keyID+"|"+k1);
	   	    		genHtml((IData)obj,sbuf,keyID+"|"+k1);
	                sbuf.append("</TABLE></DIV></TD><TR>");
	            }  
	          else
	            {	
	                String k1=(documentCursor.getKey()).toString();
	                addDocToHtml(k1,sbuf,keyID+"|"+k1);
	                String[] aObj=(String[])obj;
	                for(int i1=0;i1<aObj.length;i1++)
	                {
	                  addElementToHtml(htmlEncode(aObj[i1]),sbuf); 
	                } 
	               sbuf.append("</TABLE></DIV></TD><TR>");
	            }
	        }
	        else
	        {
	          addElementToHtml((documentCursor.getKey()).toString(),htmlEncode((documentCursor.getValue()).toString()),sbuf); 
	        }   
	     } 
	     else
	   	 {  
	        addElementToHtml((documentCursor.getKey()).toString(),"",sbuf); 
	   	 }  
	   }
	   documentCursor.destroy();
	}
	
	private static String getDocRef(IData idataObj,String docKey,String[] ids,int counter)
	{
	  String retStr=docKey;
	  IDataCursor documentCursor = idataObj.getCursor();
	  if(ids != null)
	   {
	      for(int i=0;i<ids.length;i++)
	       {
	         String tStr=String.valueOf(IDataUtil.get(documentCursor,ids[i])); 
	         if(!(tStr.equals("null")))  
	          { 
	            retStr=retStr+"["+ids[i]+"="+tStr+"]";
	            break; 
	          }  
	       }
	
	   } 
	  
	  if(retStr.equals(docKey))
	    retStr=retStr+" ["+counter+"]";
	
	 documentCursor.destroy();
	 return retStr;
	
	}
	 
	private static void addDocToHtml(String key,StringBuffer sbuf,String keyID)
	{
	  sbuf.append("<td class=evenrow-l valign=top><IMG id=img"+keyID+" src=images/tree_plus.gif  onClick=collapse('"+keyID+"')>&nbsp;"+key+"</TD>");
	  sbuf.append("<td class=evenrow-l><DIV id="+keyID+" style=display:none><TABLE>");
	}
	
	private static void addElementToHtml(String key,String value,StringBuffer sbuf)
	{
	  sbuf.append("<TR><td class=evenrow-l><IMG src=images/tree_blank.gif>&nbsp;"+key+"</TD>");
	  sbuf.append("<td class=evenrow-l>&nbsp;"+value+"</TD></TR>");
	
	}
	private static void addElementToHtml(String value,StringBuffer sbuf)
	{
	  sbuf.append("<TR><td class=evenrow-l>&nbsp;"+value+"</TD></TR>");
	}
	
	private static String htmlEncode(String inString)
	{
		IData input = IDataFactory.create();
		IDataCursor inputCursor = input.getCursor();
		IDataUtil.put( inputCursor, "inString", inString);
		inputCursor.destroy();
	
		IData 	output = IDataFactory.create();
		try{
				output = Service.doInvoke( "pub.string", "HTMLEncode", input );
		}catch( Exception e){}
		IDataCursor outputCursor = output.getCursor();
		String value=IDataUtil.getString( outputCursor, "value" );
		outputCursor.destroy();
	    return value;
	
	}
	
	private static String genDhtml(String[] flows,String key)
	{ 
	 
	   IData input = IDataFactory.create();
	   IDataCursor inputCursor = input.getCursor();
	 
	    IData	document = IDataFactory.create();
		IDataCursor documentCursor = document.getCursor();
		IDataUtil.put( documentCursor, "flows", flows );
		documentCursor.destroy();
		IDataUtil.put( inputCursor, "document", document );
		IDataUtil.put( inputCursor, "key", key);
		inputCursor.destroy();
	
	// output
		IData 	output = IDataFactory.create();
		try{
				output = Service.doInvoke( "PackageScanner.util", "generateHtmlscript", input );
			}catch( Exception e){}
		IDataCursor outputCursor = output.getCursor();
			String	htmlcontent = IDataUtil.getString( outputCursor, "htmlcontent" );
		outputCursor.destroy();
	
	    return htmlcontent;
	
	 
	
	
	}
	
	
	private static String genDHtml(String[] flows,String key,String display)
	{ 
	 
	   IData input = IDataFactory.create();
	   IDataCursor inputCursor = input.getCursor();
	 
	    IData	document = IDataFactory.create();
		IDataCursor documentCursor = document.getCursor();
		IDataUtil.put( documentCursor, display, flows );
		documentCursor.destroy();
		IDataUtil.put( inputCursor, "document", document );
		IDataUtil.put( inputCursor, "key", key);
		inputCursor.destroy();
	
	// output
		IData 	output = IDataFactory.create();
		try{
				output = Service.doInvoke( "PackageScanner.util", "generateHtmlscript", input );
			}catch( Exception e){}
		IDataCursor outputCursor = output.getCursor();
			String	htmlcontent = IDataUtil.getString( outputCursor, "htmlcontent" );
		outputCursor.destroy();
	
	    return htmlcontent;
	
	 
	
	
	}
	
	
	private static void addACLMapToStore(String flow,String acl)
	{
	  boolean isCustomPackage=false;
	  for(int i=0;i<ignoreList.length;i++)
	   { 
	     if((flow.indexOf(ignoreList[i])) == -1)
	       isCustomPackage=true;
	   }
	
	  if(isCustomPackage)
	   {
	     int indx=flow.indexOf(".");
	     if(indx != -1)
	     { 
	     	String packName=flow.substring(0,indx);
	     	if(aclStore.containsKey(packName))
	     	{
	        	Vector v_1=(Vector)aclStore.get(packName);
		        v_1.addElement(flow+"*"+acl);
	    	 }
	     	else
	     	{
	       		Vector v_2=new Vector();
		    	v_2.addElement(flow+"*"+acl);
	    	    aclStore.put(packName,v_2); 
	     	}  
	      }
	   	}
	}
	
	
	
	private static String[] getPackages(String[] refList){
	
	
	// input
	IData input = IDataFactory.create();
	IDataCursor inputCursor = input.getCursor();
	IDataUtil.put( inputCursor, "refList", refList );
	inputCursor.destroy();
	
	// output
	IData 	output = IDataFactory.create();
	try{
		output = Service.doInvoke( "PackageScanner.util", "getPackage", input );
	}catch( Exception e){}
	IDataCursor outputCursor = output.getCursor();
		String[]	packageName = IDataUtil.getStringArray( outputCursor, "packageName" );
	outputCursor.destroy();
	return packageName;
	
	}
	
	private static String getPkgName (String inString){
	String pkg = null;
	if(inString.startsWith("pub.flow")){
	  pkg = "WmPublic";
	}
	 else{
	int idx = inString.indexOf(".");
	    if(idx<0){
	      idx = inString.indexOf(":");
	     }
	pkg = inString.substring(0,idx);
	  }
	return pkg;
	}
	
	
	
	private static String[] isValidNS(String nsName,String getPkgName){
	IData input = IDataFactory.create();
	IDataCursor inputCursor = input.getCursor();
	IDataUtil.put( inputCursor, "nsName", nsName);
	IDataUtil.put( inputCursor, "getPkgName", getPkgName);
	inputCursor.destroy();
	
	String [] s = new String[2];
	
	IData 	output = IDataFactory.create();
	try{
		output = Service.doInvoke( "PackageScanner.util", "isValidNs", input );
	}catch( Exception e){}
	IDataCursor outputCursor = output.getCursor();
		
	s[0] = IDataUtil.getString( outputCursor, "isValid" );
	s[1] = IDataUtil.getString( outputCursor, "pkgName" );
	outputCursor.destroy();
	
	return s;
	}
	
	//===============get version=======
	private static String getVersion (String pkgName){
	
	IData input = IDataFactory.create();
	IDataCursor inputCursor = input.getCursor();
	IDataUtil.put( inputCursor, "package", pkgName);
	inputCursor.destroy();
	String version = null;
	IData 	output = IDataFactory.create();
	try{
		output = Service.doInvoke( "PackageScanner.util", "getPackageInfo", input );
	}catch( Exception e){}
	IDataCursor outputCursor = output.getCursor();
		 version = IDataUtil.getString( outputCursor, "version" );
	    String isEnabled = IDataUtil.getString( outputCursor, "isEnabled" );
		
	            
	outputCursor.destroy();
	
	return version;
	} 
	
	// --- <<IS-END-SHARED>> ---
}

