package AEP_DocLinks_Inbound;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
// --- <<IS-END-IMPORTS>> ---

public final class Util

{
	// ---( internal utility methods )---

	final static Util _instance = new Util();

	static Util _newInstance() { return new Util(); }

	static Util _cast(Object o) { return (Util)o; }

	// ---( server methods )---




	public static final void upperCaseKeys (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(upperCaseKeys)>> ---
		// @sigtype java 3.5
		// [i] record:0:required Document
		// [o] record:0:required Document
		IDataCursor pipelineCursor = pipeline.getCursor();
		IData inDoc = IDataUtil.getIData(pipelineCursor, "Document");
		if (inDoc != null){
		IDataCursor docCursor = inDoc.getCursor();
		while(docCursor.next()){
			String key = docCursor.getKey();
			key = key.toUpperCase();
			docCursor.setKey(key);
		}
		docCursor.destroy();
		}
		pipelineCursor.destroy();
		
			
		// --- <<IS-END>> ---

                
	}
}

