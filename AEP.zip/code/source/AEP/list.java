package AEP;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2005-08-24 14:31:10 EDT
// -----( ON-HOST: P3031248.aepsc.com

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.util.TreeSet;
// --- <<IS-END-IMPORTS>> ---

public final class list

{
	// ---( internal utility methods )---

	final static list _instance = new list();

	static list _newInstance() { return new list(); }

	static list _cast(Object o) { return (list)o; }

	// ---( server methods )---




	public static final void appendToObjectList (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(appendToObjectList)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] object:1:required toList
		// [i] object:1:required fromList
		// [i] object:0:required fromItem
		// [o] object:1:required toList
		IDataCursor idc = pipeline.getCursor();
		
		Object[] toList = IDataUtil.getObjectArray(idc, "toList");
		Object[] fromList = IDataUtil.getObjectArray(idc, "fromList");
		Object fromItem = IDataUtil.get(idc, "fromItem");
		
		// find output array size
		int size = 0;
		if (toList != null)
		{
		   size += toList.length;
		}
		if (fromList != null)
		{
		   size += fromList.length;
		}
		if (fromItem != null)
		{
		   size++;
		}
		
		Object[] toListOutput = new Object[size];
		
		//populate toListOutput
		int totalSize = 0;
		if (toList != null)
		{
		   for (int i = 0; i < toList.length; i++)
		   {
		      toListOutput[i] = toList[i];
		   }
		   totalSize += toList.length;
		}
		
		if (fromList != null)
		{
		   for (int i = 0; i < fromList.length; i++)
		   {
		      toListOutput[totalSize + i] = fromList[i];
		   }
		   totalSize += fromList.length;
		}
		
		if (fromItem != null)
		{
		   toListOutput[totalSize] = fromItem;
		}
		
		if (idc.first("toList"))
		{
		   idc.setValue(toListOutput);
		}
		else
		{
		   idc.last();
		   idc.insertAfter("toList", toListOutput);
		}
		
		idc.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getMinAndMaxValue (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getMinAndMaxValue)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] object:1:required values
		// [o] object:0:required minValue
		// [o] object:0:required maxValue
		IDataCursor idc = pipeline.getCursor();
		
		Object[] values = (Object[])IDataUtil.getObjectArray(idc, "values");
		
		TreeSet ts = new TreeSet();
		
		for (int i = 0; i < values.length; i++)
		{
		    ts.add(values[i]);
		}
		
		IDataUtil.put(idc, "minValue", ts.first());
		IDataUtil.put(idc, "maxValue", ts.last());
		
		idc.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void sortDocuments (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(sortDocuments)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] record:1:required list
		// [i] record:1:required sortDescriptors
		// [i] - field:0:required keyField
		// [i] - field:0:required compareType {"STRING","NUMERIC","TIME","OBJECT"}
		// [i] - field:0:required pattern
		// [i] - field:0:required sortDescending {"false","true"}
		IDataCursor idc = pipeline.getCursor();
		IData[] list = IDataUtil.getIDataArray(idc, "list");
		IData[]	sortDescriptors = IDataUtil.getIDataArray(idc, "sortDescriptors");
		idc.destroy();
		
		if (sortDescriptors != null)
		{
		    IDataComparator c = null;
		    for (int i=sortDescriptors.length-1; i >= 0; i--)
		    {
		        idc = sortDescriptors[i].getCursor();
		        String keyField = IDataUtil.getString(idc, "keyField");
		        String compareType = IDataUtil.getString(idc, "compareType");
		        String pattern = IDataUtil.getString(idc, "pattern");
		        boolean sortDescending = (Boolean.valueOf(IDataUtil.getString(idc, "sortDescending" ))).booleanValue();
		        idc.destroy();
		
		        int cType = 0; // default to "STRING" comparison
		        if("NUMERIC".equals(compareType))
		            cType = 1;
		        else if("TIME".equals(compareType))
		            cType = 2;
		        else if("OBJECT".equals(compareType))
		            cType = 3;
		
		        c = new IDataComparator(keyField, cType, pattern, sortDescending, c);
		    }
		    java.util.Arrays.sort(list, c);
		}
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	static class IDataComparator implements java.util.Comparator 
	{
	    String field;
	    int compareType;
	    java.text.SimpleDateFormat sdf;
	    boolean descending;
	    IDataComparator nestedComparator;
	    public IDataComparator(String field, int compareType, String pattern, 
	          boolean descending, IDataComparator nestedComparator)
	    {
	        this.field = field;
	        this.compareType = compareType;
	        this.descending = descending;
	        if(compareType == 2)
	        {
	            sdf = new java.text.SimpleDateFormat( (pattern!=null? pattern : "MM/dd/yyyy hh:mm:ss a") );
	        }
	        this.nestedComparator = nestedComparator;
	    }
	    private Comparable getFieldValue(Object o)
	    {
	        Comparable c;
	        IDataCursor idc = ((IData)o).getCursor();
	        String s = IDataUtil.getString(idc, field);
	        switch (compareType)
	        {
	        case 0:        // STRING
	        default:
	            c = (s != null ? s : "");
	            break;
	        case 1:        // NUMERIC
	            c = new java.math.BigDecimal((s != null ? s : "0"));
	            break;
	        case 2:        // TIME
	            try
	            {
	                c = (s != null ? sdf.parse(s) : new java.util.Date(0));
	            }
	            catch (java.text.ParseException pe)
	            {
	                throw new RuntimeException("Value doesn't match pattern. " + s + "!=" + sdf.toPattern());
	                //throw new RuntimeException(pe);
	            }
	            break;
	        case 3:        // OBJECT
	            c = (Comparable)IDataUtil.get(idc, field);
	            break;
	        }
	        idc.destroy();
	        return c;  // will never be null
	    }
	    
	    public int compare(Object o1, Object o2)
	    {
	        int i;
	        i = getFieldValue(o1).compareTo(getFieldValue(o2));
	        if(i != 0 && descending)
	           i = -i;
	        if(i == 0 && nestedComparator != null)
	           i = nestedComparator.compare(o1, o2);
	        return i;
	    }
	}
	// --- <<IS-END-SHARED>> ---
}

