package AEP;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2005-11-07 07:58:25 EST
// -----( ON-HOST: P3031248.aepsc.com

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
// --- <<IS-END-IMPORTS>> ---

public final class log

{
	// ---( internal utility methods )---

	final static log _instance = new log();

	static log _newInstance() { return new log(); }

	static log _cast(Object o) { return (log)o; }

	// ---( server methods )---




	public static final void closeLogStream (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(closeLogStream)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required logfile
		IDataCursor idc = pipeline.getCursor();
		String logfile = IDataUtil.getString(idc, "logfile");
		idc.destroy();
		
		com.wm.app.b2b.server.LogOutputStream os = 
			(com.wm.app.b2b.server.LogOutputStream)openLogFiles.get(logfile);
		
		if(os != null)
		{
		  openLogFiles.remove(logfile);
		  os.close();
		}
		// --- <<IS-END>> ---

                
	}



	public static final void getLogStream (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getLogStream)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required logfile
		// [o] object:0:required logStream
		// [o] field:0:required newLog
		IDataCursor idc = pipeline.getCursor();
		String logfile = IDataUtil.getString(idc, "logfile");
		
		boolean newLog = false;
		com.wm.app.b2b.server.LogOutputStream os = 
			(com.wm.app.b2b.server.LogOutputStream)openLogFiles.get(logfile);
		
		if(os == null)
		{
		  os = com.wm.app.b2b.server.ServerAPI.getLogStream(logfile);
		  openLogFiles.put(logfile, os);
		  newLog = true;
		}
		
		IDataUtil.put(idc, "logStream", os);
		IDataUtil.put(idc, "newLog", (newLog?"true":"false"));
		idc.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void writeLogStream (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(writeLogStream)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] object:0:required logStream
		// [i] field:0:required message
		IDataCursor idc = pipeline.getCursor();
		com.wm.app.b2b.server.LogOutputStream os = 
			(com.wm.app.b2b.server.LogOutputStream)IDataUtil.get(idc, "logStream");
		String message = IDataUtil.getString(idc, "message" );
		idc.destroy();
		
		os.write(message);
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	// Track open log files
	private static java.util.Hashtable openLogFiles = new java.util.Hashtable();
	// --- <<IS-END-SHARED>> ---
}

