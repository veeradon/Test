package AEP_Gateway_EDI;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.io.*;
// --- <<IS-END-IMPORTS>> ---

public final class java

{
	// ---( internal utility methods )---

	final static java _instance = new java();

	static java _newInstance() { return new java(); }

	static java _cast(Object o) { return (java)o; }

	// ---( server methods )---




	public static final void getSessionInfo (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getSessionInfo)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] record:0:required $session
		// [o] field:0:required userName
		
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		
			// $session
			com.wm.app.b2b.server.Session	$session = (com.wm.app.b2b.server.Session)IDataUtil.getIData( pipelineCursor, "$session" );
			if ( $session != null)
			{
				//$session= (com.wm.app.b2b.server.Session)$session;
			}
		pipelineCursor.destroy();
		
		//com.wm.app.b2b.server.User UObject= $session.getUser();
		//String userName=UObject.getName();
		
		String userName= $session.getUser().getName();
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "userName", userName );
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}
}

