package AEP;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.util.*;
import java.text.*;
import com.wm.app.b2b.server.*;
import com.wm.app.b2b.client.*;
// --- <<IS-END-IMPORTS>> ---

public final class util

{
	// ---( internal utility methods )---

	final static util _instance = new util();

	static util _newInstance() { return new util(); }

	static util _cast(Object o) { return (util)o; }

	// ---( server methods )---




	public static final void getSystemProperty (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getSystemProperty)>> ---
		// @sigtype java 3.5
		// [i] field:0:required propertyName
		// [o] field:0:required property
		/**
		 * Service is designed to return the specified system property.
		 * 
		 */
		
		IDataCursor hCursor = pipeline.getCursor();
		
		hCursor.first("propertyName");
		String propertyName = (String) hCursor.getValue();
		
		String property = new String();
		
		property = System.getProperty(propertyName, "No property found");
		
		if (hCursor.first("property"))
		  hCursor.delete();
		hCursor.insertAfter("property", property);
		 
		// --- <<IS-END>> ---

                
	}



	public static final void incrementDate (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(incrementDate)>> ---
		// @sigtype java 3.5
		// [i] field:0:required startingDate
		// [i] field:0:required startingDateFormat
		// [i] field:0:required endingDateFormat
		// [i] field:0:optional addYears
		// [i] field:0:optional addMonths
		// [i] field:0:optional addDays
		// [i] field:0:optional addHours
		// [i] field:0:optional addMinutes
		// [i] field:0:optional addSeconds
		// [o] field:0:required endingDate

	IDataCursor idcPipeline = pipeline.getCursor();

	String strStartingDate = null;
	if (idcPipeline.first("startingDate"))
	{
		strStartingDate = (String)idcPipeline.getValue();
	} 
	else
	{
		throw new ServiceException("startingDate must be supplied!");
	}
	String strStartingDateFormat = null;
	if (idcPipeline.first("startingDateFormat"))
	{
		strStartingDateFormat = (String)idcPipeline.getValue();
	}
	else
	{
		throw new ServiceException("startingDateFormat must be supplied!");
	}
	String strEndingDateFormat = null;
	if (idcPipeline.first("endingDateFormat"))
	{
		strEndingDateFormat = (String)idcPipeline.getValue();
	}
	else
	{
		throw new ServiceException("endingDateFormat must be supplied!");
	}

	String strAddYears = null;
	String strAddMonths = null;
	String strAddDays = null;
	String strAddHours = null;
	String strAddMinutes = null;
	String strAddSeconds = null;

	if (idcPipeline.first("addYears"))
	{
		strAddYears = (String)idcPipeline.getValue();
	}
	if (idcPipeline.first("addMonths"))
	{
		strAddMonths = (String)idcPipeline.getValue();
	}
	if (idcPipeline.first("addDays"))
	{
		strAddDays = (String)idcPipeline.getValue();
	}
	if (idcPipeline.first("addHours"))
	{
		strAddHours = (String)idcPipeline.getValue();
	}
	if (idcPipeline.first("addMinutes"))
	{
		strAddMinutes = (String)idcPipeline.getValue();
	}
	if (idcPipeline.first("addSeconds"))
	{
		strAddSeconds = (String)idcPipeline.getValue();
	}

	SimpleDateFormat ssdf = new SimpleDateFormat(strStartingDateFormat);

	Date startingDate = null;
	try
	{
		startingDate = ssdf.parse(strStartingDate);
	}
	catch (Exception e)
	{
		throw new ServiceException(e.toString());
	}

	GregorianCalendar gc = new GregorianCalendar();
	gc.setTime(startingDate);

	if (strAddYears != null)
	{
		gc.add(Calendar.YEAR, Integer.parseInt(strAddYears));
	}
	if (strAddMonths != null)
	{
		gc.add(Calendar.MONTH, Integer.parseInt(strAddMonths));
	}
	if (strAddDays != null)
	{
		gc.add(Calendar.DAY_OF_MONTH, Integer.parseInt(strAddDays));
	}
	if (strAddHours != null)
	{
		gc.add(Calendar.HOUR_OF_DAY, Integer.parseInt(strAddHours));
	}
	if (strAddMinutes != null)
	{
		gc.add(Calendar.MINUTE, Integer.parseInt(strAddMinutes));
	}
	if (strAddSeconds != null)
	{
		gc.add(Calendar.SECOND, Integer.parseInt(strAddSeconds));
	}

	Date endingDate = gc.getTime();
	SimpleDateFormat esdf = new SimpleDateFormat(strEndingDateFormat);
	String strEndingDate = esdf.format(endingDate);

	idcPipeline.insertAfter("endingDate", strEndingDate);
	idcPipeline.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void isAdmin (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(isAdmin)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [o] object:0:required isAdmin
		 
		boolean isAdmin=false;
		
		
		User sUser=Service.getUser();
		Vector v=sUser.membershipNames();
		Vector appGroups=new Vector();
		
		if(v.contains("Administrators")){
		 isAdmin = true;
		   }
		
		
		appGroups.clear();
		appGroups=null;
		
		IDataCursor pipelineCursor = pipeline.getCursor();
		
		
		IDataUtil.put( pipelineCursor, "isAdmin", (new Boolean(isAdmin)) );
		
		pipelineCursor.destroy();
		
		
		
		// --- <<IS-END>> ---

                
	}



	public static final void isMonitorAdmin (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(isMonitorAdmin)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [o] object:0:required isMonitorAdmin
		 
		boolean isAdmin=false;
		
		
		User sUser=Service.getUser();
		Vector v=sUser.membershipNames();
		Vector appGroups=new Vector();
		
		if(v.contains("MonitorAdministrators")){
		 isAdmin = true;
		   }
		
		
		appGroups.clear();
		appGroups=null;
		
		IDataCursor pipelineCursor = pipeline.getCursor();
		
		
		IDataUtil.put( pipelineCursor, "isMonitorAdmin", (new Boolean(isAdmin)) );
		
		pipelineCursor.destroy();
		
		
		
		// --- <<IS-END>> ---

                
	}



	public static final void sortDoubles (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(sortDoubles)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] object:1:required doubleList
		// [o] object:1:required sortedDoubles
		//define input variables
		IDataCursor idc = pipeline.getCursor();
		
		if(idc.first("doubleList"))
		{
		  Double doubleList[] = (Double[]) idc.getValue();
		
		  if(doubleList.length > 0)
		  {
		    Double sortedDoubles[] = (Double[]) doubleList.clone();  //Make a copy of the original double list
		
		    Arrays.sort(sortedDoubles); //Sort it, natural order
		
		    if(idc.first("sortedDoubles")) idc.setValue(sortedDoubles);
		    else idc.insertAfter("sortedDoubles", sortedDoubles); //Place it in the pipeline
		  }
		
		}
		
		idc.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void sortInts (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(sortInts)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] object:1:required intList
		// [o] object:1:required sortedInts
		//define input variables
		IDataCursor idc = pipeline.getCursor();
		
		if(idc.first("intList"))
		{
		  Integer intList[] = (Integer[]) idc.getValue();
		
		  if(intList.length > 0)
		  {
		    Integer sortedInts[] = (Integer[]) intList.clone();  //Make a copy of the original integer list
		
		    Arrays.sort(sortedInts); //Sort it, natural order
		
		    if(idc.first("sortedInts")) idc.setValue(sortedInts);
		    else idc.insertAfter("sortedInts", sortedInts); //Place it in the pipeline
		  }
		
		}
		
		idc.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void threadWait (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(threadWait)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required noOfMillis
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	noOfMillis = IDataUtil.getString( pipelineCursor, "noOfMillis" );
		pipelineCursor.destroy();
		
		try
		 {
		    Thread.sleep(Integer.parseInt(noOfMillis));
		
		 }catch(Exception e){
		                       throw(new ServiceException(e.toString()));
		                    } 
		          
		  
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	static int MAX_VALUE = 1000;
	static int MIN_VALUE = 1;
	// --- <<IS-END-SHARED>> ---
}

