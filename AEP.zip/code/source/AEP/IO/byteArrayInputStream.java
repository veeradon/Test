package AEP.IO;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2005-04-14 15:11:15 EDT
// -----( ON-HOST: hqwhslas068.aepsc.com

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
// --- <<IS-END-IMPORTS>> ---

public final class byteArrayInputStream

{
	// ---( internal utility methods )---

	final static byteArrayInputStream _instance = new byteArrayInputStream();

	static byteArrayInputStream _newInstance() { return new byteArrayInputStream(); }

	static byteArrayInputStream _cast(Object o) { return (byteArrayInputStream)o; }

	// ---( server methods )---




	public static final void newInputStream (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(newInputStream)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] object:0:required bytes
		// [o] object:0:required inputStream
		IDataCursor idc = pipeline.getCursor();
		byte[] buf = (byte []) IDataUtil.get(idc, "bytes");
		
		// Will toss an exception if buf is null
		IDataUtil.put(idc, "inputStream", new java.io.ByteArrayInputStream(buf));
		idc.destroy();
		// --- <<IS-END>> ---

                
	}
}

