package PackageScanner;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2008-04-14 16:55:38 EDT
// -----( ON-HOST: rpeiasd1.aepsc.com

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.util.*;
// --- <<IS-END-IMPORTS>> ---

public final class admin

{
	// ---( internal utility methods )---

	final static admin _instance = new admin();

	static admin _newInstance() { return new admin(); }

	static admin _cast(Object o) { return (admin)o; }

	// ---( server methods )---




	public static final void clearStore (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(clearStore)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		conNameStore.clear();
		// --- <<IS-END>> ---

                
	}



	public static final void getConnInfo (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getConnInfo)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:1:required connections
		// [o] field:1:required connPackages
		 String confFound = "false";
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String[]	connections = IDataUtil.getStringArray( pipelineCursor, "connections" );
		       int conLen = connections.length;
		String[]	connPackages = new String[conLen];
		         for(int i=0;i<conLen;i++){
		              String pkg = (String)(conNameStore.get(connections[i]));
		                 
		                if(pkg!=null){
		                connPackages[i] = pkg;
		                      confFound = "true";
		                    }
		           }
		pipelineCursor.destroy();
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		
		IDataUtil.put( pipelineCursor_1, "connPackages", connPackages );
		IDataUtil.put( pipelineCursor_1, "confFound", confFound );
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void storeConnInfo (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(storeConnInfo)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] record:1:required connectionDataList
		// [i] - field:0:required connectionAlias
		// [i] - field:0:required packageName
		// [i] - field:0:required connectionState
		 
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		
			// connectionDataList
			IData[]	connectionDataList = IDataUtil.getIDataArray( pipelineCursor, "connectionDataList" );
			if ( connectionDataList != null)
			{
				for ( int i = 0; i < connectionDataList.length; i++ )
				{
					IDataCursor connectionDataListCursor = connectionDataList[i].getCursor();
						String	connectionAlias = IDataUtil.getString( connectionDataListCursor, "connectionAlias" );
						String	packageName = IDataUtil.getString( connectionDataListCursor, "packageName" );
						String	connectionState = IDataUtil.getString( connectionDataListCursor, "connectionState" );
		                                   conNameStore.put(connectionAlias,packageName);
					connectionDataListCursor.destroy();
				}
			}
		pipelineCursor.destroy();
		
		// pipeline
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	private static Hashtable conNameStore=new Hashtable();
	// --- <<IS-END-SHARED>> ---
}

