package AEP;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2005-11-07 07:50:54 EST
// -----( ON-HOST: P3031248.aepsc.com

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
// --- <<IS-END-IMPORTS>> ---

public final class properties

{
	// ---( internal utility methods )---

	final static properties _instance = new properties();

	static properties _newInstance() { return new properties(); }

	static properties _cast(Object o) { return (properties)o; }

	// ---( server methods )---




	public static final void documentListToProperties (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(documentListToProperties)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] record:1:required documentList
		// [i] field:0:required name
		// [i] field:0:required value
		// [i] field:0:required useSystemPropertiesAsDefault {"true","false"}
		// [o] object:0:required properties
		IDataCursor idc = pipeline.getCursor();
		String name = IDataUtil.getString(idc, "name");
		String value = IDataUtil.getString(idc, "value");
		idc.first("useSystemPropertiesAsDefault");
		boolean useSystemPropertiesAsDefault = IDataUtil.getBoolean(idc);
		
		java.util.Properties props = null;
		if(useSystemPropertiesAsDefault)
		{
			props = new java.util.Properties(System.getProperties());
		}
		else
		{
			props = new java.util.Properties();
		}
		
		IData[] documentList = IDataUtil.getIDataArray(idc, "documentList");
		if(documentList != null)
		{
		    for (int i = 0; i < documentList.length; i++)
		    {
		        IDataCursor dlc = documentList[i].getCursor();
		        props.setProperty(IDataUtil.getString(dlc, name), IDataUtil.getString(dlc, value));
		        dlc.destroy();
		    }
		}
		
		IDataUtil.put(idc, "properties", props);
		idc.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void propertiesGet (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(propertiesGet)>> ---
		// @sigtype java 3.5
		// [i] object:0:required properties
		// [i] field:0:required key
		// [i] field:0:required defaultValue
		// [o] field:0:required value
		IDataCursor pipelineCursor = pipeline.getCursor();
		java.util.Properties props = (java.util.Properties)IDataUtil.get( pipelineCursor, "properties" );
		String key = IDataUtil.getString( pipelineCursor, "key" );
		String defaultValue = IDataUtil.getString( pipelineCursor, "defaultValue" );
		String value = null;
		if(props == null)
			value = System.getProperty(key, defaultValue);
		else
			value = props.getProperty(key, defaultValue);
		if(value != null)
			IDataUtil.put( pipelineCursor, "value", value);
		pipelineCursor.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void propertiesLoad (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(propertiesLoad)>> ---
		// @sigtype java 3.5
		// [i] field:0:required propertiesFilename
		// [i] field:0:required useSystemPropertiesAsDefault {"true","false"}
		// [o] object:0:required properties
		IDataCursor pipelineCursor = pipeline.getCursor();
		String propertiesFilename = IDataUtil.getString( pipelineCursor, "propertiesFilename" );
		pipelineCursor.first("useSystemPropertiesAsDefault");
		boolean useSystemPropertiesAsDefault = IDataUtil.getBoolean(pipelineCursor);
		
		java.util.Properties props = null;
		if(useSystemPropertiesAsDefault)
		{
			props = new java.util.Properties(System.getProperties());
		}
		else
		{
			props = new java.util.Properties();
		}
		
		try
		{
			java.io.FileInputStream fis = new java.io.FileInputStream(propertiesFilename);
			props.load(fis);
			fis.close();
		}
		catch (java.io.IOException ioe)
		{
			//throw new ServiceException("propertiesLoad service failed." + ioe.getMessage());
			throw new ServiceException(ioe);
		}
		
		IDataUtil.put( pipelineCursor, "properties", props );
		pipelineCursor.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void propertiesSet (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(propertiesSet)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] object:0:required properties
		// [i] field:0:required key
		// [i] field:0:required value
		// [o] field:0:required oldValue
		IDataCursor pipelineCursor = pipeline.getCursor();
		java.util.Properties props = (java.util.Properties)IDataUtil.get( pipelineCursor, "properties" );
		String key = IDataUtil.getString( pipelineCursor, "key" );
		String value = IDataUtil.getString( pipelineCursor, "value" );
		String oldValue = null;
		if(props == null)
			oldValue = System.setProperty(key, value);
		else
			oldValue = (String)props.setProperty(key, value);
		if(oldValue != null)
			IDataUtil.put( pipelineCursor, "oldValue", oldValue);
		pipelineCursor.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void propertiesStore (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(propertiesStore)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] object:0:required properties
		// [i] object:0:optional outputStream
		// [i] field:0:optional propertiesFilename
		// [i] field:0:optional header
		IDataCursor idc = pipeline.getCursor();
		java.util.Properties properties = (java.util.Properties)IDataUtil.get(idc, "properties");
		Object outputStream = IDataUtil.get(idc, "outputStream");
		String propertiesFilename = IDataUtil.getString(idc, "propertiesFilename");
		String header = IDataUtil.getString(idc, "header");
		idc.destroy();
		
		java.io.OutputStream os = null;
		if(outputStream != null)
		{
		    os = (java.io.OutputStream)outputStream;
		}
		else
		{
		    try
		    {
		        os = new java.io.FileOutputStream(propertiesFilename);
		    }
		    catch(java.io.FileNotFoundException exc)
		    {
		        throw new ServiceException(exc);
		    }
		}
		
		try
		{
		    properties.store(os, header);
		}
		catch (java.io.IOException ioe)
		{
		    throw new ServiceException(ioe);
		}
		finally
		{
		    if(outputStream == null)  // if the stream is ours, close it
		    {
			try { os.close(); }
			catch (java.io.IOException ignored) { }
		    }
		}
		// --- <<IS-END>> ---

                
	}



	public static final void propertiesToDocumentList (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(propertiesToDocumentList)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] object:0:required properties
		// [i] field:0:required name
		// [i] field:0:required value
		// [o] record:1:required documentList
		IDataCursor idc = pipeline.getCursor();
		java.util.Properties properties = (java.util.Properties)IDataUtil.get(idc, "properties");
		String name = IDataUtil.getString(idc, "name");
		String value = IDataUtil.getString(idc, "value");
		
		java.util.Vector v = new java.util.Vector();
		for(java.util.Enumeration e = properties.propertyNames(); e.hasMoreElements(); )
		{
		    IData prop = IDataFactory.create();
		    IDataCursor propC = prop.getCursor();
		
		    String key = (String)e.nextElement();
		    IDataUtil.put(propC, name, key);
		    IDataUtil.put(propC, value, properties.getProperty(key));
		
		    propC.destroy();
		    v.add(prop);
		}
		
		IData[]	documentList = new IData[v.size()];
		IDataUtil.put(idc, "documentList", v.toArray(documentList));
		
		idc.destroy();
		// --- <<IS-END>> ---

                
	}
}

