package AEP.IO;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2005-10-03 09:43:06 EDT
// -----( ON-HOST: P3031248.aepsc.com

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
// --- <<IS-END-IMPORTS>> ---

public final class fileFilter

{
	// ---( internal utility methods )---

	final static fileFilter _instance = new fileFilter();

	static fileFilter _newInstance() { return new fileFilter(); }

	static fileFilter _cast(Object o) { return (fileFilter)o; }

	// ---( server methods )---




	public static final void newCombinationFileFilter (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(newCombinationFileFilter)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] object:1:required matchAny
		// [i] object:1:required matchAll
		// [i] object:1:required matchNone
		// [o] object:0:required combinationFileFilter
		IDataCursor idc = pipeline.getCursor();
		Object[] matchAny = IDataUtil.getObjectArray(idc, "matchAny");
		Object[] matchAll = IDataUtil.getObjectArray(idc, "matchAll");
		Object[] matchNone = IDataUtil.getObjectArray(idc, "matchNone");
		
		com.aep.io.CombinationFileFilter cf = new com.aep.io.CombinationFileFilter();
		if(matchAny != null)
		{
		    for(int i=0; i < matchAny.length; i++)
		    {
		        cf.addMatchAny((com.aep.io.IOFileFilter)matchAny[i]);
		    }
		}
		if(matchAll != null)
		{
		    for(int i=0; i < matchAll.length; i++)
		    {
		        cf.addMatchAll((com.aep.io.IOFileFilter)matchAll[i]);
		    }
		}
		if(matchNone != null)
		{
		    for(int i=0; i < matchNone.length; i++)
		    {
		        cf.addMatchNone((com.aep.io.IOFileFilter)matchNone[i]);
		    }
		}
		
		IDataUtil.put(idc, "combinationFileFilter", cf);
		idc.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void newLastModifiedFileFilter (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(newLastModifiedFileFilter)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:optional pointInTime
		// [i] field:0:optional pointInTimeDaysBeforeNow
		// [i] field:0:optional pointInTimeHoursBeforeNow
		// [i] field:0:optional pointInTimeMinutesBeforeNow
		// [i] field:0:optional priorToPointInTime {"true","false"}
		// [i] field:0:optional acceptMatchingDirectories {"false","true"}
		// [o] object:0:required lastModifiedFileFilter
		IDataCursor idc = pipeline.getCursor();
		String pointInTimeStr = IDataUtil.getString(idc, "pointInTime");
		String pointInTimeDaysStr = IDataUtil.getString(idc, "pointInTimeDaysBeforeNow");
		String pointInTimeHoursStr = IDataUtil.getString(idc, "pointInTimeHoursBeforeNow");
		String pointInTimeMinutesStr = IDataUtil.getString(idc, "pointInTimeMinutesBeforeNow");
		boolean priorToPointInTime = true;
		String s = IDataUtil.getString(idc, "priorToPointInTime");
		if(s != null)
		    priorToPointInTime = IDataUtil.getBoolean(idc, "priorToPointInTime");
		boolean acceptMatchingDirectories = IDataUtil.getBoolean(idc, "acceptMatchingDirectories");
		idc.destroy();
		
		com.aep.io.LastModifiedFileFilter lmf = new com.aep.io.LastModifiedFileFilter();
		try
		{
		    if(pointInTimeStr != null)
		        lmf.setPointInTime(Long.parseLong(pointInTimeStr));
		    else if(pointInTimeDaysStr != null)
			lmf.setPointInTimeDaysBeforeNow(Integer.parseInt(pointInTimeDaysStr));
		    else if(pointInTimeHoursStr != null)
			lmf.setPointInTimeHoursBeforeNow(Integer.parseInt(pointInTimeHoursStr));
		    else if(pointInTimeMinutesStr != null)
			lmf.setPointInTimeMinutesBeforeNow(Integer.parseInt(pointInTimeMinutesStr));
		}
		catch (NumberFormatException nfe)
		{
		    throw new ServiceException(nfe);
		}
		lmf.setPriorToPointInTime(priorToPointInTime);
		lmf.setAcceptMatchingDirectories(acceptMatchingDirectories);
		
		idc = pipeline.getCursor();
		IDataUtil.put(idc, "lastModifiedFileFilter", lmf);
		idc.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void newWildcardFileFilter (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(newWildcardFileFilter)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:1:optional patterns
		// [i] field:0:optional acceptMatchingDirectories {"false","true"}
		// [o] object:0:required wildcardFileFilter
		IDataCursor idc = pipeline.getCursor();
		String[] patterns = IDataUtil.getStringArray(idc, "patterns");
		boolean acceptMatchingDirectories = IDataUtil.getBoolean(idc, "acceptMatchingDirectories");
		
		com.aep.io.WildcardFileFilter wf = new com.aep.io.WildcardFileFilter();
		wf.setPatterns(patterns);
		wf.setAcceptMatchingDirectories(acceptMatchingDirectories);
		IDataUtil.put(idc, "wildcardFileFilter", wf);
		idc.destroy();
		// --- <<IS-END>> ---

                
	}
}

