package AEP;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2004-03-22 14:46:14 EST
// -----( ON-HOST: arwhslas058x.aepsc.com

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import com.wm.app.b2b.server.InvokeState;
import com.wm.app.audit.IAuditRuntime;
// --- <<IS-END-IMPORTS>> ---

public final class context

{
	// ---( internal utility methods )---

	final static context _instance = new context();

	static context _newInstance() { return new context(); }

	static context _cast(Object o) { return (context)o; }

	// ---( server methods )---




	public static final void getContextIdFields (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getContextIdFields)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [o] field:0:required parentContextId
		// [o] field:0:required rootContextId
		// [o] field:0:required currentContextId
		IDataCursor idc = pipeline.getCursor();
		
		InvokeState is = InvokeState.getCurrentState();
		IAuditRuntime iar = is.getAuditRuntime();
		
		
		String[] contextStack = iar.getContextStack();
		
		//temporary
		//IDataUtil.put(idc, "stackSize", contextStack.length+ "");
		
		//get root context id
		IDataUtil.put(idc, "rootContextId", contextStack[0]);
		
		//get parent context id
		if (contextStack.length >= 2)
		{
			IDataUtil.put(idc, "parentContextId", contextStack[contextStack.length-2]);
		}
		else
		{
			IDataUtil.put(idc, "parentContextId", null);
		}
		
		//get current context id
		IDataUtil.put(idc, "currentContextId", contextStack[contextStack.length-1]);
		
		/*
		for(int i = 0; i < contextStack.length; i++)
		{
			IDataUtil.put(idc, "stackVal"+i, contextStack[i]);
		}
		*/
		
		idc.destroy();
		// --- <<IS-END>> ---

                
	}
}

