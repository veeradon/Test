package AEP.IO;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2005-04-14 15:11:33 EDT
// -----( ON-HOST: hqwhslas068.aepsc.com

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.File;
// --- <<IS-END-IMPORTS>> ---

public final class temporaryFileInputStream

{
	// ---( internal utility methods )---

	final static temporaryFileInputStream _instance = new temporaryFileInputStream();

	static temporaryFileInputStream _newInstance() { return new temporaryFileInputStream(); }

	static temporaryFileInputStream _cast(Object o) { return (temporaryFileInputStream)o; }

	// ---( server methods )---




	public static final void newInputStream (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(newInputStream)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] object:0:optional file
		// [i] field:0:optional name
		// [o] object:0:required inputStream
		IDataCursor idc = pipeline.getCursor();
		java.io.File f = (java.io.File)IDataUtil.get(idc, "file");
		String name = IDataUtil.getString(idc, "name");
		
		TemporaryFileInputStream tis = null;
		
		try
		{
		  if(f != null)
		    tis = _instance.new TemporaryFileInputStream(f);
		  else if(name != null)
		    tis = _instance.new TemporaryFileInputStream(name);
		  else
		    throw new ServiceException("Invalid parameters. Either file or name must be specified.");
		  IDataUtil.put(idc, "inputStream", tis);
		}
		catch (java.io.FileNotFoundException exc)
		{
		  throw new ServiceException(exc);
		}
		finally
		{
		  idc.destroy();
		}
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	/**
	 * Extends java.io.FileInputStream to delete the associated file
	 * when the stream is closed.
	 */
	public class TemporaryFileInputStream extends java.io.FileInputStream
	{
	   /**
		* The FileSystem object representing the platform's local file system.
		*/
		private java.io.File f = null;
	
	   /**
		* Creates a <code>TemporaryFileInputStream</code> by
		* opening a connection to an actual file,
		* the file named by the <code>File</code> object
		* <code>file</code> in the file system. See java.io.FileInputStream.
		*/
		public TemporaryFileInputStream(File file) throws FileNotFoundException
		{
			super(file);
			this.f = file;
		}
	
	   /**
		* Creates a <code>TemporaryFileInputStream</code> by
		* opening a connection to an actual file,
		* the file named by the path name <code>name</code>
		* in the file system. See java.io.FileInputStream.
		*/
		public TemporaryFileInputStream(String name) throws FileNotFoundException
		{
			this(new File(name));
		}
	
	   /**
		* Closes this file input stream and releases any system resources
		* associated with the stream.
		*
		* @exception  IOException  if an I/O error occurs.
		*/
		public void close() throws java.io.IOException
		{
			super.close();
			if(f != null)
				f.delete();
		}
	}
	// --- <<IS-END-SHARED>> ---
}

