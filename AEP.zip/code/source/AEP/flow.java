package AEP;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
// --- <<IS-END-IMPORTS>> ---

public final class flow

{
	// ---( internal utility methods )---

	final static flow _instance = new flow();

	static flow _newInstance() { return new flow(); }

	static flow _cast(Object o) { return (flow)o; }

	// ---( server methods )---




	public static final void appendData (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(appendData)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] record:0:required source
		// [i] record:0:required target
		// [o] record:0:required target
		IDataCursor pipelineCursor = pipeline.getCursor();
		IData source = IDataUtil.getIData( pipelineCursor, "source" );
		IData target = IDataUtil.getIData( pipelineCursor, "target" );
		IDataUtil.append(source,target);
		//IDataUtil.put(pipelineCursor, "s", target.toString());
		pipelineCursor.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getServiceName (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getServiceName)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [o] field:0:required folderName
		// [o] field:0:required serviceName
		// [o] field:0:required fullName
		// [o] field:0:required successFlag
		// [o] field:0:required errorMessage
		/** Service is designed to return the current service name.
		  * Output: folderPath - the folder path to the service
		  *			serviceName - the service name
		  *			fullName - the folder path + ":" + service
		  *			successFlag - true or false
		  *			errorMessage - error detail. This is set to "None" if no error occurs.
		  *
		  * NOTE 1: Because this service relies on a method invocation that retrieves the NSService
		  * 	object relating to the calling service, it will *NOT* work as desired if run independently.
		  * 	Instead, it will return information on the current service (this one) and set the
		  *		"successFlag" and "errorMessage" values to indicate an error.
		  * NOTE 2: This service uses non-public APIs within the webMethods Integration Server. These may 
		  * 	change in future releases of the product *without* notice. These method invocations are
		  *		marked as such.
		  *
		  * @author Ryan Johnston, Professional Services, webMethods, Inc.
		  * @version 1.0
		  */
		
		//Instantiate a cursor for access to the pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		
		//Working & Output Variables - Create all output & working variables
		com.wm.lang.ns.NSService callingService = null;
		java.util.StringTokenizer strTok = null;
		String folderPath = new String();
		String serviceName = new String();
		String fullName = new String();
		String successFlag = "true";
		String errorMessage = "None";
		
		//Input Variables
		//None
		
		//Service Body
		//This publicly documented method gets the NSService object associated with the calling service.
		callingService = com.wm.app.b2b.server.Service.getCallingService();
		
		/** If the callingService is not available (meaning that the service was run directly, set the 
		  * "callingService" to hold the values for the current service (this one). Additionally, set the
		  * "successFlag" and "errorMessage" fields to indicate a problem.
		  */
		if (callingService == null)
		{
			callingService = com.wm.app.b2b.server.InvokeState.getCurrentService();
			successFlag = "false";
			errorMessage = "No calling service found... Returning information for this service instead.";
		}
		
		/** Non-public API. However, this call is relatively safe, as "toString" is a standard method that
		  * is normally overriden from the root java.lang.Object.
		  */
		fullName = callingService.toString();
		
		/** Use StringTokenizer, from the java.util package, to extract the folderPath and serviceName 
		  * values.
		  */
		try
		{
			strTok = new java.util.StringTokenizer(fullName, ":");
			folderPath = strTok.nextToken();
			serviceName = strTok.nextToken();
		}
		catch(java.lang.Exception ex)
		{
			System.out.println("CRITICAL ERROR: Check the toString() method within NSService to ensure that it is returning Folder:ServiceName as desired.");
			successFlag = "false";
			errorMessage = "CRITICAL ERROR: Check the toString() method within NSService to ensure that it is returning Folder:ServiceName as desired.";
		
		}
		
		//Populate service output
		if (pipelineCursor.first("folderPath"))
			pipelineCursor.delete();
		pipelineCursor.insertAfter("folderPath", folderPath);
		
		if (pipelineCursor.first("serviceName"))
			pipelineCursor.delete();
		pipelineCursor.insertAfter("serviceName", serviceName);
		
		if (pipelineCursor.first("fullName"))
			pipelineCursor.delete();
		pipelineCursor.insertAfter("fullName", fullName);
		
		if (pipelineCursor.first("successFlag"))
			pipelineCursor.delete();
		pipelineCursor.insertAfter("successFlag", successFlag);
		
		if (pipelineCursor.first("errorMessage"))
			pipelineCursor.delete();
		pipelineCursor.insertAfter("errorMessage", errorMessage);
		// --- <<IS-END>> ---

                
	}



	public static final void getServiceStack (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getServiceStack)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [o] field:1:required serviceStack
		IDataCursor idc = pipeline.getCursor();
		java.util.Stack callStack = com.wm.app.b2b.server.InvokeState.getCurrentState().getCallStack();
		
		// Note that we allocate one less than what the stack has
		// to omit this service from being in the list
		String [] serviceStack = new String[callStack.size()-1];
		
		for(int j=0,i=serviceStack.length; --i>=0;j++)
		  serviceStack[j] = ((com.wm.lang.ns.NSService)callStack.elementAt(i)).toString();
		IDataUtil.put(idc, "serviceStack", serviceStack);
		idc.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void removeElement (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(removeElement)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required elementName
		IDataCursor pc = pipeline.getCursor();
		
		String elementName = null;
		
		if(pc.first("elementName"))
		{
			elementName = (String) pc.getValue();
			
			while(pc.first(elementName))
				pc.delete();
		}
		
		//Always destroy cursors that you created
		pc.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void throwError (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(throwError)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:optional errorMessage
		IDataCursor pipelineCursor = pipeline.getCursor();
		String error = IDataUtil.getString(pipelineCursor, "errorMessage");
		pipelineCursor.destroy();
		
		if(error != null)
			throw new ServiceException(error);
		else
			throw new ServiceException();
		// --- <<IS-END>> ---

                
	}
}

