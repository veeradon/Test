function FileData_Pairs(x)
{
x.t("2007","-2015");
x.t("-2015","software");
x.t("support","screens");
x.t("support","package");
x.t("mobile","support");
x.t("darmstadt","germany");
x.t("menu","mobile");
x.t("screens","2007");
x.t("software","darmstadt");
x.t("solutions","menu");
x.t("package","mobile");
x.t("package","solutions");
}
