package AEP.IO;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2005-04-14 15:11:09 EDT
// -----( ON-HOST: hqwhslas068.aepsc.com

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
// --- <<IS-END-IMPORTS>> ---

public final class bufferedReader

{
	// ---( internal utility methods )---

	final static bufferedReader _instance = new bufferedReader();

	static bufferedReader _newInstance() { return new bufferedReader(); }

	static bufferedReader _cast(Object o) { return (bufferedReader)o; }

	// ---( server methods )---




	public static final void close (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(close)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] object:0:required bufferedReader
		IDataCursor idc = pipeline.getCursor();
		java.io.BufferedReader br = (java.io.BufferedReader)IDataUtil.get(idc, "bufferedReader");
		idc.destroy();
		
		try
		{
		    br.close();
		}
		catch (java.io.IOException ioe)
		{
		    throw new ServiceException(ioe);
		}
		// --- <<IS-END>> ---

                
	}



	public static final void newReader (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(newReader)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] object:0:optional inputStream
		// [i] object:0:optional reader
		// [i] field:0:optional size
		// [o] object:0:required bufferedReader
		IDataCursor idc = pipeline.getCursor();
		java.io.InputStream inputStream = (java.io.InputStream) IDataUtil.get(idc, "inputStream");
		java.io.Reader reader = (java.io.Reader)IDataUtil.get(idc, "reader");
		int sz = IDataUtil.getInt(idc, "size", 0);
		
		if((inputStream == null) && (reader == null))
		    throw new ServiceException("Either inputStream or reader must be specified");
		
		if(reader == null)
		    reader = new java.io.InputStreamReader(inputStream);
		
		java.io.BufferedReader br = null;
		if(sz == 0)
		    br = new java.io.BufferedReader(reader);
		else
		    br = new java.io.BufferedReader(reader, sz);
		
		IDataUtil.put(idc, "bufferedReader", br);
		
		idc.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void readLine (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(readLine)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] object:0:required bufferedReader
		// [o] field:0:required line
		IDataCursor idc = pipeline.getCursor();
		java.io.BufferedReader br = (java.io.BufferedReader)IDataUtil.get(idc, "bufferedReader");
		
		try
		{
		    IDataUtil.put(idc, "line", br.readLine());
		}
		catch (java.io.IOException ioe)
		{
		    throw new ServiceException(ioe);
		}
		finally
		{
		    idc.destroy();
		}
		// --- <<IS-END>> ---

                
	}
}

