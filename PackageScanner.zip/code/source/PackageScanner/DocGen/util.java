package PackageScanner.DocGen;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2010-10-12 15:15:25 EDT
// -----( ON-HOST: p2005049.aepsc.com

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.util.*;
import com.vits.webm.var.*;
// --- <<IS-END-IMPORTS>> ---

public final class util

{
	// ---( internal utility methods )---

	final static util _instance = new util();

	static util _newInstance() { return new util(); }

	static util _cast(Object o) { return (util)o; }

	// ---( server methods )---




	public static final void formatData (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(formatData)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required wmString
		// [o] field:0:required value
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	wmString = IDataUtil.getString( pipelineCursor, "wmString" );
		pipelineCursor.destroy();
		
		String[] str=wmString.split(";");
		String value="";
		for(int k=0;k<str.length;k++)
		{
			value=str[0];
		        value=value.substring(1,value.length());
		}
		
		if(value.equals(""))
		{
		  value=wmString;
		}
		
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "value", value);
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void formatVar (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(formatVar)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required inString
		// [o] field:0:required formattedString
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	inString = IDataUtil.getString( pipelineCursor, "inString" );
		pipelineCursor.destroy();
		
		Vector vObj=new Vector();
		String[] strList=inString.split(";");
		for(int j=0;j<strList.length;j++)
		{
		    vObj.addElement(strList[j]);
		}
		
		String formattedString=(String)vObj.elementAt(0);
		formattedString=formattedString.substring(1,formattedString.length());
		
		int k=formattedString.indexOf("[");
		if(k!= -1)
		  formattedString=formattedString.substring(0,k);
		
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "formattedString", formattedString);
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getAdapterNode (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getAdapterNode)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] object:0:required node
		// [o] record:0:required nodeData
		IDataCursor pipelineCursor = pipeline.getCursor();
			Object	obj = IDataUtil.get( pipelineCursor, "node" );
		pipelineCursor.destroy();
		//System.out.println("asdsadasd "+obj.toString());
		
		 com.wm.lang.ns.NSService nsObj=(com.wm.lang.ns.NSService)obj;
		
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		 IDataUtil.put( pipelineCursor_1, "nodeData",nsObj.getAsData() );
		pipelineCursor_1.destroy();   
		// --- <<IS-END>> ---

                
	}



	public static final void getDocumentName (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getDocumentName)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] record:0:required vars
		// [i] - field:0:required node_type
		// [i] - field:0:required field_type
		// [i] - field:0:required field_dim
		// [i] - field:0:required nillable
		// [i] - field:0:required rec_ref
		// [o] field:0:required documentName
		String	rec_ref=null;
		IDataCursor pipelineCursor = pipeline.getCursor();
			IData	vars = IDataUtil.getIData( pipelineCursor, "vars" );
			if ( vars != null)
			{
				IDataCursor varsCursor = vars.getCursor();
						rec_ref = IDataUtil.getString( varsCursor, "rec_ref" );
				varsCursor.destroy();
			}
		pipelineCursor.destroy();
		
		int inx=rec_ref.indexOf(":");
		String documentName=rec_ref.substring((inx+1),rec_ref.length());
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "documentName",documentName);
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getDroppedVars (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getDroppedVars)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] record:1:required nodeDataSet
		// [i] - field:0:required type
		// [i] - object:0:required nodes
		// [i] field:0:required nodeName
		// [i] field:1:required outputs
		// [i] field:1:required inputs
		// [i] object:0:required includeDroppedVars
		// [o] field:1:required list
		
		Hashtable varObjStore=new Hashtable();
		IDataCursor pipelineCursor = pipeline.getCursor();
			IData[]	nodeDataSet = IDataUtil.getIDataArray( pipelineCursor, "nodeDataSet" );
		        String nodeName= IDataUtil.getString( pipelineCursor, "nodeName" );
		        String[] outputs=IDataUtil.getStringArray( pipelineCursor, "outputs" );
			String[] inputs=IDataUtil.getStringArray( pipelineCursor, "inputs" );	
		        boolean	includeDroppedVars = ((Boolean)IDataUtil.get( pipelineCursor, "includeDroppedVars" )).booleanValue();
		pipelineCursor.destroy();
		
		WMBlock wblk=new WMBlock();
		wblk.nodeName=nodeName;
		wblk.id="1";
		getFlowVariables(nodeName,nodeDataSet,wblk,false);
		Vector vObj=new Vector();
		
		vObj=parseWMBlk(wblk,vObj,"FlOWROOT",true);
		
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "list",getStringList(vObj));
		vObj.clear();
		
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getFlowDescription (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getFlowDescription)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] record:1:required nodeDataSet
		// [i] - field:0:required type
		// [i] - object:0:required nodes
		// [i] - field:0:required comment
		// [o] field:0:required description
		IDataCursor pipelineCursor = pipeline.getCursor();
			IData[]	nodeDataSet = IDataUtil.getIDataArray( pipelineCursor, "nodeDataSet" );
		pipelineCursor.destroy();
		
		StringBuffer sbf=new StringBuffer();
		sbf.append("<B>Logic</B>");
		sbf.append("\n\n");
		getFlowDetails(nodeDataSet," ",sbf);
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "description",sbf.toString());
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getFlowDetails (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getFlowDetails)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] object:0:required nodes
		// [i] field:0:required type
		// [o] record:1:required nodeDataSet
		// [o] record:1:required nodeSubDataSet
		IDataCursor pipelineCursor = pipeline.getCursor();
			Object	obj = IDataUtil.get( pipelineCursor, "nodes" );
		        String	type = IDataUtil.getString( pipelineCursor, "type" );
		pipelineCursor.destroy();
		
		IData[] flowList=null;
		Vector vObj=(Vector)obj;
		flowList=new IData[vObj.size()];
		for(int i=0;i<vObj.size();i++)
		{
		  com.wm.lang.flow.FlowElement ob_1=(com.wm.lang.flow.FlowElement)vObj.elementAt(i);
		  flowList[i]=ob_1.getAsData();
		  
		}
		
		
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		String key=null;
		
		if(type.equals("main"))
		   key="nodeDataSet";
		else
		   key="nodeSubDataSet";
		
		IDataUtil.put( pipelineCursor_1, key,flowList);
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getFlowRoot (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getFlowRoot)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] object:0:required flowObject
		// [o] record:0:required flowRoot
		IDataCursor pipelineCursor = pipeline.getCursor();
			Object	obj = IDataUtil.get( pipelineCursor, "flowObject" );
		pipelineCursor.destroy();
		
		com.wm.lang.flow.FlowRoot fRoot=(com.wm.lang.flow.FlowRoot)obj;
		
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "flowRoot",fRoot.getAsData() );
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getFlowVars (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getFlowVars)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] record:1:required nodeDataSet
		// [i] - field:0:required type
		// [i] - object:0:required nodes
		// [i] field:0:required nodeName
		// [i] field:1:required outputs
		// [i] field:1:required inputs
		// [i] object:0:required includeDroppedVars
		// [o] field:1:required list
		Vector unMappedVars=new Vector();
		Hashtable varObjStore=new Hashtable();
		IDataCursor pipelineCursor = pipeline.getCursor();
			IData[]	nodeDataSet = IDataUtil.getIDataArray( pipelineCursor, "nodeDataSet" );
		        String nodeName= IDataUtil.getString( pipelineCursor, "nodeName" );
		        String[] outputs=IDataUtil.getStringArray( pipelineCursor, "outputs" );
			String[] inputs=IDataUtil.getStringArray( pipelineCursor, "inputs" );	
		        boolean	includeDroppedVars = ((Boolean)IDataUtil.get( pipelineCursor, "includeDroppedVars" )).booleanValue();
		pipelineCursor.destroy();
		
		WMBlock wblk=new WMBlock();
		wblk.nodeName=nodeName;
		wblk.id="1";
		getFlowVariables(nodeName,nodeDataSet,wblk,false);
		Vector vObj=new Vector();
		if(inputs != null)
		{
			for(int i=0;i<inputs.length;i++)
			{
				vObj.addElement(inputs[i]);
			}
		}
		vObj=parseWMBlock(wblk,vObj,"FlOWROOT",includeDroppedVars);
		if((vObj != null) && (outputs !=  null))
		{
			for(int j=0;j<outputs.length;j++)
			{
		            	if(vObj.contains(outputs[j]))
		                 {
				  
					vObj.remove(outputs[j]);
		                     
		                 }
				else{
		                    
				   unMappedVars.addElement(outputs[j]);
		                     }
			}
		}
		
		
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "list",getStringList(vObj));
		vObj.clear();
		IDataUtil.put( pipelineCursor_1, "un-mappedVars",getStringList(unMappedVars));
		unMappedVars.clear();
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getJSNode (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getJSNode)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] object:0:required node
		// [o] record:0:required nodeData
		IDataCursor pipelineCursor = pipeline.getCursor();
			Object	obj = IDataUtil.get( pipelineCursor, "node" );
		pipelineCursor.destroy();
		
		com.wm.app.b2b.server.JavaService jsObj=(com.wm.app.b2b.server.JavaService)obj;
		
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "nodeData",jsObj.getAsData() );
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getLabelVars (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getLabelVars)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required label
		// [o] field:1:required varList
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	label = IDataUtil.getString( pipelineCursor, "label" );
		pipelineCursor.destroy();
		Vector vObj=new Vector();
		getVarsUsedByLabels(label,vObj);
		String[] varList=null;
		if(vObj.size()>0)
		{
		   varList=new String[vObj.size()];
		   vObj.toArray(varList);	
		} 
		
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "varList", varList );
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getMapDetails (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getMapDetails)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] record:1:required nodeDataSet
		// [i] - field:0:required type
		// [i] - object:0:required nodes
		// [i] field:0:required nodeName
		// [o] field:0:required isMapComment
		
		IDataCursor pipelineCursor = pipeline.getCursor();
			IData[]	nodeDataSet = IDataUtil.getIDataArray( pipelineCursor, "nodeDataSet" );
		        String nodeName= IDataUtil.getString( pipelineCursor, "nodeName" );
		        String[] outputs=IDataUtil.getStringArray( pipelineCursor, "outputs" );
			String[] inputs=IDataUtil.getStringArray( pipelineCursor, "inputs" );	
		        boolean	includeDroppedVars = ((Boolean)IDataUtil.get( pipelineCursor, "includeDroppedVars" )).booleanValue();
		pipelineCursor.destroy();
		
		WMBlock wblk=new WMBlock();
		wblk.nodeName=nodeName;
		wblk.id="1";
		Hashtable H = new Hashtable();
		H = getMapSteps(nodeName,nodeDataSet,wblk,false,"main",H);
		String isMapComment = (String)(H.get("result")); 
		
		
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		
		H.clear();
		
		
		IDataUtil.put( pipelineCursor_1, "isMapComment",isMapComment);
		
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getMappedValue (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getMappedValue)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required description
		// [i] field:0:required elementName
		// [o] field:0:required value
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	description = IDataUtil.getString( pipelineCursor, "description" );
			String	elementName = IDataUtil.getString( pipelineCursor, "elementName" );
		pipelineCursor.destroy();
		
		elementName=elementName+" </I> to  <I>";
		int inx=description.indexOf(elementName);
		String value="";
		if(inx != -1)
		{
		  description=description.substring((inx+elementName.length()),description.length());
		  int i_1=  description.indexOf("</I>");
		  value=description.substring(0,i_1);
		  value.trim();
		}
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "value", value);
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getNSRecord (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getNSRecord)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] object:0:required sigObj
		// [o] record:0:required vars
		IDataCursor pipelineCursor = pipeline.getCursor();
			Object	obj = IDataUtil.get( pipelineCursor, "sigObj" );
		pipelineCursor.destroy();
		
		com.wm.lang.ns.NSRecord sRoot=(com.wm.lang.ns.NSRecord)obj;
		
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "vars",sRoot.getAsData() );
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getNSSignature (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getNSSignature)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] object:0:required sigObj
		// [o] record:0:required svc_sig
		IDataCursor pipelineCursor = pipeline.getCursor();
			Object	obj = IDataUtil.get( pipelineCursor, "sigObj" );
		pipelineCursor.destroy();
		
		com.wm.lang.ns.NSSignature sRoot=(com.wm.lang.ns.NSSignature)obj;
		
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "svc_sig",sRoot.getAsData() );
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getNameSpaces (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getNameSpaces)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required packageName
		// [i] field:0:optional interfaceName
		// [o] field:1:required namespaces
		// [o] field:1:required adapterservices
		// [o] field:1:required javaservices
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	packageName = IDataUtil.getString( pipelineCursor, "packageName" );
			String	interfaceName = IDataUtil.getString( pipelineCursor, "interfaceName" );
		        if((interfaceName == null) || (interfaceName =="")){
		             interfaceName =  packageName;}
		pipelineCursor.destroy();
		
		Vector vObj=new Vector();
		Vector jObject=new Vector();
		Vector aObject=new Vector();
		getNodeList(packageName,interfaceName,vObj,jObject,aObject);
		String[]	namespaces = new String[vObj.size()];
		vObj.toArray(namespaces);
		String[]	javaservices = new String[jObject.size()];
		jObject.toArray(javaservices);
		String[]	adapterservices = new String[aObject.size()];
		aObject.toArray(adapterservices);
		
		aObject.clear();
		jObject.clear();
		vObj.clear();
		Arrays.sort(namespaces);
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "namespaces", namespaces );
		IDataUtil.put( pipelineCursor_1, "javaservices", javaservices );
		IDataUtil.put( pipelineCursor_1, "adapterservices", adapterservices );
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getNode (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getNode)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] object:0:required node
		// [o] record:0:required nodeData
		IDataCursor pipelineCursor = pipeline.getCursor();
			Object	obj = IDataUtil.get( pipelineCursor, "node" );
		pipelineCursor.destroy();
		
		
		com.wm.app.b2b.server.FlowSvcImpl fsObj=(com.wm.app.b2b.server.FlowSvcImpl)obj;
		
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "nodeData",fsObj.getAsData() );
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getServiceSig (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getServiceSig)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] object:0:required sigObject
		// [o] record:0:required svc_sig
		IDataCursor pipelineCursor = pipeline.getCursor();
			Object	obj = IDataUtil.get( pipelineCursor, "sigObject" );
		pipelineCursor.destroy();
		
		com.wm.lang.ns.NSSignature sRoot=(com.wm.lang.ns.NSSignature)obj;
		
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "svc_sig",sRoot.getAsData() );
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getServiceType (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getServiceType)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] object:0:required serviceType
		// [o] field:0:required type
		IDataCursor pipelineCursor = pipeline.getCursor();
			Object	serviceType = IDataUtil.get( pipelineCursor, "serviceType" );
		pipelineCursor.destroy();
		
		String str=serviceType.toString();
		String type=null;
		if((str.indexOf("AdapterService")) != -1)
		 type="AdapterService";
		else if((str.indexOf("flow/webservice")) != -1)
		 type="webservice";
		else if((str.indexOf("flow")) != -1)
		 type="flow";
		else if((str.indexOf("java")) != -1)
		 type="java";
		
		
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		  IDataUtil.put( pipelineCursor_1, "type",type);
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getVarLoc (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getVarLoc)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] record:1:required nodeDataSet
		// [i] - field:0:required type
		// [i] - object:0:required nodes
		// [i] field:0:required nodeName
		// [i] field:0:required variable
		// [o] field:0:required location
		IDataCursor pipelineCursor = pipeline.getCursor();
			IData[]	nodeDataSet = IDataUtil.getIDataArray( pipelineCursor, "nodeDataSet" );
		        String nodeName= IDataUtil.getString( pipelineCursor, "nodeName" );
		        String variable= IDataUtil.getString( pipelineCursor, "variable" );	
		pipelineCursor.destroy();
		
		
		
		WMBlock wblk=new WMBlock();
		wblk.nodeName=nodeName;
		wblk.id="1";
		getFlowVariables(nodeName,nodeDataSet,wblk,false);
		String[] list=new String[1];
		
		list[0]=variable;
		Hashtable refStore=new Hashtable();
		getVarUsageLoc(wblk,"FlOWROOT",list,refStore);
		
		
		String location=null;
		if(refStore.size()>0)
		{
		   StringBuffer sbf=new StringBuffer();
		   Enumeration enum_1=refStore.keys();   
		   String id=(String)enum_1.nextElement();
		   getDesignDoc(wblk,sbf,"FlOWROOT",id," ");
		   location=sbf.toString();
		}
		else
		  location="variable not used with in the flow,might be existing in the inputs/outputs";
		
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "location",location);
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getVars (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getVars)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required nodeName
		// [i] object:0:required nodes
		// [o] field:1:required list
		Hashtable varObjStore=new Hashtable();
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	nodeName = IDataUtil.getString( pipelineCursor, "nodeName" );
			Object	nodes =(Object)IDataUtil.get( pipelineCursor, "nodes" );
		pipelineCursor.destroy();
		
		WMBlock wmblk=new WMBlock();
		getSubFlowVars(nodeName,(Vector)nodes,wmblk,false);
		String[] list=null;
		int counter=0;
		if(varObjStore.size()>0)
		{
		  list=new String[varObjStore.size()];
		  Enumeration enum_1=varObjStore.keys();
		  while(enum_1.hasMoreElements())
		  {  
		    String ky=(String)enum_1.nextElement();
		    list[counter]=ky;
		    counter++;
		  }
		
		}
		
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "list",list);
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void isAModel (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(isAModel)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required package
		// [o] object:0:required isModel
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	package_1 = IDataUtil.getString( pipelineCursor, "package" );
		pipelineCursor.destroy();
		boolean isMdl=false;
		if(package_1.indexOf("_Process") != -1)
		  isMdl=true;
		
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "isModel",Boolean.valueOf(isMdl));
		pipelineCursor_1.destroy();
		     
		// --- <<IS-END>> ---

                
	}



	public static final void isANullObject (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(isANullObject)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required inStr
		// [o] object:0:required isNull
		boolean isNull=false;
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	inStr = String.valueOf(IDataUtil.getString( pipelineCursor, "inStr" ));
		pipelineCursor.destroy();
		
		if(inStr.equals("null"))
		  isNull=true;
		
		
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "isNull", Boolean.valueOf(isNull));
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void isCommonPack (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(isCommonPack)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required serviceName
		// [o] object:0:optional stat
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	serviceName = IDataUtil.getString( pipelineCursor, "serviceName" );
		pipelineCursor.destroy();
		boolean stat=false;
		String ifcName=serviceName.substring(0,serviceName.indexOf("."));
		if(igStore.contains(ifcName))
		  stat=true;
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "stat", Boolean.valueOf(stat));
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void reformatData (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(reformatData)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required wmString
		// [o] field:0:required value
		String wmString=null;
		IDataCursor pipelineCursor = pipeline.getCursor();
			wmString = IDataUtil.getString( pipelineCursor, "wmString" );
		pipelineCursor.destroy();
		
		
		String value="";
		if(wmString != null)
		{
			String[] str=wmString.split(";");
			for(int k=0;k<str.length;k++)
			{
				int i=str[k].indexOf("/");
				if(i != -1)
					 value=value+"/"+str[k].substring(i+1,str[k].length());
			}
		}
		
		if(value.equals(""))
		{
		  value=wmString;
		}
		
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "value", value);
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void reformatVal (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(reformatVal)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required inString
		// [o] field:0:required formattedString
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	inString = IDataUtil.getString( pipelineCursor, "inString" );
		pipelineCursor.destroy();
		
		Vector vObj=new Vector();
		String[] strList=inString.split(";");
		for(int j=0;j<strList.length;j++)
		{
		  
		  if(strList[j].length() > 3)
		    vObj.addElement(strList[j]);
		}
		
		String formattedString=null;
		if(vObj.size()>0)
		 formattedString=(String)vObj.elementAt(vObj.size()-1);
		
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "formattedString", formattedString);
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	private static Vector ignoreOps=new Vector();
	private static Vector endOps=new Vector();
	private static Vector igStore=new Vector(); 
	
	static
	{
	   ignoreOps.addElement("MAPDELETE");
	   endOps.addElement("LOOP");
	  endOps.addElement("INVOKE"); 
	  endOps.addElement("RETRY"); 
	
	   igStore.addElement("pub");
	   
	  
	}
	
	private static void getFlowDetails(IData[] nodeDataSet,String lineIndex,StringBuffer sbf)
	{
	
	  for ( int i = 0; i < nodeDataSet.length; i++ )
	   {
				IDataCursor nodeDataSetCursor = nodeDataSet[i].getCursor();
					Object	nodes = IDataUtil.get( nodeDataSetCursor, "nodes" );
	                String	type = IDataUtil.getString( nodeDataSetCursor, "type" );
	                String	cmnt = IDataUtil.getString( nodeDataSetCursor, "comment" );
				nodeDataSetCursor.destroy();
	            
	            if(nodes == null)
	            {
	              if(!(ignoreOps.contains(type)))
	              {                
	              	 String tStr=getNodeDescription(type,nodeDataSet[i],lineIndex,cmnt);
	                if((tStr != null) && (!(tStr.equals("$na$"))))
	                {
	                	sbf.append(lineIndex+tStr);
	              		sbf.append("\n");
	                }
	              }
	            } 
	            else
	            { 
	              if(!(ignoreOps.contains(type)))
	              {
	              	String tStr=getNodeDescription(type,nodeDataSet[i],lineIndex,cmnt);
	                if((tStr != null) && (!(tStr.equals("$na$"))))
	                {
	                	sbf.append(lineIndex+tStr);
	              		sbf.append("\n");
	                }
	              }
	              getSubFlowDetails((Vector)nodes,lineIndex,sbf); 
	              if(endOps.contains(type)) 
	              {
	                sbf.append(lineIndex+"end\""+type+"\"");
	              	sbf.append("\n"); 
	              }
	            } 
	       
		}	
	   
	}
	
	private static void getSubFlowDetails(Vector vObj,String lineIndex,StringBuffer sbf)
	{
	  lineIndex=lineIndex+"	";
	  IData[] flowList=null;
	  flowList=new IData[vObj.size()];
	  for(int i=0;i<vObj.size();i++)
	  {
	    Object ob_2=(Object)vObj.elementAt(i);
	    String cName=(ob_2.getClass()).getName();
	    if(cName.equals("com.wm.data.ISMemDataImpl"))
	     flowList[i]=(IData)ob_2;
	    else
	    {  
	        com.wm.lang.flow.FlowElement ob_1=(com.wm.lang.flow.FlowElement)vObj.elementAt(i);
	    	flowList[i]=ob_1.getAsData();
	    } 
	    
	  }
	  getFlowDetails(flowList,lineIndex,sbf);
	
	}
	
	private static String getNodeDescription(String type,IData nodeSet,String lineIndex,String comment)
	{
	  IData 	output = IDataFactory.create();
	  try{
	         
	     	output = Service.doInvoke( "PackageScanner.DocGen.util.map", "gen"+type, nodeSet );
	
	     }catch( Exception e){}
	
	   IDataCursor outputCursor = output.getCursor();
		 String	description = IDataUtil.getString( outputCursor, "description" );
	   outputCursor.destroy();
	    // System.out.println("type:" + type + "||" + "COMMENTS:" + comment);
	   
	   return  description;
	  
	}
	
	
	
	private static void getNodeList(String packageName,String interfaceName,Vector vObj,Vector jObject,Vector aObject)
	{
	
	IData input = IDataFactory.create();
	IDataCursor inputCursor = input.getCursor();
	IDataUtil.put( inputCursor, "interface",interfaceName);
	IDataUtil.put( inputCursor, "package", packageName);
	inputCursor.destroy();
	
	IData 	output = IDataFactory.create();
	try{
		output = Service.doInvoke( "PackageScanner.DocGen.util", "getNodeList", input );
	}catch( Exception e){}
	
	IDataCursor outputCursor = output.getCursor();
		IData[]	nodeList = IDataUtil.getIDataArray( outputCursor, "nodeList" );
	outputCursor.destroy();
	
		if ( nodeList != null)
		{
			for ( int i = 0; i < nodeList.length; i++ )
			{
				IDataCursor nodeListCursor = nodeList[i].getCursor();
					String	name = String.valueOf(IDataUtil.getString( nodeListCursor, "node_nsName" ));
					String	svcType = String.valueOf(IDataUtil.getString( nodeListCursor, "svc_type" ));
	            nodeListCursor.destroy(); 
	            if(svcType.equals("flow"))
	                   vObj.addElement(name);
	            else if(svcType.equals("java"))   
	                  jObject.addElement(name);
	            else if(svcType.equals("AdapterService"))   
	                  aObject.addElement(name);
	            else
	               getNodeList(packageName,name,vObj,jObject,aObject);                 
				
			}
		}
	 
	}
	
	private static void getServiceDetails(String name,Hashtable htObj)
	{
	 
	    IData input = IDataFactory.create();
		IDataCursor inputCursor = input.getCursor();
		IDataUtil.put( inputCursor, "name", name );
		inputCursor.destroy();
	
		IData 	output = IDataFactory.create();
		try{
				output = Service.doInvoke( "PackageScanner.DocGen.util", "getRefDetails", input );
			}catch( Exception e){
	                              // System.out.println(e.toString());
								}
		
		IDataCursor outputCursor = output.getCursor();
			String	type = IDataUtil.getString( outputCursor, "type" ); 
	        String[] references=null;
	        Object obj=IDataUtil.get(outputCursor, "references"); 
	        
	        if(obj != null)
	        {
	           references = (String[])obj;
	        } 
	
	
	       
	    outputCursor.destroy();
	        
	        if(references==null)
	            addServiceInfo(name,type,htObj);
	        else
	        { 
	            for(int i=0;i<references.length;i++)
	            {
				   String tStr=references[i];
				   int inx=references[i].indexOf("/");
				   if(inx != -1)
	               {
	                 String t1=tStr.substring(0,inx);
	                 if(!igStore.contains(t1))
					 {      
	     		             tStr=tStr.substring((inx+1),tStr.length());
	                          getServiceDetails(tStr,htObj); 
	                 }
				   }
	            } 
	        }            
		
	}
	
	private static void addServiceInfo(String name,String type,Hashtable htObj)
	{
	  if(type.equals("webservice"))
	   {
	      if(htObj.containsKey("webservice"))
	      {
	         Vector vobj=(Vector)htObj.get("webservice");
	         vobj.addElement(name); 
	      }
	      else
	      {
	         Vector vobj_1=new Vector();
	         vobj_1.addElement(name); 
	         htObj.put("webservice",vobj_1);
	      }    
	   }
	  else if(type.equals("AdapterService"))
	   { 
	      if(htObj.containsKey("AdapterService"))
	      {
	         Vector vobj=(Vector)htObj.get("AdapterService");
	         vobj.addElement(name); 
	      }
	      else
	      {
	         Vector vobj_1=new Vector();
	         vobj_1.addElement(name); 
	         htObj.put("AdapterService",vobj_1);
	      }    
	 
	   }
	}
	
	//-----------------------------*************************-----------------------------
	 
	private static void getFlowVariables(String nodeName,IData[] nodeDataSet,WMBlock wmblk,boolean useSameObject)
	{
	  String seq=wmblk.id;
	  for ( int i = 0; i < nodeDataSet.length; i++ )
	   {
				IDataCursor nodeDataSetCursor = nodeDataSet[i].getCursor();
					Object	nodes = IDataUtil.get( nodeDataSetCursor, "nodes" );
	                String	type = IDataUtil.getString( nodeDataSetCursor, "type" );
	                String	comment = IDataUtil.getString( nodeDataSetCursor, "comment" );
				nodeDataSetCursor.destroy();
	           
	            if(! (type==null))
	            { 
	                    if(type.equals("MAP") || type.equals("MAPEXIT"))
						{      
	                                          
						  WMObject wmobj=null; 	
	                      if(useSameObject)
	                        wmobj=(WMObject)((wmblk.sequencer).elementAt((wmblk.sequencer).size() -1));
	                      else     
	                         wmobj=getWMObject(wmblk,seq+"_"+i,type);
						  loadNodeVarDetails(nodeName,type,nodeDataSet[i],wmblk,comment);
						  String serviceName=null;	
						  if((wmblk.sequencer).size()>0)	
	                      {
						      WMObject wO_1=(WMObject)((wmblk.sequencer).elementAt((wmblk.sequencer).size() -1));
							  serviceName=wO_1.serviceName;		
	                      }
	                      else
							  serviceName=nodeName;			
	                      if(nodes != null)
	                        getSubFlowVars(serviceName,(Vector)nodes,wmblk,useSameObject);
	
	                      if(!useSameObject)  
	                          wmobj.objectLocked=true;
						   	
	                    }      
	                    else if(type.equals("INVOKE") || type.equals("MAPINVOKE"))
						{      
	                               
	                      WMObject wmobj=getWMObject(wmblk,seq+"_"+i,type);
						  loadNodeVarDetails(nodeName,type,nodeDataSet[i],wmblk,comment);
						  String serviceName=null;	
						  if((wmblk.sequencer).size()>0)	
	                      {
						      WMObject wO_1=(WMObject)((wmblk.sequencer).elementAt((wmblk.sequencer).size() -1));
							  serviceName=wO_1.serviceName;		
	                      }
	                      else
							  serviceName=nodeName;			
	                      if(nodes != null)
	                        getSubFlowVars(serviceName,(Vector)nodes,wmblk,true);
	
	                      wmobj.objectLocked=true;
						  	
	                    }  					        
						else if(type.equals("MAPSET") || type.equals("MAPCOPY") || type.equals("MAPDELETE"))
	                    {
	                        
	                        String serviceName=null;	 
							if((wmblk.sequencer).size()>0)	
	                      	{
						      WMObject wO_1=(WMObject)((wmblk.sequencer).elementAt((wmblk.sequencer).size() -1));
							  serviceName=wO_1.serviceName;		
	                      	}
	                     	 else
							  	serviceName=nodeName;
							loadNodeVarDetails(serviceName,type,nodeDataSet[i],wmblk,comment);
							if(nodes != null)
	                        	getSubFlowVars(serviceName,(Vector)nodes,wmblk,useSameObject);
							 
	                    }
						else if(type.equals("SEQUENCE") || type.equals("BRANCH") || type.equals("LOOP") || type.equals("RETRY"))
	                    {
						
						  WMBlock wmblk_1=getBlockObject(nodeName,type,nodeDataSet[i]);
						  wmblk_1.id=seq+"."+i;	
						  (wmblk.sequencer).addElement(wmblk_1);
						  if(nodes != null) 
	                       	getSubFlowVars(nodeName,(Vector)nodes,wmblk_1,false);
						  wmblk_1.objectLocked=true;	
						
	                    }
	            } 
		}
	} 
	
	private static WMObject getWMObject(WMBlock wmblk,String id,String type)
	{
	 
	  WMObject wmobj=null;
	  boolean createNewObject=true;
	  if((wmblk.sequencer).size()>0)
	  {
	    Object obj=((wmblk.sequencer).elementAt((wmblk.sequencer).size() -1));
	    String cName=(obj.getClass()).getName();
	    if(cName.equals("com.vits.webm.var.WMObject"))
	    {
	      
	      WMObject wobj_1=(WMObject)obj;
	      if(type.equals("MAPINVOKE"))
	      {
	        if((wobj_1.type).equals("MAPINVOKE"))
	        {
	          wmobj=new WMObject();
			  wmobj.id=id;
	          wmobj.type=type;
		      (wmblk.sequencer).addElement(wmobj);
	          wmobj.droppedVariables=wobj_1.droppedVariables;
	        } 
	        else
	        {
	            wmobj=wobj_1; 
	          	wmobj.type=type;
	        }
	        createNewObject=false; 
		    
	      }
	      else if((!(wobj_1.objectLocked)) && ((wobj_1.type).equals("INVOKE")))
	       {
	         wmobj=wobj_1;
		     createNewObject=false;
	       }
	      else
	         createNewObject=true;
	    }
	    else
	      createNewObject=true;
	  } 
	  if(createNewObject)
	  { 
	  		wmobj=new WMObject();
			wmobj.id=id;
	        wmobj.type=type;
		    (wmblk.sequencer).addElement(wmobj);		
	  } 
	  return wmobj;   
	}
	private static WMBlock getBlockObject(String nodeName,String type,IData nodeSet)
	{
	  WMBlock wmblk=new WMBlock();
	  wmblk.nodeType=type;
	  
	  IDataCursor nodeSetCursor = nodeSet.getCursor();
	    IDataUtil.put( nodeSetCursor, "nodeName", nodeName);
	  nodeSetCursor.destroy();
	
	  IData 	output = IDataFactory.create();
	  try{
	
	     	output = Service.doInvoke( "PackageScanner.DocGen.util.blocks", "gen"+type, nodeSet );
	
	     }catch( Exception e){
	                           
	                         }
	
	     IDataCursor outputCursor = output.getCursor();
	
		output = IDataUtil.getIData( outputCursor, "output" );
		if ( output != null)
		{
	        String description=null;
			IDataCursor outputCursor_1 = output.getCursor();
				String	val = String.valueOf(IDataUtil.getString( outputCursor_1, "type" ));
				String[] vList=IDataUtil.getStringArray( outputCursor_1, "varList" );
				description=String.valueOf(IDataUtil.getString( outputCursor_1, "nodeDescription" ));
	        outputCursor_1.destroy();
			wmblk.nodeName=val;
			wmblk.addNodeDescription(description+"<BR>");
	        wmblk.addVariables(vList);
		}
	   outputCursor.destroy();
	   return wmblk;
	}
	
	private static void loadNodeVarDetails(String nodeName,String type,IData nodeSet,WMBlock wmblk,String comment)
	{
	  IDataCursor nodeSetCursor = nodeSet.getCursor();
	    IDataUtil.put( nodeSetCursor, "nodeName", nodeName);
	    IDataUtil.put( nodeSetCursor, "nodeName", comment);
	  nodeSetCursor.destroy();
	
	  IData 	output = IDataFactory.create();
	  try{
	
	     	output = Service.doInvoke( "PackageScanner.DocGen.util.verify", "gen"+type, nodeSet );
	
	     }catch( Exception e){
	                            
	                         }
	
	     IDataCursor outputCursor = output.getCursor();
	
		// output
		output = IDataUtil.getIData( outputCursor, "output" );
		if ( output != null)
		{
			loadVars(nodeName,output,wmblk);
		}
	   outputCursor.destroy();
	   
	}
	
	private static void getSubFlowVars(String nodeName,Vector vObj,WMBlock wmblk_1,boolean useSameObject)
	{
	  IData[] flowList=null;
	  flowList=new IData[vObj.size()];
	  for(int i=0;i<vObj.size();i++)
	  {
	    Object ob_2=(Object)vObj.elementAt(i);
	    String cName=(ob_2.getClass()).getName();
	    if(cName.equals("com.wm.data.ISMemDataImpl"))
	     flowList[i]=(IData)ob_2;
	    else
	    {  
	        com.wm.lang.flow.FlowElement ob_1=(com.wm.lang.flow.FlowElement)vObj.elementAt(i);
	    	flowList[i]=ob_1.getAsData();
	    } 
	    
	  }
	  
	  getFlowVariables(nodeName,flowList,wmblk_1,useSameObject);
	
	}
	
	private static void loadVars(String nodeName,IData output,WMBlock wmblk_1)
	{
	
	 WMObject wobj=(WMObject)((wmblk_1.sequencer).elementAt((wmblk_1.sequencer).size() -1));
	 wobj.serviceName= nodeName;
	 String description=null; 
	 IDataCursor outputCursor_1 = output.getCursor();
				String	type_1 = IDataUtil.getString( outputCursor_1, "type" );
				String	mode = IDataUtil.getString( outputCursor_1, "mode" );
				String	val = String.valueOf(IDataUtil.getString( outputCursor_1, "val" ));
				String	src = String.valueOf(IDataUtil.getString( outputCursor_1, "src" ));
				String	tgt = String.valueOf(IDataUtil.getString( outputCursor_1, "tgt" ));
	            String[] cList=IDataUtil.getStringArray( outputCursor_1, "clearVars" );
	            String[] vList=IDataUtil.getStringArray( outputCursor_1, "varList" );
				String ref_flowname=IDataUtil.getString( outputCursor_1, "ref_flowname" );
				String[] inputs=IDataUtil.getStringArray( outputCursor_1, "inputs" );
				String[] outputs=IDataUtil.getStringArray( outputCursor_1, "outputs" );
				description = IDataUtil.getString( outputCursor_1, "nodeDescription" );
	 outputCursor_1.destroy();
	
	 if(type_1 .equals("MAP"))
	 {
	    wobj.addVariables(vList);
	    wobj.mode=mode;
	   wobj.addNodeDescription(description+"<BR>");
	 }
	 else if(type_1 .equals("MAPCOPY"))
	 {   
	   wobj.addElementDescription(description+"<BR>");
	   if((wobj.type).equals("MAPINVOKE"))
	   {
	       if((wobj.mode).equals("INVOKEINPUT"))
	         wobj.addVariable(src);
	       else  
	         wobj.addVariable(tgt);	
	   }
	   else
	   {
	      wobj.addVariable(src);
		  wobj.addVariable(tgt);	
	   }
	 }
	 else if(type_1 .equals("MAPSET"))
	 {
	   wobj.addElementDescription(description+"<BR>");
	   if((wobj.type).equals("MAPINVOKE"))
	   {
	   }
	   else
	     wobj.addVariable(val); 
	
	   if(cList != null)
	       wobj.clearPipelineVars=cList;    
	 }
	 else if(type_1 .equals("MAPDELETE")) 
	 {
	     wobj.dropVariable(val);
	 }
	 else if(type_1 .equals("INVOKE")) 
	 {
	     wobj.addVariables(vList);
	     wobj.addNodeDescription(description+"<BR>");
	     wobj.invokeServiceName=ref_flowname;
		 wobj.serviceName=ref_flowname;	
	     wobj.setServiceInputs(inputs);
	     wobj.setServiceOutputs(outputs); 
		 
	 }  
	 else if(type_1 .equals("MAPINVOKE")) 
	 {
	     wobj.addNodeDescription(description+"<BR>");
	     wobj.invokeServiceName=ref_flowname;
		 wobj.serviceName=ref_flowname;	
	     wobj.setServiceInputs(inputs);
	     wobj.setServiceOutputs(outputs);      
	 }  
	
	
	}
	
	private static Vector parseWMBlock(WMBlock wmblk,Vector vObj,String pNodeType,boolean includeDels)
	{
	  Vector v_1=wmblk.sequencer;
	  Vector pipeTracker=new Vector();
	  for(int i=0;i<v_1.size();i++)
	  { 
	    Object obj=v_1.elementAt(i);
	    String cName=(obj.getClass()).getName();
	    if(cName.equals("com.vits.webm.var.WMBlock"))
	    {
		  WMBlock wmblk_3=(WMBlock)obj; 
	      String nodeType=wmblk_3.nodeType;
	      Vector v_2=new Vector((Collection)vObj);
	      v_2=parseWMBlock(wmblk_3,v_2,nodeType,includeDels);
	      if(pNodeType.equals("BRANCH"))
	      	pipeTracker.addElement(v_2);  
	      else
	        vObj=v_2;     
	    }
	    else
	    {
	      Vector v_3=new Vector((Collection)vObj);	
	      parseWMObject((WMObject)obj,v_3,includeDels);
		  if(pNodeType.equals("BRANCH"))
	      	pipeTracker.addElement(v_3);
	      else
	         vObj=v_3;	  	
	     }
	     
	  }  
	  if(pNodeType.equals("BRANCH"))
	  {	
	    checkBranchVariables(vObj,pipeTracker);
		pipeTracker.clear();
		pipeTracker=null;
	  }
	 return vObj; 
	}
	private static void parseWMObject(WMObject wmobj,Vector vObj,boolean includeDels)
	{
	   Vector v_2=wmobj.droppedVariables;
	   Vector v_3=wmobj.declaredVariables;
	   if(wmobj.clearPipelineVars != null)
	   {
	      vObj.clear();
	      for(int i=0;i<(wmobj.clearPipelineVars).length;i++)
	      {
	         vObj.addElement((wmobj.clearPipelineVars)[i]);
	      }
	   }    
	  if(v_3.size()>0)
	   {
	     for(int k1=0;k1<v_3.size();k1++)
	     {
	       
	       if(!vObj.contains(v_3.elementAt(k1)))
		   {
	          vObj.addElement(v_3.elementAt(k1));
	           
	       }  
	     }
	   } 	
	   if(includeDels && (v_2.size()>0))
	   {
	     for(int k=0;k<v_2.size();k++)
	     {
	       vObj.remove(v_2.elementAt(k));
	       
	     }
	   } 
	
	}
	private static void checkBranchVariables(Vector vObj,Vector pipeTracker)
	{
	  String[] tstr=new String[vObj.size()];
	  vObj.toArray(tstr);  
	  for(int i=0;i<tstr.length;i++)
	  {
	    boolean dropVar=false;
	    for(int k=0;k<pipeTracker.size();k++)
	    {
	      Vector v_11=(Vector)pipeTracker.elementAt(k);
	      if(!v_11.contains(tstr[i])) 
	        dropVar=true;
	      else
	        dropVar=false;         
	    }     
	    if(dropVar)
	     vObj.remove(tstr[i]);
	  } 
	
	  for(int p=0;p<pipeTracker.size();p++)
	  {
	      Vector v_11=(Vector)pipeTracker.elementAt(p);
	      addAdditonalVars(vObj,v_11);     
	  }  
	
	}
	private static void addAdditonalVars(Vector vObj,Vector vTemp)
	{
	  String[] tStr=new String[vTemp.size()];
	  vTemp.toArray(tStr);	
	  for(int i=0;i<tStr.length;i++)
	  {
	    if(!vObj.contains(tStr[i]))
	    {
	      vObj.addElement(tStr[i]);
	    } 
	  }
	
	}
	
	private static String[] getStringList(Vector vObj)
	{
	  String[]  list=null;
	  if((vObj != null) && (vObj.size()>0))
	  {
	  		list=new String[vObj.size()];
	  		vObj.toArray(list);
	  }
	  return list;
	}
	
	//------------------- Design Doc---------------------------------------
	
	private static void getDesignDoc(WMBlock wmblk,StringBuffer sbf,String pNodeType,String id,String spaces)
	{
	  String tStr=spaces;
	  Vector v_1=wmblk.sequencer;
	  Vector pipeTracker=new Vector();
	  for(int i=0;i<v_1.size();i++)
	  { 
	    Object obj=v_1.elementAt(i);
	    String cName=(obj.getClass()).getName();
	    if(cName.equals("com.vits.webm.var.WMBlock"))
	    {
		  WMBlock wmblk_3=(WMBlock)obj;
	      String bStr=wmblk_3.getPartDoc(tStr);
	      String nodeType=wmblk_3.nodeType;
	      if((wmblk_3.id).equals(id))
	   		sbf.append("<font color=red><B>"+bStr+"</B></font>");
	      else
	        sbf.append(bStr); 
	      getDesignDoc(wmblk_3,sbf,nodeType,id,tStr+"&nbsp;&nbsp;&nbsp;");     
	    }
	    else
	    {
	       WMObject wobj=(WMObject)obj;
	       String str=wobj.getPartDoc(tStr);
	       if((wobj.id).equals(id))
	        str="<font color=red><B>"+str+"</B></font>";
	       sbf.append(str); 
	    }
	  }  
	}
	
	//------------Var drop location----------------------------------------------
	
	private static void getVarUsageLoc(WMBlock wmblk,String pNodeType,String[] varNames,Hashtable refStore)
	{
	  Vector v_1=wmblk.sequencer;
	  for(int i=0;i<v_1.size();i++)
	  { 
	    Object obj=v_1.elementAt(i);
	    String cName=(obj.getClass()).getName();
	    if(cName.equals("com.vits.webm.var.WMBlock"))
	    {
		  WMBlock wmblk_3=(WMBlock)obj;
		  String nodeType=wmblk_3.nodeType;
	      for(int j=0;j<varNames.length;j++)
	      {
	        if(wmblk_3.isVarReferenced(varNames[j]))
	        {
	          if(refStore.containsKey(varNames[j]))
	               refStore.remove(varNames[j]);
	          refStore.put(wmblk_3.id,wmblk);
	        } 	    
	      }	
	      getVarUsageLoc(wmblk_3,nodeType,varNames,refStore);     
	    }
	    else
	    {
	      WMObject wmobj=(WMObject)obj; 
	      for(int j=0;j<varNames.length;j++)
	      {
	      	if(wmobj.isVarReferenced(varNames[j]))
	        {
	          if(refStore.containsKey(varNames[j]))
	               refStore.remove(varNames[j]);
	          refStore.put(wmobj.id,wmblk);
	        } 	    
	      }
	    }   
	  } 
	
	
	}
	
	private static void getVarsUsedByLabels(String label,Vector vObj)
	{ 
	  int inx=label.indexOf("%");
	  if(inx != -1)
	  {
	    String tStr=label.substring((inx+1),label.length());
	    int inx_1=tStr.indexOf("%");
	    if(inx_1 != -1)
	    {
	      String elem=tStr.substring(0,inx_1);
	      vObj.addElement(elem);
	      tStr=tStr.substring((inx_1+1),tStr.length());
	      getVarsUsedByLabels(tStr,vObj);
	    }
	  } 
	}
	
	
	//--=============================================
	private static Vector parseWMBlk(WMBlock wmblk,Vector vObj,String pNodeType,boolean includeDels)
	{
	
	  Vector v_1=wmblk.sequencer;
	  Vector pipeTracker=new Vector();
	  for(int i=0;i<v_1.size();i++)
	  { 
	    Object obj=v_1.elementAt(i);
	    String cName=(obj.getClass()).getName();
	    if(cName.equals("com.vits.webm.var.WMBlock"))
	    {
		  WMBlock wmblk_3=(WMBlock)obj; 
	      String nodeType=wmblk_3.nodeType;
	      Vector v_2=new Vector((Collection)vObj);
	      v_2=parseWMBlk(wmblk_3,v_2,nodeType,includeDels);
	      if(pNodeType.equals("BRANCH"))
	      	pipeTracker.addElement(v_2);  
	      else
	        vObj=v_2;     
	    }
	    else
	    {
	      Vector v_3=new Vector((Collection)vObj);	
	      parseWMObj((WMObject)obj,v_3,includeDels);
		  if(pNodeType.equals("BRANCH"))
	      	pipeTracker.addElement(v_3);
	      else
	         vObj=v_3;	  	
	     }
	     
	  }  
	  if(pNodeType.equals("BRANCH"))
	  {	
	    checkBranchVariables(vObj,pipeTracker);
		pipeTracker.clear();
		pipeTracker=null;
	  }
	 return vObj; 
	}
	
	private static void parseWMObj(WMObject wmobj,Vector vObj,boolean includeDels)
	{
	   Vector v_2=wmobj.droppedVariables;
	      Vector v_3=wmobj.declaredVariables;
	      if(wmobj.clearPipelineVars != null)
	      {
	         vObj.clear();
	         for(int i=0;i<(wmobj.clearPipelineVars).length;i++)
	         {
	            vObj.addElement((wmobj.clearPipelineVars)[i]);
	         }
	      }    
	     
	      if(includeDels && (v_2.size()>0))
	      {
	        for(int k=0;k<v_2.size();k++)
	        {
	          vObj.addElement(v_2.elementAt(k));
	          
	        }
	   } 
	}
	
	
	//***********************
	//-----------------------------*************************-----------------------------
	 
	private static Hashtable getMapSteps(String nodeName,IData[] nodeDataSet,WMBlock wmblk,boolean useSameObject,String stepType, Hashtable H)
	{
	  String seq=wmblk.id;
	  
	 
	  for ( int i = 0; i < nodeDataSet.length; i++ )
	   {
				IDataCursor nodeDataSetCursor = nodeDataSet[i].getCursor();
					Object	nodes = IDataUtil.get( nodeDataSetCursor, "nodes" );
	                String	type = IDataUtil.getString( nodeDataSetCursor, "type" );
	                String	comment = IDataUtil.getString( nodeDataSetCursor, "comment" );
				nodeDataSetCursor.destroy();
	           
	            if(! (type==null))
	            { 
	                    if(type.equals("MAP") || type.equals("MAPEXIT"))
						{      
						
						
	                                        
	                                     if(!(stepType.equals("INVOKE") || stepType.equals("MAPINVOKE"))){
	                                            if((comment == null) || (comment == "")) {
	                                           
	                                            H.put("result","false");
	                                                  }
	                                           }
	                                             
						  WMObject wmobj=null; 	
	                      if(useSameObject)
	                        wmobj=(WMObject)((wmblk.sequencer).elementAt((wmblk.sequencer).size() -1));
	                      else     
	                         wmobj=getWMObject(wmblk,seq+"_"+i,type);
						  loadNodeVarDetails(nodeName,type,nodeDataSet[i],wmblk,comment);
						  String serviceName=null;	
						  if((wmblk.sequencer).size()>0)	
	                      {
						      WMObject wO_1=(WMObject)((wmblk.sequencer).elementAt((wmblk.sequencer).size() -1));
							  serviceName=wO_1.serviceName;		
	                      }
	                      else
							  serviceName=nodeName;			
	                      if(nodes != null)
	                        getSubVars(serviceName,(Vector)nodes,wmblk,useSameObject,type,H);
	
	                      if(!useSameObject)  
	                          wmobj.objectLocked=true;
						   	
	                    }      
	                    else if(type.equals("INVOKE") || type.equals("MAPINVOKE"))
						{      
	                               
	                      WMObject wmobj=getWMObject(wmblk,seq+"_"+i,type);
						  loadNodeVarDetails(nodeName,type,nodeDataSet[i],wmblk,comment);
						  String serviceName=null;	
						  if((wmblk.sequencer).size()>0)	
	                      {
						      WMObject wO_1=(WMObject)((wmblk.sequencer).elementAt((wmblk.sequencer).size() -1));
							  serviceName=wO_1.serviceName;		
	                      }
	                      else
							  serviceName=nodeName;			
	                      if(nodes != null)
	                        getSubVars(serviceName,(Vector)nodes,wmblk,true,type,H);
	
	                      wmobj.objectLocked=true;
						  	
	                    }  					        
						else if(type.equals("MAPSET") || type.equals("MAPCOPY") || type.equals("MAPDELETE"))
	                    {
	                        
	                        String serviceName=null;	 
							if((wmblk.sequencer).size()>0)	
	                      	{
						      WMObject wO_1=(WMObject)((wmblk.sequencer).elementAt((wmblk.sequencer).size() -1));
							  serviceName=wO_1.serviceName;		
	                      	}
	                     	 else
							  	serviceName=nodeName;
							loadNodeVarDetails(serviceName,type,nodeDataSet[i],wmblk,comment);
							if(nodes != null)
	                        	getSubVars(serviceName,(Vector)nodes,wmblk,useSameObject,type,H);
							 
	                    }
						else if(type.equals("SEQUENCE") || type.equals("BRANCH") || type.equals("LOOP") || type.equals("RETRY"))
	                    {
						
						  WMBlock wmblk_1=getBlockObject(nodeName,type,nodeDataSet[i]);
						  wmblk_1.id=seq+"."+i;	
						  (wmblk.sequencer).addElement(wmblk_1);
						  if(nodes != null) 
	                       	getSubVars(nodeName,(Vector)nodes,wmblk_1,false,type,H);
						  wmblk_1.objectLocked=true;	
						
	                    }
	            } 
		}
		return H;
	} 
	
	
	//**************************
	private static void getSubVars(String nodeName,Vector vObj,WMBlock wmblk_1,boolean useSameObject,String stepname, Hashtable H)
	{
	  IData[] flowList=null;
	  flowList=new IData[vObj.size()];
	  for(int i=0;i<vObj.size();i++)
	  {
	    Object ob_2=(Object)vObj.elementAt(i);
	    String cName=(ob_2.getClass()).getName();
	    if(cName.equals("com.wm.data.ISMemDataImpl")){
	    
	            
	         flowList[i]=(IData)ob_2;
	         }
	    else
	    {  
	        com.wm.lang.flow.FlowElement ob_1=(com.wm.lang.flow.FlowElement)vObj.elementAt(i);
	    	flowList[i]=ob_1.getAsData();
	    	
	    } 
	    
	  }
	   
	   getMapSteps(nodeName,flowList,wmblk_1,useSameObject,stepname,H);
	
	}
	// --- <<IS-END-SHARED>> ---
}

