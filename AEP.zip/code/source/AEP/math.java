package AEP;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.math.BigDecimal;
// --- <<IS-END-IMPORTS>> ---

public final class math

{
	// ---( internal utility methods )---

	final static math _instance = new math();

	static math _newInstance() { return new math(); }

	static math _cast(Object o) { return (math)o; }

	// ---( server methods )---




	public static final void addFloats (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(addFloats)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required num1
		// [i] field:0:required num2
		// [o] field:0:required value
		IDataCursor idc = pipeline.getCursor();
		
		String num1 = (String)IDataUtil.get(idc, "num1");
		String num2 = (String)IDataUtil.get(idc, "num2");
		
		BigDecimal bd1 = new BigDecimal(num1);
		BigDecimal bd2 = new BigDecimal(num2);
		
		BigDecimal bdTotal = bd1.add(bd2);
		
		IDataUtil.put(idc, "value", bdTotal.toString());
		
		idc.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void divideFloats (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(divideFloats)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required num1
		// [i] field:0:required num2
		// [i] field:0:required scale
		// [o] field:0:required value
		IDataCursor idc = pipeline.getCursor();
		
		String num1 = (String)IDataUtil.get(idc, "num1");
		String num2 = (String)IDataUtil.get(idc, "num2");
		String scale = (String)IDataUtil.get(idc, "scale");
		
		BigDecimal bd1 = new BigDecimal(num1);
		BigDecimal bd2 = new BigDecimal(num2);
		int scaleInt = new Integer(scale).intValue();
		
		BigDecimal bdTotal = bd1.divide(bd2, scaleInt, BigDecimal.ROUND_HALF_DOWN);
		
		IDataUtil.put(idc, "value", bdTotal.toString());
		
		idc.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void mod (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(mod)>> ---
		// @sigtype java 3.5
		// [i] field:0:required num1
		// [i] field:0:required num2
		// [o] field:0:required mod
		Integer mod=0;
		IDataCursor idc = pipeline.getCursor();
		
		String num1 = (String)IDataUtil.get(idc, "num1");
		String num2 = (String)IDataUtil.get(idc, "num2");
		
		Integer int1 = Integer.parseInt(num1);
		Integer int2 = Integer.parseInt(num2);
		
		mod = int1 % int2;
		
		IDataUtil.put(idc, "mod", mod.toString());
		
		idc.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void multiplyFloats (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(multiplyFloats)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required num1
		// [i] field:0:required num2
		// [o] field:0:required value
		IDataCursor idc = pipeline.getCursor();
		
		String num1 = (String)IDataUtil.get(idc, "num1");
		String num2 = (String)IDataUtil.get(idc, "num2");
		
		BigDecimal bd1 = new BigDecimal(num1);
		BigDecimal bd2 = new BigDecimal(num2);
		
		BigDecimal bdTotal = bd1.multiply(bd2);
		
		IDataUtil.put(idc, "value", bdTotal.toString());
		
		idc.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void roundToInt (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(roundToInt)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required dblValue
		// [o] field:0:required intValue
		
		IDataCursor pipelineCursor = pipeline.getCursor();
		        String str= String.valueOf(IDataUtil.getString( pipelineCursor, "dblValue" ));        	
		pipelineCursor.destroy();
		String intValue=null; 
		if(!(str.equals("null")))
		 {
		   long l=Math.round(Double.parseDouble(str));
		   int ival=(new Long(l)).intValue();
		   intValue=Integer.toString(ival);
		 }
		
		
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		if(intValue != null)
		 IDataUtil.put( pipelineCursor_1, "intValue", intValue);
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void subtractFloats (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(subtractFloats)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required num1
		// [i] field:0:required num2
		// [o] field:0:required value
		IDataCursor idc = pipeline.getCursor();
		
		String num1 = (String)IDataUtil.get(idc, "num1");
		String num2 = (String)IDataUtil.get(idc, "num2");
		
		BigDecimal bd1 = new BigDecimal(num1);
		BigDecimal bd2 = new BigDecimal(num2);
		
		BigDecimal bdTotal = bd1.subtract(bd2);
		
		IDataUtil.put(idc, "value", bdTotal.toString());
		
		idc.destroy();
		// --- <<IS-END>> ---

                
	}
}

