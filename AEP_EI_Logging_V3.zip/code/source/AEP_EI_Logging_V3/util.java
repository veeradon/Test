package AEP_EI_Logging_V3;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import com.wm.app.b2b.server.ISRuntimeException;
import com.wm.app.b2b.server.InvokeState;
import java.util.*;
import com.wm.lang.ns.NSName;
import com.wm.app.b2b.server.ns.Namespace;
import com.wm.app.b2b.server.ServiceThread;
// --- <<IS-END-IMPORTS>> ---

public final class util

{
	// ---( internal utility methods )---

	final static util _instance = new util();

	static util _newInstance() { return new util(); }

	static util _cast(Object o) { return (util)o; }

	// ---( server methods )---




	public static final void buildKeyValuePairs (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(buildKeyValuePairs)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] record:0:required inDoc
		// [o] record:1:required outDoc
		Hashtable h = new Hashtable();
		// pipeline
		int i=0;
		
		IDataCursor pipelineCursor = pipeline.getCursor();
		
			// inDoc
			IData	inDoc = IDataUtil.getIData( pipelineCursor, "inDoc" );
			if ( inDoc != null)
			{
		                IDataCursor inDocCursor = inDoc.getCursor();
		              while(inDocCursor.next())
		   			 {
		                                String tempVal = (String) (inDocCursor.getValue());
		                              if(inDocCursor.getValue() == null){
		                                     tempVal = "";
		                                  }
		                              h.put(inDocCursor.getKey(),tempVal);
		
		                         }//while
		
		                   Enumeration enum_1=h.keys();
		                      IData[]	outDoc = new IData[h.size()];
		           while(enum_1.hasMoreElements())
		           {
		
		                          outDoc[i] = IDataFactory.create();
		                          IDataCursor outDocCursor = outDoc[i].getCursor();
		                          String key_1=(String)enum_1.nextElement();
					  String val_1 = (String)h.get(key_1);
					  IDataUtil.put( outDocCursor, "key", key_1 );
					   IDataUtil.put( outDocCursor, "value", val_1 );
					   outDocCursor.destroy();
		                             i++;
		   			 }//while
		                      // pipeline
				IDataCursor pipelineCursor_1 = pipeline.getCursor();
				IDataUtil.put( pipelineCursor_1, "outDoc", outDoc );
				pipelineCursor_1.destroy();
		
			}
		pipelineCursor.destroy();
		
			
		// --- <<IS-END>> ---

                
	}



	public static final void doThreadInvoke (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(doThreadInvoke)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required svcName
		// [i] record:0:required input
		// [o] record:0:required results
		IDataCursor idc = pipeline.getCursor();
		
		//get inputs
		String svcName=null;
		NSName svcNSName=null; 
		IData input = IDataFactory.create();
		 
		if (idc.first("svcName")) {
		  svcName=IDataUtil.getString(idc,"svcName");
		} else {
		  throw new ServiceException("Parameter 'svcName' must be provided");
		}
		if (idc.first("input")) {
		  input=IDataUtil.getIData(idc,"input");
		} 
		//call isValidService to determine whether service exists in this namespace
		if (!(isValidService(svcName))) {
		 throw new ServiceException("Error: service name " + svcName + " does not exist.");
		}
		svcNSName = NSName.create(svcName);
		try{ 
		  IData results=IDataFactory.create();
		  IData inputClone = IDataUtil.deepClone(input);
		  ServiceThread  svcThread = Service.doThreadInvoke(svcNSName, inputClone);
		  //results = Service.doThreadInvoke(svcNSName, inputClone);
		  results = svcThread.getIData();
		  if (idc.first("results")) idc.delete();
		  idc.insertAfter("results",results);
		} catch (Exception ex) {
		  throw new ServiceException("The following exception occured while invoking service \"" + svcName + "\" - \n" + ex);
		} finally {
		  idc.destroy();
		}
		// --- <<IS-END>> ---

                
	}



	public static final void getContextId (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getContextId)>> ---
		// @sigtype java 3.5
		// [o] field:0:required contextId
		String[] contextStack;
		String contextId = "";
		try{
			   contextStack = InvokeState.getCurrentState().getAuditRuntime().getContextStack();
			   if(contextStack != null){
				   if(contextStack.length == 1){
					   contextId = contextStack[0];
				   }else if(contextStack.length == 2){
					   contextId = contextStack[0];
				   }else {
					   contextId = contextStack[1];
				   }
			   }	
			                                
			}catch(Exception ex){
			                ServiceException sx = new ServiceException(ex);
			                throw sx;
			}
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put(pipelineCursor_1, "contextId", contextId);
		pipelineCursor_1.destroy();	
		// --- <<IS-END>> ---

                
	}



	public static final void modInts (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(modInts)>> ---
		// @sigtype java 3.5
		// [i] field:0:required num1
		// [i] field:0:required num2
		// [o] field:0:required mod
		//long mod=0;
		IDataCursor idc = pipeline.getCursor();
		
		String num1 = (String)IDataUtil.get(idc, "num1");
		String num2 = (String)IDataUtil.get(idc, "num2");
		
		//Integer int1 = Integer.parseInt(num1);
		
		Long int1 = Long.parseLong(num1);
		
		Integer int2 = Integer.parseInt(num2);
		
		Long mod = int1 % int2;
		
		
		int result =mod.intValue();
		
		IDataUtil.put(idc, "mod", Integer.toString(result));
		
		idc.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void retryOrNot (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(retryOrNot)>> ---
		// @sigtype java 3.5
		// [i] field:0:required errorType
		// [o] field:0:required exceptionForRetry
		IDataCursor cursor = pipeline.getCursor();
		
		String errorType = IDataUtil.getString(cursor, "errorType");
		String exceptionForRetry = "false";
		
		//		if (errorType.equals("com.wm.pkg.art.error.DetailedServiceException") || errorType.equals("com.wm.app.b2b.server.ISRuntimeException") || ("com.wm.pkg.art.error.DetailedSystemException")  )
				
		if (errorType.equals("com.wm.pkg.art.error.DetailedSystemException") || errorType.equals("com.wm.app.b2b.server.ISRuntimeException"))
		{
		  exceptionForRetry = "true";
		}
		else
		{
		  Class clazz = null;
		  try
		  {
		    clazz = Class.forName(errorType);
		    Object obj = clazz.newInstance();
		    if (obj instanceof ISRuntimeException)
		    {
		      exceptionForRetry = "true";
		    }
		  }
		  catch (Exception e)
		  {
		    e.printStackTrace();
		  }
		}
		IDataUtil.put(cursor, "exceptionForRetry", exceptionForRetry);
		cursor.destroy();
		
			
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	static Reader getReader(IDataCursor cursor, String key)
	{
	  Reader reader = null;
	  if (cursor.first(key))
	  {
	    Object o = cursor.getValue();
	    if (o == null)
	    {
	      reader = new StringReader("");
	    }
	    else if (o instanceof BufferedReader)
	    {
	      reader = (BufferedReader) o;
	    }
	    else if (o instanceof Reader)
	    {
	      reader = new BufferedReader((Reader) o);
	    }
	    else if (o instanceof InputStream)
	    {
	      reader = new BufferedReader(new InputStreamReader((InputStream) o));
	    }
	    else if (o instanceof String)
	    {
	      reader = new BufferedReader(new StringReader((String) o));
	    }
	    else if (o instanceof byte[])
	    {
	      reader = new BufferedReader(new InputStreamReader(new ByteArrayInputStream((byte[]) o)));
	    }
	  }
	  return reader;
	
	}
	
	static Writer getWriter(IDataCursor cursor, String key)
	{
	  Writer writer = new StringWriter();
	  if (cursor.first(key))
	  {
	    Object o = cursor.getValue();
	    if (o == null)
	    {
	      return writer;
	    }
	    else if (o instanceof BufferedWriter)
	    {
	      writer = (BufferedWriter) o;
	    }
	    else if (o instanceof Writer)
	    {
	      writer = new BufferedWriter((Writer) o);
	    }
	    else if (o instanceof OutputStream)
	    {
	      writer = new BufferedWriter(new OutputStreamWriter((OutputStream) o));
	    }
	    
	    }
	  return writer;
	
	}
	
	public static boolean isValidService(String svcName) throws ServiceException {
		  //verify that the service exists in the current namespace
		  try {
		    //create NSName object from fully qualified service name
		     NSName svc = NSName.create(svcName);
		     //create Namespace object for current namespace
		     Namespace nspace = Namespace.current();
		     //use nodeExists method to test for existence of specified service name in the current namespace
		     if (nspace.nodeExists(svc)) {
		  return true; 
		     } else {
		  return false;
		     }
		  } catch (Exception ex) {
		     return false;
		  }
		}
		
		public static boolean serviceExists(NSName svcNSName){
		boolean b = false;
		 Namespace namesp = Namespace.current();
		  b = namesp.nodeExists(svcNSName);
		return b;
		}
		
		public static void del_filler( String deleteKeyName, Object tmpPipe ) {
		  IDataCursor tpc = null;
		  if (tmpPipe instanceof IData) {
		    IData tmpO = (IData)tmpPipe;
		    tpc = tmpO.getCursor();
		  }
		
		  if (tmpPipe instanceof IData[]) {
		    IData idArray[] = (IData[])tmpPipe;
		    for (int n=0; n < idArray.length; n++) {
		      del_filler(deleteKeyName, idArray[n]);
		    }
		  return;
		  }
		
		  if (tpc == null) {return;} /* If the wrong object type is passed to del_filler, don't complain, just exit.  Keeping
		                                overhead down in deleting filler fields is more important than catching unusual exceptions */
		
		  if (tpc.first() == true) {
		    String key = "";
		    boolean more = true;
		    boolean del_flag = false;
		    while(more) {
		      del_flag = false;
		      key = tpc.getKey().toLowerCase();
		      Object tmpObj = tpc.getValue();
		      if (tmpObj instanceof IData || tmpObj instanceof IData[]) {
		        del_filler(deleteKeyName, tmpObj);
		      } else {
		        if (key.equals(deleteKeyName)) {
		          del_flag = true;
		        } 
		      }
		      if (del_flag) {
		        more = tpc.delete();
		      } else {
		        more = tpc.next();
		      }
		    }
		  }
		  tpc.destroy();
		}
	// --- <<IS-END-SHARED>> ---
}

