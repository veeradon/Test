package AEP;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2004-06-15 09:16:20 EDT
// -----( ON-HOST: arwhslas058x.aepsc.com

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.util.HashMap;
// --- <<IS-END-IMPORTS>> ---

public final class hash

{
	// ---( internal utility methods )---

	final static hash _instance = new hash();

	static hash _newInstance() { return new hash(); }

	static hash _cast(Object o) { return (hash)o; }

	// ---( server methods )---




	public static final void addItemToHashMap (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(addItemToHashMap)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] object:0:optional hashMap
		// [i] object:0:required addKey
		// [i] object:0:required addValue
		// [o] object:0:required hashMap
		IDataCursor idc = pipeline.getCursor();
		
		HashMap hashMap = (HashMap)IDataUtil.get(idc, "hashMap");
		if (hashMap == null)
		{
		    hashMap = new HashMap();
		}
		
		Object addKey = IDataUtil.get(idc, "addKey");
		Object addValue = IDataUtil.get(idc, "addValue");
		
		hashMap.put(addKey, addValue);
		
		IDataUtil.put(idc, "hashMap", hashMap);
		
		idc.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getItemFromHashMap (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getItemFromHashMap)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] object:0:required hashMap
		// [i] object:0:required getKey
		// [o] object:0:required value
		IDataCursor idc = pipeline.getCursor();
		
		HashMap hashMap = (HashMap)IDataUtil.get(idc, "hashMap");
		Object getKey = IDataUtil.get(idc, "getKey");
		
		Object value = hashMap.get(getKey);
		
		IDataUtil.put(idc, "value", value);
		
		idc.destroy();
		// --- <<IS-END>> ---

                
	}
}

