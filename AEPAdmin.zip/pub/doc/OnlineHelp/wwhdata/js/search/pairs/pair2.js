function FileData_Pairs(x)
{
x.t("2007","-2015");
x.t("-2015","software");
x.t("integration","server");
x.t("administrator","integration");
x.t("administrator","window");
x.t("administrator","utility");
x.t("darmstadt","germany");
x.t("window","integration");
x.t("window","navigation");
x.t("software","darmstadt");
x.t("utility","2007");
x.t("navigation","server");
x.t("server","administrator");
}
