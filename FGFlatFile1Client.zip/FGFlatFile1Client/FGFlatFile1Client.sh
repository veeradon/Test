#!/bin/sh

# Path
PATH=/usr/java6/bin:/usr/bin:/etc:/usr/sbin:/usr/ucb:/appl/eisched/bin:/usr/bin/X11:/sbin:.;export PATH

#Log file Path settings --CHANGE THESE 2 LINES TO YOUR PREFERRED LOG LOCATION--
CONSOLELOG=/appl/sftpclient/WAM-SIT4/FGFlatFile1Client/batchlogs/console_SampleSFTP`date +%Y%m%d`.log
CONSOLEERRLOG=/appl/sftpclient/WAM-SIT4/FGFlatFile1Client/batchlogs/consoleErr_SampleSFTP`date +%Y%m%d`.log

# APP.PROPERTIES FILE TO USE --CHANGE TO YOUR PREFERRED LOG LOCATION--
APPPROPERTIES=/appl/sftpclient/WAM-SIT4/FGFlatFile1Client/app.properties

# Process to Launch
# Valid values include:
# com.aep.sftp.jobs.SFTPRetrieveJob
# 
#
APPRUNNAME=com.aep.sftpframework.jobs.SFTPRetrieveJob



# --DO NOT CHANGE ANYTHING UNDER THIS LINE --

#CLASSPATH file Path settings 
QUARTZ=/appl/sftp/lib
QUARTZ_CP=$QUARTZ_CP":/appl/sftpclient/SFTPClient.jar"
for jarfile in $QUARTZ/*.jar; 
do QUARTZ_CP=$QUARTZ_CP:$jarfile
done
CLASSPATH=$QUARTZ_CP; export CLASSPATH

INSTALL_DIR=/appl/sftpclient
APPSSL=-Djavax.net.ssl.trustStore=/appl/gsScheduler/cacerts

#add VM parameters if required 
#sample  -Xms1024M -Xmx1024M "
APPVM="-Xms512M -Xmx512M"

#Change to Application dir to pickup the log properties --DO NOT CHANGE--
CWD=`pwd`
cd $INSTALL_DIR
#Execute via shared code --DO NOT CHANGE--
. ./CommandLineExec.sh
cd $CWD
