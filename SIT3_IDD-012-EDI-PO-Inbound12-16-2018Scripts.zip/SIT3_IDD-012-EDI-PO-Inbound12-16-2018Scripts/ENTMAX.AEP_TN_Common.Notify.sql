delete from config_entry where config_group='ENTMAX.AEP_TN_Common.Notify';
--**************************************************************************************
--* CONFIGURATION INSERT SCRIPT.
--**************************************************************************************
Declare
TYPE adapter is varray(2) of VARCHAR2(500);
TYPE config is varray(5) of VARCHAR2(255);
TYPE configurations is varray(60) of config;
 
counter number;
key_val varchar2(255);
updateDate DATE;

adapter_name adapter := adapter('ENTMAX.AEP_TN_Common.Notify','ENTMAX.AEP_TN_Common.Notify object configurations');
configlist configurations :=configurations
(

config('emailInterfaceNotify','true','STRING','OTHER','TBD'),
config('emailOn_dataerror','smedapati@aep.com','STRING','OTHER','TBD'),
config('emailOn_default','smedapati@aep.com','STRING','OTHER','TBD'),
config('emailOn_fail','smedapati@aep.com','STRING','OTHER','TBD'),
config('emailOn_invalid','smedapati@aep.com','STRING','OTHER','TBD'),
config('emailOn_retryWarning','smedapati@aep.com','STRING','OTHER','TBD'),
config('emailOn_success','smedapati@aep.com','STRING','OTHER','TBD'),
config('emailOn_warning','smedapati@aep.com','STRING','OTHER','TBD')

);
Begin
 DBMS_OUTPUT.ENABLE(1000000);
 DBMS_OUTPUT.PUT_LINE('####@@@@START@@@@####'); 

 DBMS_OUTPUT.PUT_LINE('');
 
 DBMS_OUTPUT.PUT_LINE('**********VERIFYING ADAPTER**********'); 
 DBMS_OUTPUT.PUT_LINE('      ADAPTER-NAME ::'||adapter_name(1)); 
  
 select sysdate into updateDate from dual; 
 select count(*) into counter from config_groups where config_group=adapter_name(1);
  
 IF counter = 0 THEN
  
      DBMS_OUTPUT.PUT_LINE('            NEW ADAPTER :: ADDING NEW ADAPTER ' || adapter_name(1));
  
      insert into config_groups values(adapter_name(1),adapter_name(2),'ACTIVE'); 
  
      DBMS_OUTPUT.PUT_LINE('                    NEW ADAPTER :: SUCESSFULLY ADDED..' || ' NUMBER OF ROWS INSERTED ::::'|| SQL%ROWCOUNT);       
  
 END IF;
  
 DBMS_OUTPUT.PUT_LINE('**********VERIFYING CONFIGURATIONS**********'); 
  
 FOR i IN configlist.FIRST..configlist.LAST LOOP
       DBMS_OUTPUT.PUT_LINE('');      
       DBMS_OUTPUT.PUT_LINE('      VERIFYING CONFIGURATION FOR  CONFIG-KEY :: '||configlist(i)(1)|| '....');
       
       DBMS_OUTPUT.PUT_LINE('                VERIFYING CONFIG_CATEGORIES FOR  CONFIG-KEY :: '||configlist(i)(1)|| '....');
       select count(*) into counter from CONFIG_CATEGORIES where CONFIG_CATEGORY=configlist(i)(4);
       IF counter = 0 THEN
         insert into config_categories values(configlist(i)(4),configlist(i)(4),'FALSE','FALSE',updateDate,'IFWADMIN');
         DBMS_OUTPUT.PUT_LINE('                               INSERTED CONFIG_CATEGORY :: '||configlist(i)(4)); 
       ELSE
         DBMS_OUTPUT.PUT_LINE('                               NO CHANGE CONFIG_CATEGORY EXISTS'); 
       END IF;
       
       DBMS_OUTPUT.PUT_LINE('                 VERIFYING CONFIG_KEYTYPES FOR  CONFIG-KEY :: '||configlist(i)(1)|| '....');
       select count(*) into counter from CONFIG_KEY_TYPES where KEY_TYPE=configlist(i)(3);
       IF counter = 0 THEN
         insert into CONFIG_KEY_TYPES values(configlist(i)(3));
         DBMS_OUTPUT.PUT_LINE('                               INSERTED CONFIG_KEY_TYPE :: '||configlist(i)(3)); 
       ELSE
          DBMS_OUTPUT.PUT_LINE('                              NO CHANGE CONFIG_TYPE EXISTS'); 
       END IF;
       
              
       select count(*) into counter from config_entry where CONFIG_GROUP=adapter_name(1) and CONFIG_KEY=configlist(i)(1);
       
       IF counter = 0 THEN
      
         DBMS_OUTPUT.PUT_LINE('    ENTRY NOT FOUND, ADDING A NEW CONFIG....');
         
         INSERT INTO config_entry VALUES(adapter_name(1),configlist(i)(1),configlist(i)(2),configlist(i)(3),'ACTIVE','FALSE',sysdate,configlist(i)(4),configlist(i)(5),updateDate,'IFWADMIN');
         DBMS_OUTPUT.PUT_LINE('              NEW CONFIGURATION :: SUCESSFULLY ADDED..' || ' NUMBER OF ROWS INSERTED ::::'|| SQL%ROWCOUNT);       
         
       ELSE
         DBMS_OUTPUT.PUT_LINE('    CONFIGURATION ALREADY EXISTS, DELETING EXISTING CONFIGURATION....');
         delete from config_entry where CONFIG_GROUP=adapter_name(1) and CONFIG_KEY=configlist(i)(1);
         DBMS_OUTPUT.PUT_LINE('             CONFIGURATION ALREADY EXISTS, EXISTING CONFIGURATION DELETED,INSERTING NEW CONFIGURATION....');
         INSERT INTO config_entry VALUES(adapter_name(1),configlist(i)(1),configlist(i)(2),configlist(i)(3),'ACTIVE','FALSE',sysdate,configlist(i)(4),configlist(i)(5),updateDate,'IFWADMIN');
         DBMS_OUTPUT.PUT_LINE('             CONFIGURATION INSERTED..');
       END IF; 
       
       counter := NULL;
 END LOOP;
 DBMS_OUTPUT.PUT_LINE(''); 
 DBMS_OUTPUT.PUT_LINE('####@@@@END@@@@####');   
 
 DBMS_OUTPUT.PUT_LINE('');
 DBMS_OUTPUT.PUT_LINE('**********VERIFICATION STARTED**********');   
 SELECT count(*) into counter FROM config_entry WHERE CREATED_DATE=updateDate;
 DBMS_OUTPUT.PUT_LINE('      CONFIG_ENTRY ::: NUMBER ROWS EFFECTED :: '||counter);
 DBMS_OUTPUT.PUT_LINE('**********VERIFICATION ENDED**********');
 
End;
