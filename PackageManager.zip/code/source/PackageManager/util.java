package PackageManager;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2011-01-26 16:49:12 EST
// -----( ON-HOST: p2005049.aepsc.com

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.io.*;
import java.util.*;
import com.wm.app.b2b.server.*;
// --- <<IS-END-IMPORTS>> ---

public final class util

{
	// ---( internal utility methods )---

	final static util _instance = new util();

	static util _newInstance() { return new util(); }

	static util _cast(Object o) { return (util)o; }

	// ---( server methods )---




	public static final void clearObjs (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(clearObjs)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		pHash.clear();
		// --- <<IS-END>> ---

                
	}



	public static final void createFileHandle (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(createFileHandle)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required fileName
		// [o] object:0:required fileHandle
		 
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	fileName = IDataUtil.getString( pipelineCursor, "fileName" );
		pipelineCursor.destroy();
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		
		File fileHandle;
		if(fileName != null && fileName != "")
		{
			fileHandle = new File(fileName);
		}
		 
		else 
		{
			fileHandle = null;
		}
		
		IDataUtil.put( pipelineCursor_1, "fileHandle", fileHandle );
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getMultipleMappingValues (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getMultipleMappingValues)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required srcFile
		// [o] record:1:required ValuesList
		// [o] - field:0:required source
		// [o] - field:0:required tvalue1
		// [o] - field:0:required tvalue2
		// [o] - field:0:required tvalue3
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	srcFile = IDataUtil.getString( pipelineCursor, "srcFile" );
		pipelineCursor.destroy();
		Vector tempStore=new Vector();
		try
		 {
		   BufferedReader bfr=new BufferedReader(new InputStreamReader(new FileInputStream(srcFile)));
		   String str=null; 
		   while((str=bfr.readLine()) != null)
		    {
		      tempStore.addElement(str);
		    } 
		   bfr.close();
		
		 }catch(Exception e){
		                      throw(new ServiceException(e.toString()));
		                     }
		
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IData[]	ValuesList = new IData[tempStore.size()];
		for(int i=1;i<tempStore.size();i++)
		 {
		    ValuesList[i] = IDataFactory.create();
		    String str=(String)tempStore.elementAt(i);
		    StringTokenizer stk=new StringTokenizer(str,",");
		    String source=(String)stk.nextToken();
		    //String target1=(String)stk.nextToken();
		    //String target2=(String)stk.nextToken();
		    String target3=null;
		    if(stk.hasMoreTokens()) 
		      target3=(String)stk.nextToken(); 
		   
		    IDataCursor ValuesListCursor = ValuesList[i].getCursor();
		    IDataUtil.put( ValuesListCursor, "source", source );
		    //IDataUtil.put( ValuesListCursor, "tvalue1",target1 );
		   // IDataUtil.put( ValuesListCursor, "tvalue2",target2 );
		    if(target3 != null)
		      IDataUtil.put( ValuesListCursor, "tvalue3",target3 );
		    ValuesListCursor.destroy();
		 }
		IDataUtil.put( pipelineCursor_1, "ValuesList", ValuesList );
		pipelineCursor_1.destroy();
		
		// --- <<IS-END>> ---

                
	}



	public static final void getPackageVerForValidate (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getPackageVerForValidate)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required pacakgeName
		// [i] field:0:required tgtVersion
		// [i] field:0:required tgtnoOfElements
		// [i] field:0:required enabled
		// [o] field:0:required version
		// [o] field:0:required noOfElements
		// [o] field:0:required isEqual
		// [o] field:0:required enabled
		String version = "";
		String noOfElements = "";
		String isEqual = "false";
		String srcEnabled = "";
		String[] s = new String[3];
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	pacakgeName = IDataUtil.getString( pipelineCursor, "pacakgeName" );
		        String	tgtVersion = IDataUtil.getString( pipelineCursor, "tgtVersion" );
		        String	tgtnoOfElements = IDataUtil.getString( pipelineCursor, "tgtnoOfElements" );
		        String	enabled = IDataUtil.getString( pipelineCursor, "enabled" );
		  String value = (String)(pHash.get(pacakgeName));
		  if(value == null){
		     version = "Package not found";
		     noOfElements = "--";
		     }
		    else{
		      		 StringTokenizer st = new StringTokenizer(value,"_");
		          		  int i =0;
		              			 while (st.hasMoreTokens()) {
		            			 s[i] = st.nextToken();
		                                       i++;
		              
		          			 }
		
		        
		       			 version = s[0];
		       			 noOfElements = s[1];
		       			 srcEnabled = s[2];
		            if(enabled.equals("false")){
		                         noOfElements = "N/A";
		                     }
		           else if((version.equals(tgtVersion)) && (noOfElements.equals(tgtnoOfElements)) && (enabled.equals(srcEnabled))){
		                     isEqual = "";
		                    }
		        }
		
		pipelineCursor.destroy();
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "version", version );
		IDataUtil.put( pipelineCursor_1, "noOfElements", noOfElements);
		IDataUtil.put( pipelineCursor_1, "isEqual", isEqual);
		IDataUtil.put( pipelineCursor_1, "enabled", srcEnabled);
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getPackageVersion (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getPackageVersion)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required pacakgeName
		// [i] field:0:required tgtVersion
		// [i] field:0:required tgtnoOfElements
		// [o] field:0:required version
		// [o] field:0:required noOfElements
		// [o] field:0:required isEqual
		String version = "";
		String noOfElements = "";
		String isEqual = "false";
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	pacakgeName = IDataUtil.getString( pipelineCursor, "pacakgeName" );
		        String	tgtVersion = IDataUtil.getString( pipelineCursor, "tgtVersion" );
		        String	tgtnoOfElements = IDataUtil.getString( pipelineCursor, "tgtnoOfElements" );
		  String value = (String)(pHash.get(pacakgeName));
		  if(value == null){
		     version = "Package not found";
		     noOfElements = "--";
		     }
		    else{
		    
		        int indx = value.indexOf("_");
		        version = value.substring(0,indx);
		        noOfElements = value.substring(indx+1);
		           if((version.equals(tgtVersion)) && (noOfElements.equals(tgtnoOfElements))){
		                     isEqual = "";
		                    }
		        }
		
		pipelineCursor.destroy();
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "version", version );
		IDataUtil.put( pipelineCursor_1, "noOfElements", noOfElements);
		IDataUtil.put( pipelineCursor_1, "isEqual", isEqual);
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void hasAdmin (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(hasAdmin)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [o] object:0:required isAdmin
		 boolean isAdmin=false;
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	user = IDataUtil.getString( pipelineCursor, "user" );
		pipelineCursor.destroy();
		User sUser=Service.getUser();
		Vector v=sUser.membershipNames();
		Vector appGroups=new Vector();
		
		if((v.contains("MonitorAdministrators")) || (v.contains("Administrators")) || ((v.contains("ProductionManagement"))))
		 isAdmin = true;
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "isAdmin", (new Boolean(isAdmin)) );
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void isStringMatch (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(isStringMatch)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required packageName
		// [i] field:0:required pkgStrNameLike
		// [o] field:0:required isInclude
		boolean bol = false;
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	packageName = IDataUtil.getString( pipelineCursor, "packageName" );
			String	pkgStrNameLike = IDataUtil.getString( pipelineCursor, "pkgStrNameLike" );
		pipelineCursor.destroy();
		
		int indOf = packageName.indexOf(pkgStrNameLike);
		  if(indOf >=0){
		  bol = true;
		    }
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "isInclude", bol+"");
		pipelineCursor_1.destroy();
		
		// --- <<IS-END>> ---

                
	}



	public static final void isWmPackage (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(isWmPackage)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required packageName
		// [o] field:0:required isWmPkg
		
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	packageName = IDataUtil.getString( pipelineCursor, "packageName" );
		boolean bol = packageName.startsWith("Wm");
		pipelineCursor.destroy();
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "isWmPkg", bol+"");
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void isZiporWmFile (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(isZiporWmFile)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required inFileName
		// [o] field:0:required isZip
		// [o] field:0:required fileName
		String fileName = "";
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	inFileName = IDataUtil.getString( pipelineCursor, "inFileName" );
		pipelineCursor.destroy();
		String isZip = "false";
		boolean isWm = inFileName.startsWith ("Wm");
		boolean isPkgManager = inFileName.equals("PackageManager.zip");
		
		 if ( (isWm)|| (isPkgManager) ){
		        // don't include in the instalable packges.
		         }
		
		  else{
			int idx = inFileName.indexOf('.'); 
		  	if(idx>0){
		             String temp = inFileName.substring(idx+1);
		           int idxz = temp.indexOf('z'); 
		                if(idxz>=0)
		                    isZip = "true";
		                    fileName = inFileName.substring(0,idx);
		            }
		      }
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "isZip", isZip );
		IDataUtil.put( pipelineCursor_1, "fileName", fileName );
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void organizePkgs (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(organizePkgs)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:1:optional filenameList
		// [o] field:1:optional filenameOutList
		
		
		IDataCursor pipelineCursor = pipeline.getCursor();
			String[]	filenameList = IDataUtil.getStringArray( pipelineCursor, "filenameList" );
		pipelineCursor.destroy();
		
		int size = filenameList.length;
		
		
		String[] filenameOutList = new String[size];
		
		
		
		int codepkgcnt = 0;
		int processpkgcnt = size-1;
		
		for (int i=0;i<size;i++){
		
		   int processIndex = filenameList[i].lastIndexOf("_Process");
		          
		           if(processIndex>=0){
		              
		                 filenameOutList[processpkgcnt] = filenameList[i];
		                   processpkgcnt --;
		                 }
		           else
		                {
		                        filenameOutList[codepkgcnt] = filenameList[i];  
		                   codepkgcnt ++;
		              
		                 }
		         }
		
		
		
		
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		
		
		IDataUtil.put( pipelineCursor_1, "filenameOutList", filenameOutList );
		
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void sortStringList (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(sortStringList)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:1:required inStringList
		// [o] field:1:required outStringList
		IDataCursor pipelineCursor = pipeline.getCursor();
			String[]	inStringList = IDataUtil.getStringArray( pipelineCursor, "inStringList" );
		pipelineCursor.destroy();
		
		Arrays.sort(inStringList);
		
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "outStringList", inStringList );
		pipelineCursor_1.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void storeInstalledPackage (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(storeInstalledPackage)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		
			// PackageInfo
			IData	PackageInfo = IDataUtil.getIData( pipelineCursor, "PackageInfo" );
			if ( PackageInfo != null)
			{
				IDataCursor PackageInfoCursor = PackageInfo.getCursor();
		
					// i.Package
					IData[]	Package = IDataUtil.getIDataArray( PackageInfoCursor, "Package" );
					if ( Package != null)
					{
						for ( int i = 0; i < Package.length; i++ )
						{
							IDataCursor PackageCursor = Package[i].getCursor();
								String	packageName = IDataUtil.getString( PackageCursor, "packageName" );
								String	version = IDataUtil.getString( PackageCursor, "version" );
								String	noOfElements = IDataUtil.getString( PackageCursor, "noOfElements" );
		                                                String	enabled = IDataUtil.getString( PackageCursor, "enabled" );
		                                                String value = version + "_" + noOfElements+"_"+enabled;
		                                                  boolean b = pHash.containsKey(packageName);
		                                                           if(!b)
								             pHash.put(packageName,value);
							PackageCursor.destroy();
						}
					}
				PackageInfoCursor.destroy();
			}
		pipelineCursor.destroy();
		
		// pipeline
		// --- <<IS-END>> ---

                
	}



	public static final void threadSleep (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(threadSleep)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required noOfMilliSecs
		IDataCursor pipelineCursor = pipeline.getCursor();
			int noOfMilliSecs = Integer.parseInt(IDataUtil.getString( pipelineCursor, "noOfMilliSecs" ));
		pipelineCursor.destroy();
		
		try
		 {
		   Thread.sleep(noOfMilliSecs);
		
		 }catch(Exception e){
		                      throw(new ServiceException(e.toString()));
		                    }
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	private static Hashtable pHash = new Hashtable();
	// --- <<IS-END-SHARED>> ---
}

