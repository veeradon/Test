function FileData_Pairs(x)
{
x.t("2007","-2015");
x.t("-2015","software");
x.t("integration","cloud");
x.t("darmstadt","germany");
x.t("menu","integration");
x.t("menu","settings");
x.t("cloud","menu");
x.t("settings","screen");
x.t("software","darmstadt");
x.t("screen","2007");
x.t("screen","applications");
x.t("screen","accounts");
x.t("applications","screen");
x.t("accounts","screen");
}
