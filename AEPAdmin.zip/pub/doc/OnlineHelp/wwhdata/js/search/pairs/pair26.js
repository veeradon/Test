function FileData_Pairs(x)
{
x.t("publishing","packages");
x.t("2007","-2015");
x.t("-2015","software");
x.t("packages","menu");
x.t("packages","screen");
x.t("packages","management");
x.t("darmstadt","germany");
x.t("menu","packages");
x.t("software","darmstadt");
x.t("screen","publishing");
x.t("screen","2007");
x.t("screen","subscribing");
x.t("subscribing","screen");
x.t("management","screen");
}
