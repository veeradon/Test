package AEP.IO;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2005-09-29 14:16:05 EDT
// -----( ON-HOST: P3031248.aepsc.com

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
// --- <<IS-END-IMPORTS>> ---

public final class file

{
	// ---( internal utility methods )---

	final static file _instance = new file();

	static file _newInstance() { return new file(); }

	static file _cast(Object o) { return (file)o; }

	// ---( server methods )---




	public static final void createTempFile (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(createTempFile)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required prefix
		// [i] field:0:optional suffix
		// [i] field:0:optional directory
		// [o] object:0:required file
		// [o] field:0:required filename
		IDataCursor idc = pipeline.getCursor();
		String prefix = IDataUtil.getString(idc, "prefix");
		String suffix = IDataUtil.getString(idc, "suffix");
		String dir = IDataUtil.getString(idc, "directory");
		if((dir!=null) && (dir.trim().length() == 0))
		  dir = null;
		try
		{
		  java.io.File f = java.io.File.createTempFile(prefix, suffix, ((dir!=null)?new java.io.File(dir):null));
		  IDataUtil.put(idc, "file", f);
		  IDataUtil.put(idc, "filename", f.getCanonicalPath());
		}
		catch (java.io.IOException ioe)
		{
		  throw new ServiceException(ioe);
		}
		finally
		{
		  idc.destroy();
		}
		// --- <<IS-END>> ---

                
	}



	public static final void getName (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getName)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] object:0:required file
		// [o] field:0:required name
		IDataCursor idc = pipeline.getCursor();
		java.io.File f = (java.io.File)IDataUtil.get(idc, "file");
		
		IDataUtil.put(idc, "name", f.getName());
		idc.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getPath (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getPath)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] object:0:required file
		// [o] field:0:required pathname
		IDataCursor idc = pipeline.getCursor();
		java.io.File f = (java.io.File)IDataUtil.get(idc, "file");
		
		IDataUtil.put(idc, "pathname", f.getPath());
		idc.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void listFiles (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(listFiles)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:optional pathname
		// [i] object:0:optional fileFilter
		// [i] object:0:optional filenameFilter
		// [i] field:0:optional checkPathSecurity {"false","true"}
		// [o] object:1:required files
		// [o] field:0:required result
		IDataCursor idc = pipeline.getCursor();
		String pathname = IDataUtil.getString(idc, "pathname");
		Object fileFilter = IDataUtil.get(idc, "fileFilter");
		Object filenameFilter = IDataUtil.get(idc, "filenameFilter");
		boolean checkPathSecurity = IDataUtil.getBoolean(idc, "checkPathSecurity");
		String isValid = "true";
		
		// Set default - IS root
		if(pathname == null)	
		    pathname = ".";
		else if((pathname.trim()).length() == 0)
		    pathname = ".";
		
		if(checkPathSecurity)
		{
		    try
		    {
		        Values chk = new Values();
		        chk.put("action", "read");
		        chk.put("path", pathname);
		        Values chkResult = Service.doInvoke("PSUtilities.config", "checkPathValidity", chk);
		        isValid = chkResult.getString("valid");
		    }
		    catch (Exception e)
		    {
		        throw new ServiceException(e);
		    }
		}
		
		String result = "Access denied.";
		if("true".equals(isValid))
		{
		    java.io.File f = new java.io.File(pathname);
		    java.io.File[] l = null;
		    if(fileFilter != null)
		        l = f.listFiles((java.io.FileFilter)fileFilter);
		    else if(filenameFilter != null)
		        l = f.listFiles((java.io.FilenameFilter)filenameFilter);
		    else
		        l = f.listFiles();
		    if(l != null)
		    {
		        IDataUtil.put(idc, "files", l);
		        result = l.length + "";
		    }
		    else
		        result = "0";
		}
		IDataUtil.put(idc, "result", result);
		idc.destroy();
		// --- <<IS-END>> ---

                
	}
}

