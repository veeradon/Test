package AEPRestartsResource;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2013-01-16 19:09:22 EST
// -----( ON-HOST: roeiasd61

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.util.*;
import java.io.*;
// --- <<IS-END-IMPORTS>> ---

public final class util

{
	// ---( internal utility methods )---

	final static util _instance = new util();

	static util _newInstance() { return new util(); }

	static util _cast(Object o) { return (util)o; }

	// ---( server methods )---




	public static final void clearStores (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(clearStores)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		hPorts.clear();
		// --- <<IS-END>> ---

                
	}



	public static final void isExcludePort (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(isExcludePort)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required port
		// [o] field:0:required isExclude
		String isExclude = "false";
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	port = IDataUtil.getString( pipelineCursor, "port" );
		       try{
		          isExclude =  (String)(hPorts.get(port));
		          }catch(Exception e){
		                      
		                      }
		pipelineCursor.destroy();
		
		// pipeline
		IDataCursor pipelineCursor_1 = pipeline.getCursor();
		IDataUtil.put( pipelineCursor_1, "isExclude", isExclude);
		pipelineCursor_1.destroy();
		 
		// --- <<IS-END>> ---

                
	}



	public static final void loadPortPropsFromFile (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(loadPortPropsFromFile)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [o] field:1:required excludePorts
		// [o] field:0:optional propErrMsg
		Properties prop = new Properties();
		String[]	excludePorts = null;
		 String propErrMsg = "";
		    	try {
		               //load a properties file
		    		prop.load(new FileInputStream("packages/AEPRestartsResource/config/config.properties"));
		 
		               //get the property value 
		             String exclPorts = prop.getProperty("exclude_ports");
		              	excludePorts = exclPorts.split(",");
		  
		 
		    	} catch (IOException ex) {
		    		propErrMsg = ex.toString();
		          }
		
		
		// pipeline
		
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		IDataUtil.put( pipelineCursor, "excludePorts", excludePorts );
		IDataUtil.put( pipelineCursor, "propErrMsg", propErrMsg);
		pipelineCursor.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void storeExcludePorts (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(storeExcludePorts)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:1:required excludePorts
		
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String[]	excludePorts = IDataUtil.getStringArray( pipelineCursor, "excludePorts" );
		                     for(int i=0;i<excludePorts.length;i++){
		                             boolean bol = hPorts.containsKey(excludePorts[i]);
		                           if(!bol){
		                                  
		                               hPorts.put(excludePorts[i],"true");
		                                  }
		                                   else{
		                                        //ignore
		                                      }
		                       }
		pipelineCursor.destroy();
		
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	private static HashMap hPorts = new HashMap();
	// --- <<IS-END-SHARED>> ---
}

