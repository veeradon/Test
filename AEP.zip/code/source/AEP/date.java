package AEP;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2005-10-17 15:39:18 EDT
// -----( ON-HOST: P3031248.aepsc.com

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.util.*;
import java.text.*;
// --- <<IS-END-IMPORTS>> ---

public final class date

{
	// ---( internal utility methods )---

	final static date _instance = new date();

	static date _newInstance() { return new date(); }

	static date _cast(Object o) { return (date)o; }

	// ---( server methods )---




	public static final void addOrSubtractTime (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(addOrSubtractTime)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] object:0:required inDate
		// [i] object:0:required amount
		// [i] field:0:required field {"YEAR","MONTH","DAY","HOUR","MINUTE","SECOND","MILLISECOND"}
		// [o] object:0:required outDate
		IDataCursor idc = pipeline.getCursor();
		
		Date inDate = (Date)IDataUtil.get(idc, "inDate");
		int amount = ((Integer)IDataUtil.get(idc, "amount")).intValue();
		String field = (String)IDataUtil.get(idc, "field");
		
		int fieldInt = -1;
		if (field.equals("YEAR"))
		{
			fieldInt = Calendar.YEAR;
		}
		else if (field.equals("MONTH"))
		{
			fieldInt = Calendar.MONTH;
		}
		else if (field.equals("DAY"))
		{
			fieldInt = Calendar.DATE;
		}
		else if (field.equals("HOUR"))
		{
			fieldInt = Calendar.HOUR;
		}
		else if (field.equals("MINUTE"))
		{
			fieldInt = Calendar.MINUTE;
		}
		else if (field.equals("SECOND"))
		{
			fieldInt = Calendar.SECOND;
		}
		else if (field.equals("MILLISECOND"))
		{
			fieldInt = Calendar.MILLISECOND;
		}
		
		Calendar inDateCal = Calendar.getInstance();
		inDateCal.setTime(inDate);
		inDateCal.add(fieldInt, amount);
		
		IDataUtil.put(idc, "outDate", inDateCal.getTime());
		
		idc.destroy();
		
		// --- <<IS-END>> ---

                
	}



	public static final void calculateDateDifference (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(calculateDateDifference)>> ---
		// @sigtype java 3.5
		// [i] field:0:required startDateTime
		// [i] field:0:required endDateTime
		// [i] field:0:required startDateFormat
		// [i] field:0:required endDateFormat
		// [o] field:0:required dateDifferenceSec
		// [o] field:0:required dateDifferenceMin
		// [o] field:0:required dateDifferenceHr
		// [o] field:0:required dateDifferenceDay
		 
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
		String	startDateTime = "";
		String	endDateTime = "";
		String startDateFormat = "";
		String endDateFormat = "";
		if (pipelineCursor.first("startDateTime"))
		{
			startDateTime = (String) pipelineCursor.getValue();
		}
		if (pipelineCursor.first("endDateTime"))
		{
			endDateTime = (String) pipelineCursor.getValue();
		}
		if (pipelineCursor.first("startDateFormat"))
		{
			startDateFormat = (String) pipelineCursor.getValue();
		}
		if (pipelineCursor.first("endDateFormat"))
		{
			endDateFormat = (String) pipelineCursor.getValue();
		}
		
		if (startDateTime.equals("") || endDateTime.equals(""))
			throw new ServiceException("Dates cannot be null");
		if (startDateFormat.equals("") || endDateFormat.equals(""))
			throw new ServiceException("Date formats cannot be null");
		
		pipelineCursor.destroy();
		
		try {
				SimpleDateFormat sdf = new SimpleDateFormat(startDateFormat);
				Date sdt = sdf.parse(startDateTime);
				SimpleDateFormat edf = new SimpleDateFormat(endDateFormat);
				Date edt = edf.parse(endDateTime);
				long  timediff = edt.getTime() - sdt.getTime();
		
		//		SimpleDateFormat ssdf = new SimpleDateFormat("HH:mm:ss");
		//		Calendar cal = Calendar.getInstance();
		//		cal.clear();
		//		cal.set(Calendar.SECOND, (int) timediff /1000);
		
		//		Date newDateTime = cal.getTime();
		//		String displayTime=null;
		
		//		if (cal.get(Calendar.DAY_OF_YEAR) > 1 )
		//		    displayTime = ssdf.format(newDateTime) + " and " + (cal.get(Calendar.DAY_OF_YEAR)-1) + " Day(s)" ;
		//		else 
		//		    displayTime = ssdf.format(newDateTime);
		
				String displayTimeSec = Long.toString(timediff/1000);
				String displayTimeMin = Long.toString(timediff/60000);
				String displayTimeHr = Long.toString(timediff/3600000);
				String displayTimeDay = Long.toString(timediff/86400000);
		
				// pipeline
				IDataCursor pipelineCursor_1 = pipeline.getCursor();
				pipelineCursor_1.last();
				pipelineCursor_1.insertAfter( "dateDifferenceSec", displayTimeSec);
				pipelineCursor_1.insertAfter( "dateDifferenceMin", displayTimeMin);
				pipelineCursor_1.insertAfter( "dateDifferenceHr", displayTimeHr);
				pipelineCursor_1.insertAfter( "dateDifferenceDay", displayTimeDay);
				pipelineCursor_1.destroy();
			} catch (ParseException e) {
				throw new ServiceException("Error parsing the date time: " + e);
			}
		// --- <<IS-END>> ---

                
	}



	public static final void compareDates (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(compareDates)>> ---
		// @sigtype java 3.5
		// [i] field:0:required dateString1
		// [i] field:0:required dateFormat1
		// [i] field:0:required dateString2
		// [i] field:0:required dateFormat2
		// [o] field:0:required result
	IDataCursor idcPipeline = pipeline.getCursor();
	String ds1 = "";
	String ds2 = "";
	String df1 = "";
	String df2 = ""; 
	if (idcPipeline.first("dateString1"))
		ds1 = (String)idcPipeline.getValue();
	
	if (idcPipeline.first("dateString2"))
		ds2 = (String)idcPipeline.getValue();

	if (idcPipeline.first("dateFormat1"))
		df1 = (String)idcPipeline.getValue();

	if (idcPipeline.first("dateFormat2"))
		df2 = (String)idcPipeline.getValue();

	if (df1.equals("") || df2.equals(""))
		throw new ServiceException("Date formats must be specified");

	if (ds1.equals("") || ds2.equals(""))
		throw new ServiceException("Dates cannot be null");

	SimpleDateFormat sdf1 = new SimpleDateFormat(df1);
	SimpleDateFormat sdf2 = new SimpleDateFormat(df2);
	Date d1 = null;
	Date d2 = null;
	try
	{
		d1 = sdf1.parse(ds1);
		d2 = sdf2.parse(ds2);
	}
	catch (Exception e)
	{
		throw new ServiceException(e.toString());
	}

	boolean isafter = d1.after(d2);
	boolean isbefore = d2.after(d1);
	if (isafter)
	{
		idcPipeline.insertAfter("result", "1");
	}
    else if (isbefore)
	{
		idcPipeline.insertAfter("result", "-1");
	}
	else //dates are equal
	{
		idcPipeline.insertAfter("result", "0");
	}

	idcPipeline.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void currentTimeMillis (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(currentTimeMillis)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [o] field:0:required value
		IDataCursor pipelineCursor = pipeline.getCursor();
		IDataUtil.put(pipelineCursor, "value", String.valueOf(System.currentTimeMillis()));
		pipelineCursor.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void dateForSOAPDate (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(dateForSOAPDate)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required SOAPDate
		// [o] object:0:required JavaDate
		// [o] field:0:required isValidDate {"true","false"}
		// [o] field:0:required errMsg
		//define input variables
		IDataCursor idcPipeline = pipeline.getCursor();
		String SOAPDate = null;
		String dateString = null;
		
		//Output variables
		Date JavaDate = null;
		String isValidDate = "true";
		String errMsg = null;
		
		//Remove all ocurrences of the target variables from the pipeline...
		while(idcPipeline.first("JavaDate"))
		  idcPipeline.delete();
		
		while(idcPipeline.first("isValidDate"))
		  idcPipeline.delete();
		
		while(idcPipeline.first("errMsg"))
		  idcPipeline.delete();
		
		if (idcPipeline.first("SOAPDate"))
		{
			SOAPDate = (String) idcPipeline.getValue();
		
			StringBuffer strBuff = new StringBuffer(SOAPDate);
		
			SimpleDateFormat df;
		
			int start = strBuff.indexOf("Z");
			int stop = -1;
		
			if(start != -1)
			{
				strBuff.replace(start, start+1, " GMT");
				df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss z");
			}
			else
			{	
				//Get rid of any fractional seconds.
				start = strBuff.lastIndexOf(".");
		
				boolean isOffset = (strBuff.charAt(strBuff.length()-6) == '-');
		
				if(start != -1)
				{
					stop = (isOffset ? strBuff.lastIndexOf("-") : strBuff.length()-1);
					strBuff.delete(start, stop);
				}
		
				if(isOffset) //We have a GMT offset
				{
					//Get rid of any colon in the GMT offset field
					strBuff.deleteCharAt(strBuff.lastIndexOf(":")); 
					df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ");
				}
				else
					df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
			}
		
		
			df.setLenient(false);
		
			try
			{
				JavaDate = df.parse(strBuff.toString());
			}
			catch(Exception e)
			{
				isValidDate = "false";
				errMsg = "Invalid date: " + strBuff.toString();
			}
		}
		else
		{
			isValidDate = "false";
			errMsg = "Missing dateString";
		}
		
		
		idcPipeline.insertAfter("JavaDate", JavaDate);
		idcPipeline.insertAfter("isValidDate", isValidDate);
		idcPipeline.insertAfter("errMsg", errMsg);
		
		idcPipeline.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void dateForString (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(dateForString)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required dateString
		// [i] field:0:optional formatString
		// [o] object:0:required outDate
		// [o] field:0:required isValidDate
		// [o] field:0:required errMsg
		//define input variables
		IDataCursor idcPipeline = pipeline.getCursor();
		String dateString = null;
		String formatString = null;
		
		//Output variables
		Date outDate = null;
		String isValidDate = "true";
		String errMsg = null;
		
		//Remove all ocurrences of the target variables from the pipeline...
		while(idcPipeline.first("outDate"))
		  idcPipeline.delete();
		
		while(idcPipeline.first("isValidDate"))
		  idcPipeline.delete();
		
		while(idcPipeline.first("errMsg"))
		  idcPipeline.delete();
		
		if (idcPipeline.first("dateString"))
		{
			dateString = (String) idcPipeline.getValue();
			if (idcPipeline.first("formatString"))
			{
				formatString = (String) idcPipeline.getValue();
			}
			else
			{
				formatString = "MM/dd/yyyy";
			}
		
			SimpleDateFormat df = new SimpleDateFormat(formatString);
			df.setLenient(false);
		
			try
			{
				outDate = df.parse(dateString);
			}
			catch(Exception e)
			{
				isValidDate = "false";
				errMsg = "Invalid date";
			}
		}
		else
		{
			isValidDate = "false";
			errMsg = "Missing dateString";
		}
		
		
		idcPipeline.insertAfter("outDate", outDate);
		idcPipeline.insertAfter("isValidDate", isValidDate);
		idcPipeline.insertAfter("errMsg", errMsg);
		
		idcPipeline.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void dateToMilliseconds (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(dateToMilliseconds)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] object:0:required inDate
		// [o] object:0:required millisecondsTime
		IDataCursor idc = pipeline.getCursor();
		
		Date inDate = (Date)IDataUtil.get(idc, "inDate");
		
		long milliseconds = inDate.getTime();
		IDataUtil.put(idc, "millisecondsTime", new Long("" + milliseconds));
		
		idc.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void dayOffset (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(dayOffset)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required numdays
		// [o] field:0:required strdate
		//define input variables
		IDataCursor idcPipeline = pipeline.getCursor();
		String numdays=null;
		
		//Output Variables
		
		//Remove all ocurrences of the target variables from the pipeline...
		while(idcPipeline.first("strDate"))
		  idcPipeline.delete();
		
		
		if (idcPipeline.first("numdays"))
		{
			numdays = (String) idcPipeline.getValue();
		}
		
		Calendar myDate = Calendar.getInstance();
		
		int nDays = Integer.parseInt(numdays);
		
		myDate.add(Calendar.DATE, nDays);
		
		DateFormat df = new SimpleDateFormat("yyyyMMdd");
		
		String strDate = df.format(myDate.getTime());
		
		idcPipeline.insertAfter("strdate", strDate);
		
		idcPipeline.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void getTimeZoneForDate (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getTimeZoneForDate)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] object:0:required inDate
		// [o] field:0:required tzString
		IDataCursor idc = pipeline.getCursor();
		
		Date inDate = (Date)IDataUtil.get(idc, "inDate");
		Calendar c = Calendar.getInstance();
		c.setTime(inDate);
		
		TimeZone tz = c.getTimeZone();
		IDataUtil.put(idc, "tzString", tz.getDisplayName(tz.inDaylightTime(inDate), TimeZone.SHORT));
		idc.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void inDaylightTime (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(inDaylightTime)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] object:0:required inDate
		// [o] object:0:required inDaylightTime
		IDataCursor idc = pipeline.getCursor();
		
		Date inDate = (Date)IDataUtil.get(idc, "inDate");
		if (inDate == null)
		{
		    IDataUtil.put(idc, "inDaylightTime", new Boolean(false));
		}
		else
		{
		    Calendar c = Calendar.getInstance();
		    c.setTime(inDate);
		    TimeZone tz = c.getTimeZone();
		
		    IDataUtil.put(idc, "inDaylightTime", new Boolean(tz.inDaylightTime(inDate)));
		}
		idc.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void incrementDate (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(incrementDate)>> ---
		// @sigtype java 3.5
		// [i] field:0:required startingDate
		// [i] field:0:required startingDateFormat
		// [i] field:0:required endingDateFormat
		// [i] field:0:optional addYears
		// [i] field:0:optional addMonths
		// [i] field:0:optional addDays
		// [i] field:0:optional addHours
		// [i] field:0:optional addMinutes
		// [i] field:0:optional addSeconds
		// [o] field:0:required endingDate

	IDataCursor idcPipeline = pipeline.getCursor();

	String strStartingDate = null;
	if (idcPipeline.first("startingDate"))
	{
		strStartingDate = (String)idcPipeline.getValue();
	}
	else
	{
		throw new ServiceException("startingDate must be supplied!");
	}
	String strStartingDateFormat = null;
	if (idcPipeline.first("startingDateFormat"))
	{
		strStartingDateFormat = (String)idcPipeline.getValue();
	}
	else
	{
		throw new ServiceException("startingDateFormat must be supplied!");
	}
	String strEndingDateFormat = null;
	if (idcPipeline.first("endingDateFormat"))
	{
		strEndingDateFormat = (String)idcPipeline.getValue();
	}
	else
	{
		throw new ServiceException("endingDateFormat must be supplied!");
	}

	String strAddYears = null;
	String strAddMonths = null;
	String strAddDays = null;
	String strAddHours = null;
	String strAddMinutes = null;
	String strAddSeconds = null;

	if (idcPipeline.first("addYears"))
	{
		strAddYears = (String)idcPipeline.getValue();
	}
	if (idcPipeline.first("addMonths"))
	{
		strAddMonths = (String)idcPipeline.getValue();
	}
	if (idcPipeline.first("addDays"))
	{
		strAddDays = (String)idcPipeline.getValue();
	}
	if (idcPipeline.first("addHours"))
	{
		strAddHours = (String)idcPipeline.getValue();
	}
	if (idcPipeline.first("addMinutes"))
	{
		strAddMinutes = (String)idcPipeline.getValue();
	}
	if (idcPipeline.first("addSeconds"))
	{
		strAddSeconds = (String)idcPipeline.getValue();
	}

	SimpleDateFormat ssdf = new SimpleDateFormat(strStartingDateFormat);

	Date startingDate = null;
	try
	{
		startingDate = ssdf.parse(strStartingDate);
	}
	catch (Exception e)
	{
		throw new ServiceException(e.toString());
	}

	GregorianCalendar gc = new GregorianCalendar();
	gc.setTime(startingDate);

	if (strAddYears != null)
	{
		gc.add(Calendar.YEAR, Integer.parseInt(strAddYears));
	}
	if (strAddMonths != null)
	{
		gc.add(Calendar.MONTH, Integer.parseInt(strAddMonths));
	}
	if (strAddDays != null)
	{
		gc.add(Calendar.DAY_OF_MONTH, Integer.parseInt(strAddDays));
	}
	if (strAddHours != null)
	{
		gc.add(Calendar.HOUR_OF_DAY, Integer.parseInt(strAddHours));
	}
	if (strAddMinutes != null)
	{
		gc.add(Calendar.MINUTE, Integer.parseInt(strAddMinutes));
	}
	if (strAddSeconds != null)
	{
		gc.add(Calendar.SECOND, Integer.parseInt(strAddSeconds));
	}

	Date endingDate = gc.getTime();
	SimpleDateFormat esdf = new SimpleDateFormat(strEndingDateFormat);
	String strEndingDate = esdf.format(endingDate);

	idcPipeline.insertAfter("endingDate", strEndingDate);
	idcPipeline.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void millisecondsToDate (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(millisecondsToDate)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] object:0:required millisecondsTime
		// [o] object:0:required outDate
		IDataCursor idc = pipeline.getCursor();
		
		Long millisecondsTime = (Long)IDataUtil.get(idc, "millisecondsTime");
		
		Date outDate = new Date(millisecondsTime.longValue());
		IDataUtil.put(idc, "outDate", outDate);
		
		idc.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void soapDateForDate (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(soapDateForDate)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] object:0:required theDate
		// [o] field:0:required soapDate
		// [o] field:0:required isValidDate
		// [o] field:0:optional errMsg
		//define input variables
		IDataCursor idcPipeline = pipeline.getCursor();
		Date theDate = null;
		
		//Output variables
		StringBuffer soapDate = new StringBuffer();
		String isValidDate = "true";
		String errMsg = null;
		
		//Remove all ocurrences of the target variables from the pipeline...
		while(idcPipeline.first("soapDate"))
		  idcPipeline.delete();
		
		while(idcPipeline.first("isValidDate"))
		  idcPipeline.delete();
		
		while(idcPipeline.first("errMsg"))
		  idcPipeline.delete();
		
		if (idcPipeline.first("theDate"))
		{
			theDate = (Date) idcPipeline.getValue();
		
			try
			{
				SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ");
				soapDate = df.format(theDate, soapDate, new FieldPosition(0));
			
				soapDate.insert(soapDate.length()-2, ":");
			}
			catch(Exception e)
			{
				isValidDate = "false";
				errMsg = "Invalid date";
			}
		
		}
		else
		{
			isValidDate = "false";
			errMsg = "Missing required parameter: theDate";
		
		}
		
		idcPipeline.insertAfter("soapDate", soapDate.toString());
		idcPipeline.insertAfter("isValidDate", isValidDate);
		if(isValidDate.equals("false"))
			idcPipeline.insertAfter("errMsg", errMsg);
		
		idcPipeline.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void stringForDate (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(stringForDate)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] object:0:required theDate
		// [i] field:0:optional dateFormat
		// [o] field:0:required dateString
		//define input variables
		IDataCursor idcPipeline = pipeline.getCursor();
		Date theDate = null;
		String dateFormat = null;
		
		//Output variables
		StringBuffer dateString = new StringBuffer();
		
		//Remove all ocurrences of the target variables from the pipeline...
		while(idcPipeline.first("dateString"))
		  idcPipeline.delete();
		
		if (idcPipeline.first("theDate"))
		{
			theDate = (Date) idcPipeline.getValue();
			if (idcPipeline.first("dateFormat"))
			{
				dateFormat = (String) idcPipeline.getValue();
			}
			else
			{
				dateFormat = "MM/dd/yyyy";
			}
		
			SimpleDateFormat df = new SimpleDateFormat(dateFormat);
			//df.setLenient(false);
		
			try
			{
				dateString = df.format(theDate, dateString, new FieldPosition(0));
			}
			catch(Exception e)
			{
				//isValidDate = "false";
				//errMsg = "Invalid date";
			}
		}
		else
		{
			//isValidDate = "false";
			//errMsg = "Missing dateString";
		}
		
		
		idcPipeline.insertAfter("dateString", dateString.toString());
		
		idcPipeline.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void subtractDates (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(subtractDates)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] object:0:required inDate1
		// [i] object:0:required inDate2
		// [o] object:0:required millisecondsDifference
		IDataCursor idc = pipeline.getCursor();
		
		Date inDate1 = (Date)IDataUtil.get(idc, "inDate1");
		Date inDate2 = (Date)IDataUtil.get(idc, "inDate2");
		
		long firstDateMillis = inDate1.getTime();
		long secondDateMillis = inDate2.getTime();
		
		Long millisecondsDifference = new Long(firstDateMillis - secondDateMillis);
		
		IDataUtil.put(idc, "millisecondsDifference", millisecondsDifference);
		
		idc.destroy();
		// --- <<IS-END>> ---

                
	}
}

