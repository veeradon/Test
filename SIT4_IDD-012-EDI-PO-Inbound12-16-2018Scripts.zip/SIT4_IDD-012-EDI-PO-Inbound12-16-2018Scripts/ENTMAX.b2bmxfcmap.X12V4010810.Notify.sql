delete from config_entry where config_group='ENTMAX.b2bmxfcmap.X12V4010810.Notify';
--**************************************************************************************
--* CONFIGURATION INSERT SCRIPT.
--**************************************************************************************
Declare
TYPE adapter is varray(2) of VARCHAR2(500);
TYPE config is varray(5) of VARCHAR2(255);
TYPE configurations is varray(60) of config;
 
counter number;
key_val varchar2(255);
updateDate DATE;

adapter_name adapter := adapter('ENTMAX.b2bmxfcmap.X12V4010810.Notify','ENTMAX.b2bmxfcmap.X12V4010810.Notify object configurations');
configlist configurations :=configurations
(
config('sendEmailOn_fail','smedapati@aep.com','STRING','OTHER','TBD'),
config('sendEmailOn_success','smedapati@aep.com','STRING','OTHER','Email addresses separated by commas'),
config('sendEmailOn_dataError','smedapati@aep.com','STRING','OTHER','TBD'),
config('sendEmailOn_default','smedapati@aep.com','STRING','OTHER','TBD'),
config('sendEmailOn_invalid',',smedapati@aep.com','STRING','OTHER','TBD'),
config('sendEmailOn_duplicate','smedapati@aep.com','STRING','OTHER','TBD'),
config('sendEmailOn_retryWarn','smedapati@aep.com','STRING','OTHER','TBD'),
config('sendEmailOn_retryFirst','smedapati@aep.com','STRING','OTHER','TBD'),
config('sendEmailOn_retryLast',',smedapati@aep.com','STRING','OTHER','TBD'),
config('sendEmailOn_retrySuccess',',smedapati@aep.com','STRING','OTHER','TBD'),
config('emailInterfaceNotify','true','STRING','OTHER','TBD'),
config('emailOn_dataerror','smedapati@aep.com','STRING','OTHER','TBD'),
config('emailOn_default','smedapati@aep.com','STRING','OTHER','TBD'),
config('emailOn_fail','smedapati@aep.com','STRING','OTHER','TBD'),
config('emailOn_invalid','smedapati@aep.com','STRING','OTHER','TBD'),
config('emailOn_retryWarning','smedapati@aep.com','STRING','OTHER','TBD'),
config('emailOn_success','smedapati@aep.com','STRING','OTHER','TBD'),
config('emailOn_warning','smedapati@aep.com','STRING','OTHER','TBD'),


--CI values
config('ConnectionCI','http://wamasd2.aepsc.com:9083/','STRING','OTHER','CI of Maximo queue for this interface'),
config('IntegrationCI','ei-wam-invoice-in-solution-Dev','STRING','OTHER','TBD'),  --Integration source or target CI (depending on Pub or Sub)

--Service Info
config('alias','EDI Invoice To Maximo','STRING','OTHER','TBD'),--Message Type + From/To+ Source/Target ex: AssetLocation From Maximo or ASSET NRX to NRX
config('context','Procure2Pay','STRING','OTHER','TBD'),--Asset,Cook,Financials,Inventory,Procure2Pay,WorkOrder

--Logging
config('doLog','true','STRING','OTHER','TBD'),	
config('logLevel','INFO','STRING','OTHER','TBD'),--Log levels that log4j2 framework supports

--Notification config
config('enableAlerts','true','STRING','OTHER','TBD'),
config('enableEmail','true','STRING','OTHER','TBD'),	
config('emsInterfaceNotify_System','true','STRING','OTHER','TBD'),
config('emsInterfaceNotify_Service','true','STRING','OTHER','TBD'),
config('emsTicketPriorityLevel_System','2','STRING','OTHER','TBD'),
config('emsTicketPriorityLevel_Service','4','STRING','OTHER','TBD'),  
config('retryNotificationFrequency','1','STRING','OTHER','TBD'), --Send notification every nth retry attempt

--Trigger Retries
config('exitRetry','false','STRING','OTHER','Force exit retry'),
config('maxRetryCount','5','STRING','OTHER','This value overrides the trigger retry settings')

);
Begin
 DBMS_OUTPUT.ENABLE(1000000);
 DBMS_OUTPUT.PUT_LINE('####@@@@START@@@@####'); 

 DBMS_OUTPUT.PUT_LINE('');
 
 DBMS_OUTPUT.PUT_LINE('**********VERIFYING ADAPTER**********'); 
 DBMS_OUTPUT.PUT_LINE('      ADAPTER-NAME ::'||adapter_name(1)); 
  
 select sysdate into updateDate from dual; 
 select count(*) into counter from config_groups where config_group=adapter_name(1);
  
 IF counter = 0 THEN
  
      DBMS_OUTPUT.PUT_LINE('            NEW ADAPTER :: ADDING NEW ADAPTER ' || adapter_name(1));
  
      insert into config_groups values(adapter_name(1),adapter_name(2),'ACTIVE'); 
  
      DBMS_OUTPUT.PUT_LINE('                    NEW ADAPTER :: SUCESSFULLY ADDED..' || ' NUMBER OF ROWS INSERTED ::::'|| SQL%ROWCOUNT);       
  
 END IF;
  
 DBMS_OUTPUT.PUT_LINE('**********VERIFYING CONFIGURATIONS**********'); 
  
 FOR i IN configlist.FIRST..configlist.LAST LOOP
       DBMS_OUTPUT.PUT_LINE('');      
       DBMS_OUTPUT.PUT_LINE('      VERIFYING CONFIGURATION FOR  CONFIG-KEY :: '||configlist(i)(1)|| '....');
       
       DBMS_OUTPUT.PUT_LINE('                VERIFYING CONFIG_CATEGORIES FOR  CONFIG-KEY :: '||configlist(i)(1)|| '....');
       select count(*) into counter from CONFIG_CATEGORIES where CONFIG_CATEGORY=configlist(i)(4);
       IF counter = 0 THEN
         insert into config_categories values(configlist(i)(4),configlist(i)(4),'FALSE','FALSE',updateDate,'IFWADMIN');
         DBMS_OUTPUT.PUT_LINE('                               INSERTED CONFIG_CATEGORY :: '||configlist(i)(4)); 
       ELSE
         DBMS_OUTPUT.PUT_LINE('                               NO CHANGE CONFIG_CATEGORY EXISTS'); 
       END IF;
       
       DBMS_OUTPUT.PUT_LINE('                 VERIFYING CONFIG_KEYTYPES FOR  CONFIG-KEY :: '||configlist(i)(1)|| '....');
       select count(*) into counter from CONFIG_KEY_TYPES where KEY_TYPE=configlist(i)(3);
       IF counter = 0 THEN
         insert into CONFIG_KEY_TYPES values(configlist(i)(3));
         DBMS_OUTPUT.PUT_LINE('                               INSERTED CONFIG_KEY_TYPE :: '||configlist(i)(3)); 
       ELSE
          DBMS_OUTPUT.PUT_LINE('                              NO CHANGE CONFIG_TYPE EXISTS'); 
       END IF;
       
              
       select count(*) into counter from config_entry where CONFIG_GROUP=adapter_name(1) and CONFIG_KEY=configlist(i)(1);
       
       IF counter = 0 THEN
      
         DBMS_OUTPUT.PUT_LINE('    ENTRY NOT FOUND, ADDING A NEW CONFIG....');
         
         INSERT INTO config_entry VALUES(adapter_name(1),configlist(i)(1),configlist(i)(2),configlist(i)(3),'ACTIVE','FALSE',sysdate,configlist(i)(4),configlist(i)(5),updateDate,'IFWADMIN');
         DBMS_OUTPUT.PUT_LINE('              NEW CONFIGURATION :: SUCESSFULLY ADDED..' || ' NUMBER OF ROWS INSERTED ::::'|| SQL%ROWCOUNT);       
         
       ELSE
         DBMS_OUTPUT.PUT_LINE('    CONFIGURATION ALREADY EXISTS, DELETING EXISTING CONFIGURATION....');
         delete from config_entry where CONFIG_GROUP=adapter_name(1) and CONFIG_KEY=configlist(i)(1);
         DBMS_OUTPUT.PUT_LINE('             CONFIGURATION ALREADY EXISTS, EXISTING CONFIGURATION DELETED,INSERTING NEW CONFIGURATION....');
         INSERT INTO config_entry VALUES(adapter_name(1),configlist(i)(1),configlist(i)(2),configlist(i)(3),'ACTIVE','FALSE',sysdate,configlist(i)(4),configlist(i)(5),updateDate,'IFWADMIN');
         DBMS_OUTPUT.PUT_LINE('             CONFIGURATION INSERTED..');
       END IF; 
       
       counter := NULL;
 END LOOP;
 DBMS_OUTPUT.PUT_LINE(''); 
 DBMS_OUTPUT.PUT_LINE('####@@@@END@@@@####');   
 
 DBMS_OUTPUT.PUT_LINE('');
 DBMS_OUTPUT.PUT_LINE('**********VERIFICATION STARTED**********');   
 SELECT count(*) into counter FROM config_entry WHERE CREATED_DATE=updateDate;
 DBMS_OUTPUT.PUT_LINE('      CONFIG_ENTRY ::: NUMBER ROWS EFFECTED :: '||counter);
 DBMS_OUTPUT.PUT_LINE('**********VERIFICATION ENDED**********');
 
End;
