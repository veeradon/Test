package AEP.IO;

// -----( IS Java Code Template v1.2
// -----( CREATED: 2005-10-03 10:29:42 EDT
// -----( ON-HOST: P3031248.aepsc.com

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.io.*;
import java.util.*;
import java.nio.channels.*;
import java.nio.*;
// --- <<IS-END-IMPORTS>> ---

public final class utils

{
	// ---( internal utility methods )---

	final static utils _instance = new utils();

	static utils _newInstance() { return new utils(); }

	static utils _cast(Object o) { return (utils)o; }

	// ---( server methods )---




	public static final void copyFile (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(copyFile)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required sourceDir
		// [i] field:0:required sourceFile
		// [i] field:0:optional destDir
		// [i] field:0:optional destFile
		// [i] field:0:optional bufferSize
		// [o] field:0:required successFlag
		// [o] field:0:required errorMessage
		IDataCursor pl = pipeline.getCursor();
		
		String sourceDir = null;
		String destDir = null;
		String sourceFile = null;
		String destFile = null;
		int bufferSize=102400;  //default (100K) number of bytes to copy with each read/write
		
		//Remove all ocurrences of the target variables from the pipeline...
		while(pl.first("successFlag"))
			pl.delete();
		
		while(pl.first("errorMessage"))
			pl.delete();
		
		if (pl.first("sourceDir")) { sourceDir = (String)pl.getValue(); }
		else {
		  pl.destroy();
		  throw(new ServiceException("sourceDir is required"));
		}
		
		if (pl.first("destDir")) { destDir = (String)pl.getValue(); }
		else {destDir = sourceDir;} 
		
		File targetDir = new File(destDir);
		
		boolean targetOk = (targetDir.exists() && targetDir.isDirectory());
		
		if(!targetOk)
		{
		  pl.insertAfter("errorMessage", destDir + " does not exist or is not a directory");
		  pl.insertAfter("successFlag", "false");
		  pl.destroy();
		  return;
		}
		
		if (pl.first("sourceFile")) { sourceFile = (String)pl.getValue(); }
		else {
		  pl.destroy();
		  throw(new ServiceException("sourceFile is required"));
		}
		
		if (pl.first("destFile")) { destFile = (String)pl.getValue(); }
		else { destFile = sourceFile; }
		
		String fullSource = sourceDir + File.separator + sourceFile;
		String fullDest = destDir + File.separator + destFile;
		
		if(fullSource.equals(fullDest))
		{
		  pl.insertAfter("errorMessage", "Source and destination files cannot be the same.");
		  pl.insertAfter("successFlag", "false");
		  pl.destroy();
		  return;
		}
		
		// 4/14/2005 - Moved bufferSize statements down
		
		File file1 = new File(fullSource);
		File file2 = new File(fullDest);
		boolean tf;
		
		tf = file1.exists();
		if (!tf) {
		  pl.insertAfter("errorMessage", fullSource + " doesn't exist");
		  pl.insertAfter("successFlag", "false");
		  pl.destroy();
		  return;
		}
		
		// 4/14/2005 - Moved from above to avoid allocating an array
		// that isn't used. Changed to use smaller of bufferSize and
		// source file size.
		//Set the bufferSize if supplied, else use default
		//if(pl.first("bufferSize")) {bufferSize = Integer.parseInt((String) pl.getValue());}
		bufferSize = IDataUtil.getInt(pl, bufferSize);
		if(file1.length() < bufferSize)
		  bufferSize = (int)file1.length();  // cast to int is safe since we just confirmed
		                                     // the length is within the limits of an int
		
		byte copyBuff[] = new byte[bufferSize];
		// 4/14/2005 - end of moved block
		
		int bytesRead=-1;
		
		try {
		  FileInputStream fr = new FileInputStream(file1);
		  FileOutputStream fw = new FileOutputStream(file2);
		  while ( (bytesRead = fr.read(copyBuff,0,bufferSize)) != -1 ) { fw.write(copyBuff,0,bytesRead); }
		  fr.close();
		  fw.close();
		}
		catch (java.io.IOException ex) {
		  pl.insertAfter("errorMessage", "Copy of " + fullSource + " to " + fullDest + " failed" );
		  pl.insertAfter("successFlag", "false");
		  pl.destroy();
		  return;
		}
		
		pl.insertAfter("successFlag", "true");
		pl.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void deleteFile (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(deleteFile)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:optional filename
		// [i] field:0:optional directory
		// [i] object:0:optional file
		// [o] field:0:required successFlag
		//define input variables
		IDataCursor idcPipeline = pipeline.getCursor();
		String longFilename,filename,directory ;
		java.io.File localFile = null; 	// Moved from below 9/29/2005
		
		//Output Variables
		String successFlag = "false";
		
		// Check to see if the filename object is in the pipeline
		if (idcPipeline.first("filename"))
		{
			//get the filename string object out of the pipeline
			filename = (String) idcPipeline.getValue();
		
			// Check to see if the optional directory object is in the pipeline
			if (idcPipeline.first("directory"))
			{
				//get the directory string object out of the pipeline
				directory = (String) idcPipeline.getValue();
				// Changed 9/29/2005
				//longFilename = (directory + File.separator + filename);
				localFile = new File(directory, filename);
			}
			else
			{
				// Changed 9/29/2005
				//longFilename = (filename);
				localFile = new File(filename);
			}
		}
		// Added 9/29/2005
		else if (idcPipeline.first("file"))
		{
			localFile = (java.io.File) idcPipeline.getValue();
		}
		//if it is not in the pipeline, then handle the error
		else
		{
			idcPipeline.destroy();
			throw( new ServiceException("Required parameter 'filename' missing."));
		}
		
		//Assign full path name to a file object
		// Moved above 9/29/2005
		//File localFile = new File(longFilename);
		
		//Check if a directory was entered
		if (localFile.isDirectory())
		{
			idcPipeline.destroy();
			throw(new ServiceException("Can't delete a directory"));
		}
		
		//Check if the file doesn't exist
		else if (!localFile.exists())
		{
			successFlag = "true"; //Treat as if already deleted
		}
		//check if you can write to file
		else if (!localFile.canWrite()) 
		{
			idcPipeline.destroy();
			throw(new ServiceException("File not writeable"));
		}
		//File can be deleted
		else
		{
			if(localFile.delete()) // 4/14/2005 - Check return value
			  successFlag = "true";
		}
		
		//insert the successFlag into the pipeline
		if(idcPipeline.first("successFlag"))
			idcPipeline.setValue(successFlag);
		else
			idcPipeline.insertAfter("successFlag", successFlag);
		
		//Always destroy cursors that you created
		idcPipeline.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void dirExist (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(dirExist)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required dirPath
		// [o] field:0:required exists {"true","false"}
		//define input variables
		IDataCursor idcPipeline = pipeline.getCursor();
		String dirPath ;
		
		//Output Variables
		String exists = "false";
		
		// Check to see if the dirPath object is in the pipeline
		if (idcPipeline.first("dirPath"))
		{
			//get the dirPath string object out of the pipeline
			dirPath = (String) idcPipeline.getValue();
		}
		//if it is not in the pipeline, then handle the error
		else
		{
			idcPipeline.destroy();
			throw(new ServiceException("Required parameter 'dirPath' missing."));
		}
		
		//Assign path name to a file object
		File localFile = new File(dirPath);
		
		//Check is a directory was entered
		if (localFile.exists() && localFile.isDirectory())
			exists = "true";
		
		if(idcPipeline.first("exists"))
			idcPipeline.setValue(exists);
		else
			idcPipeline.insertAfter("exists", exists);
		
		//Always destroy cursors that you created
		idcPipeline.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void fileType (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(fileType)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required filename
		// [o] field:0:required successFlag
		// [o] field:0:required exists
		// [o] field:0:required fileType
		//define input variables
		IDataCursor idcPipeline = pipeline.getCursor();
		String filename = null ;
		
		//Output Variables
		String successFlag = "false";
		String exists = null;
		String fileType = null;
		
		//Remove all ocurrences of the target variables from the pipeline...
		while(idcPipeline.first("successFlag"))
			idcPipeline.delete();
		
		while(idcPipeline.first("exists"))
			idcPipeline.delete();
		
		while(idcPipeline.first("fileType"))
			idcPipeline.delete();
		
		// Check to see if the filename object is in the pipeline
		if (idcPipeline.first("filename"))
		{
			//get the filename string object out of the pipeline
			filename = (String) idcPipeline.getValue();
		}
		//if it is not in the pipeline, then handle the error
		else
		{
			idcPipeline.destroy();
			throw(new ServiceException("Required parameter 'filename' missing."));
		}
		
		//Assign file or directory name to a file object
		File fileOrDir = new File(filename);
		
		//Check if the object exists
		if (fileOrDir.exists())
		{
			// Check if the filename is an actual directory
		 	if (fileOrDir.isDirectory())
			{
				successFlag = "true";
				exists = "true";
				fileType = "directory";
			}
		
			//The filename is a name of an actual file
			else
			{
				successFlag = "true";
				exists = "true";
				fileType = "file";
			}
		}
		//File doesn't exist
		else
		{
			successFlag = "true";
			exists = "false";
			fileType = null;
		}
		
		
		//insert the successFlag into the pipeline
		idcPipeline.insertAfter("successFlag", successFlag);
		
		//insert the exists of file into the pipline
		idcPipeline.insertAfter("exists", exists);
		
		//insert the type of file into the pipline
		idcPipeline.insertAfter("fileType", fileType);
		
		//Always destroy cursors that you created
		idcPipeline.destroy();
		
		// --- <<IS-END>> ---

                
	}



	public static final void getCurrentWorkDirectory (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getCurrentWorkDirectory)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [o] field:0:required CurrentWorkingDir
		String userdir = System.getProperty("user.dir");
		IDataCursor cursor= pipeline.getCursor();
		cursor.last();
		cursor.insertAfter("CurrentWorkingDir",userdir);
		cursor.destroy(); 
		// --- <<IS-END>> ---

                
	}



	public static final void getDirDelim (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(getDirDelim)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [o] field:0:required dirDelim
		IDataCursor idcPipeline = pipeline.getCursor();
		
		String dirDelim = File.separator;
		
		if(idcPipeline.first("dirDelim"))
			idcPipeline.setValue(dirDelim);
		else
			idcPipeline.insertAfter("dirDelim", dirDelim);
		
		//Always destroy cursors that you created
		idcPipeline.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void listFilesInDirectory (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(listFilesInDirectory)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required targetDirectory
		// [i] field:0:optional fileFilter
		// [i] field:0:optional includeDirectories {"false","true"}
		// [o] field:1:optional filenameList

	//define input variables
	IDataCursor idcPipeline = pipeline.getCursor();
	String targetDirectory = null;

	while(idcPipeline.first("filenameList"))
		idcPipeline.delete();

	//get the targetDirectory out of the pipeline
	if (idcPipeline.first("targetDirectory"))
		targetDirectory = (String)idcPipeline.getValue();
	else //if it is not in the pipeline, then handle the error
	{
		idcPipeline.destroy();

		throw(new ServiceException("Required parameter 'targetDirectory' missing"));
	}

	String fileFilter = "*"; //Default filter

	//Override with any value found in pipeline
	if (idcPipeline.first("fileFilter")) fileFilter = (String)idcPipeline.getValue();

	String includeDirectories = "false"; //Don't include directories by default

	if (idcPipeline.first("includeDirectories"))includeDirectories = (String)idcPipeline.getValue();

	boolean bIncludeDirs = includeDirectories.equals("true");

	File targetDirectoryPath = new File (targetDirectory);

	if (!targetDirectoryPath.isDirectory () || !targetDirectoryPath.exists())
	{
		idcPipeline.destroy();
		throw(new ServiceException("Directory does not exist"));
	}

	//idcPipeline.last ();
	String [] filenameList = null;


	//Load file suffix filter.  This class is defined in WCardDirFilter.jar
	//WCardDirFilter dirFilter = new WCardDirFilter (fileFilter, bIncludeDirs);
	com.aep.io.WildcardFileFilter dirFilter = new com.aep.io.WildcardFileFilter(fileFilter);
	dirFilter.setAcceptMatchingDirectories(bIncludeDirs);

	//Search for matching filenames
	filenameList = targetDirectoryPath.list (dirFilter);

	idcPipeline.insertAfter("filenameList", filenameList);

	//Always destroy cursors that you created
	idcPipeline.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void mkdir (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(mkdir)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required dirPath
		// [o] field:0:required successFlag
	IDataCursor idcPipeline = pipeline.getCursor();
	String successFlag = "true";
	String dirPath = null;

	//Remove all ocurrences of the target variables from the pipeline...
	while(idcPipeline.first("successFlag"))
		idcPipeline.delete();


	// Check to see if the dirPath object is in the pipeline
	if (idcPipeline.first("dirPath"))
	{
		//get the dirPath out of the pipeline
		dirPath = (String)idcPipeline.getValue();

		File thePath = new File(dirPath);

		if(thePath.exists() && thePath.isDirectory())
			successFlag = "true";
		else
			successFlag = (thePath.mkdirs() ? "true" : "false");

	}
	//if it is not in the pipeline, then handle the error
	else
	{
		idcPipeline.destroy();
		throw(new ServiceException("Required parameter 'dirPath' missing"));
	}

	idcPipeline.insertAfter("successFlag", successFlag);

	//Always destroy cursors that you created
	idcPipeline.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void moveFile (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(moveFile)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required sourceDir
		// [i] field:0:required sourceFile
		// [i] field:0:optional destDir
		// [i] field:0:optional destFile
		// [i] field:0:optional bufferSize
		// [o] field:0:required successFlag
		// [o] field:0:required errorMessage
		IDataCursor pl = pipeline.getCursor();
		
		String sourceDir=null;
		String destDir=null;
		String sourceFile=null;
		String destFile=null;
		int bufferSize=102400;  //default (100K) number of bytes to copy with each read/write
		
		//Remove all ocurrences of the target variables from the pipeline...
		while(pl.first("successFlag"))
			pl.delete();
		
		while(pl.first("errorMessage"))
			pl.delete();
		
		if (pl.first("sourceDir")) { sourceDir = (String)pl.getValue(); }
		else {
		  pl.destroy();
		  throw(new ServiceException("sourceDir is required"));
		}
		
		if (pl.first("destDir")) { destDir = (String)pl.getValue(); }
		else {destDir = sourceDir;}
		
		File targetDir = new File(destDir);
		
		boolean targetOk = (targetDir.exists() && targetDir.isDirectory());
		
		if(!targetOk)
		{
		  pl.insertAfter("errorMessage", destDir + " does not exist or is not a directory");
		  pl.insertAfter("successFlag", "false");
		  pl.destroy();
		  return;
		}
		
		if (pl.first("sourceFile")) { sourceFile = (String)pl.getValue(); }
		else {
		  pl.destroy();
		  throw(new ServiceException("sourceFile is required"));
		}
		
		if (pl.first("destFile")) { destFile = (String)pl.getValue(); }
		else { destFile = sourceFile; }
		
		String fullSource = sourceDir + File.separator + sourceFile;
		String fullDest = destDir + File.separator + destFile;
		
		if(fullSource.equals(fullDest))
		{
		  pl.insertAfter("errorMessage", "Source and destination files cannot be the same.");
		  pl.insertAfter("successFlag", "false");
		  pl.destroy();
		  return;
		}
		
		File file1 = new File(fullSource);
		File file2 = new File(fullDest);
		boolean tf;
		
		tf = file1.exists();
		if (!tf) {
		  pl.insertAfter("errorMessage", fullSource + " doesn't exist");
		  pl.insertAfter("successFlag", "false");
		  pl.destroy();
		  return;
		}
		
		tf = file1.renameTo(file2);  //Interestingly, on Windows platforms this works across drive letters
		if (tf) {
		  pl.insertAfter("successFlag", "true");
		  pl.destroy();
		  return;
		}
		
		//Rename failed, files probably on different inodes, try copy & delete instead
		 
		//Set the bufferSize if supplied, else use default
		
		if(pl.first("bufferSize")) {bufferSize = Integer.parseInt((String) pl.getValue());}
		
		// 4/14/2005 - Use the smaller of bufferSize or source file size.
		if(file1.length() < bufferSize)
		  bufferSize = (int)file1.length();  // cast to int is safe since we just confirmed
		                                     // the length is within the limits of an int
		// 4/14/2005 - End
		
		byte copyBuff[] = new byte[bufferSize];
		int bytesRead=-1;
		
		try {
		  FileInputStream fr = new FileInputStream(file1);
		  FileOutputStream fw = new FileOutputStream(file2);
		  while ( (bytesRead = fr.read(copyBuff,0,bufferSize)) != -1 ) { fw.write(copyBuff,0,bytesRead);}
		  fr.close();
		  fw.close();
		}
		catch (java.io.IOException ex) {
		  pl.insertAfter("errorMessage", "Copy of " + fullSource + " to " + fullDest + " failed" );
		  pl.insertAfter("successFlag", "false");
		  pl.destroy();
		  return;
		}
		
		tf = file1.delete();
		if (!tf) {
		  pl.insertAfter("errorMessage", "Can't delete " + fullSource + " after copy");
		  pl.insertAfter("successFlag", "false");
		  pl.destroy();
		  return;
		}
		
		pl.insertAfter("successFlag", "true");
		pl.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void readTextFile (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(readTextFile)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:required sourceDir
		// [i] field:0:required fileName
		// [o] field:0:required contents
		// [o] field:0:required successFlag {"true","false"}
		// [o] field:0:required errorMessage
		IDataCursor pl = pipeline.getCursor();
		
		String sourceDir = null;
		String fileName = null;
		String contents = null;
		
		//Remove all ocurrences of the target variables from the pipeline...
		while(pl.first("successFlag"))
			pl.delete();
		
		while(pl.first("errorMessage"))
			pl.delete();
		
		while(pl.first("contents"))
			pl.delete();
		
		if (pl.first("sourceDir")) { sourceDir = (String)pl.getValue(); }
		else {
		  pl.destroy();
		  throw(new ServiceException("sourceDir is required"));
		}
		
		if (pl.first("fileName")) { fileName = (String)pl.getValue(); }
		else {
		  pl.destroy();
		  throw(new ServiceException("fileName is required"));
		}
		
		String fullSource = sourceDir + File.separator + fileName;
		
		try {
		  File theFile = new File(fullSource);
		  // 4/14/2005 - Changed to use just FileReader.
		  //BufferedReader fr = new BufferedReader(new FileReader(theFile));
		  FileReader fr = new FileReader(theFile);
		
		  char fileBuffer[] = new char[(int) theFile.length()];
		
		  fr.read(fileBuffer, 0, (int) theFile.length());
		
		  fr.close();
		
		  contents = new String(fileBuffer);
		  
		}
		catch (java.io.IOException ex) {
		  pl.insertAfter("errorMessage", "Could not open or read from " + fullSource );
		  pl.insertAfter("successFlag", "false");
		  pl.destroy();
		  return;
		}
		
		pl.insertAfter("contents", contents);
		pl.insertAfter("successFlag", "true");
		pl.destroy();
		// --- <<IS-END>> ---

                
	}



	public static final void writeTextFile (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(writeTextFile)>> ---
		// @subtype unknown
		// @sigtype java 3.5
		// [i] field:0:optional destDir
		// [i] field:0:required fileName
		// [i] object:0:required fileContent
		// [i] field:0:optional overwriteFlag {"overwrite","append"}
		// [i] field:0:optional exclusiveLock {"true","false"}
		// [i] field:0:optional charsetName
		// [o] field:0:required successFlag
		// [o] field:0:required errorMessage
		IDataCursor pl = pipeline.getCursor();
		
		String destDir = null;
		String fileName = null;
		Object fileContent = null;  // 4/7/2005 Rob Eamon; Changed from String to Object
		String overwriteFlag = "overwrite";
		String fullName = null;
		String exclusiveLock = "true";
		String charsetName = null;  // 4/7/2005 Rob Eamon; added
		
		//Remove all occurrences of the target variables from the pipeline...
		while(pl.first("successFlag"))
			pl.delete();
		
		while(pl.first("errorMessage"))
			pl.delete();
		
		if (pl.first("fileName")) { fileName = (String)pl.getValue(); }
		else {
		  pl.destroy();
		  throw(new ServiceException("fileName is required"));
		}
		
		if (pl.first("fileContent")) { fileContent = pl.getValue(); }
		else {
		  pl.destroy();
		  throw(new ServiceException("fileContent is required"));
		}
		
		if (pl.first("destDir")) { 
			destDir = (String)pl.getValue(); 
			File targetDir = new File(destDir);
		
			boolean targetOk = (targetDir.exists() && targetDir.isDirectory());
		
			if(!targetOk)
			{
		  		pl.insertAfter("errorMessage", destDir + " does not exist or is not a directory");
		  		pl.insertAfter("successFlag", "false");
		  		pl.destroy();
		  		return;
			}
			else
				fullName = destDir + File.separator + fileName;
		
		}
		else
			fullName = fileName; //No destDir specified.  Assume fully-qualified name passed.
		
		
		if (pl.first("overwriteFlag")) { overwriteFlag = (String)pl.getValue(); }
		if (pl.first("exclusiveLock")) { exclusiveLock = (String)pl.getValue(); }
		if (pl.first("charsetName")) { charsetName = (String)pl.getValue(); }   // 4/7/2005 Rob Eamon; added
		
		// 4/7/2005 - Rob Eamon
		// Moved fileOS scope outside the try block so
		// the catch block can close if needed on exception.
		FileOutputStream fileOS=null;
		
		try {
		  if(overwriteFlag.equals("append"))
		    fileOS = new FileOutputStream(fullName, true);
		  else
		    fileOS = new FileOutputStream(fullName, false);
		
		  FileLock lock = null;
		  if(exclusiveLock.equals("true"))
		  {
		    FileChannel channel = fileOS.getChannel();
		    lock = channel.lock();
		  }
		  
		  // 4/7/2005 - Rob Eamon
		  // The following write is not correct--the count of characters
		  // returned by fileContent.length may not match the number
		  // of bytes returned by fileContent.getBytes. Symptom will
		  // be files that are "missing" content. Since the intent is
		  // to write the entire fileContent string, calling the
		  // write method that simply accepts a byte array will be sufficient.
		  //fileOS.write(fileContent.getBytes(), 0, fileContent.length());
		
		  byte fileData[] = null;
		  java.io.InputStream is = null;
		
		  if(fileContent instanceof java.io.InputStream)
		  {
		    is = (java.io.InputStream)fileContent;
		  }
		  else if(fileContent instanceof String)
		  {	
		    if(charsetName != null)
		      fileData = ((String)fileContent).getBytes(charsetName);
		    else
		      fileData = ((String)fileContent).getBytes();
		  }
		  else if(fileContent instanceof byte[])
		  {
		    fileData = (byte[])fileContent;
		  }
		  else
		  {
		    throw new ServiceException("Unsupported fileContent type.");
		  }
		
		  if(fileData != null)
		    fileOS.write(fileData);
		  else
		  {
		    fileData = new byte[1024];
		    int bytesread = 0;
		    while((bytesread=is.read(fileData)) > 0)
		    {
		      fileOS.write(fileData, 0, bytesread);
		    }
		  }
		  // end 4/7/2005
		
		  if((lock != null) && (lock.isValid())) lock.release();
		  fileOS.close();  // Closing the stream closes the channel. Closing the
		                   // channel releases the lock.
		  pl.insertAfter("successFlag", "true");
		}
		catch (java.lang.IllegalStateException ex) {
		  // 4/7/2005 Rob Eamon
		  // Close the output stream if it was opened to avoid resource leaks.
		  try {
		    if(fileOS != null)
		      fileOS.close();
		  } 
		  catch (java.io.IOException ignored) { }
		  // end 4/7/2005
		
		  pl.insertAfter("errorMessage", "Could not open or read from " + fullName );
		  pl.insertAfter("successFlag", "false");
		  //pl.destroy();
		  //return;
		}
		catch (java.io.IOException ex) {
		  // 4/7/2005 Rob Eamon
		  // Close the output stream if it was opened to avoid resource leaks.
		  try {
		    if(fileOS != null)
		      fileOS.close();
		  } 
		  catch (java.io.IOException ignored) { }
		  // end 4/7/2005
		
		  pl.insertAfter("errorMessage", "Could not write to " + fullName + "\n" + ex.toString() );
		  pl.insertAfter("successFlag", "false");
		  //pl.destroy();
		  //return;
		}
		finally
		{
		  pl.destroy();
		}
		// --- <<IS-END>> ---

                
	}
}

